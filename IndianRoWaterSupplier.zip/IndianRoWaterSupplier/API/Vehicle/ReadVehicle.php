<?php
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	
	
	// database connection will be here

	// include database and object files
	include_once '../Config/Database.php';
	include_once '../Objects/Vehicle.php';
	 
	// instantiate database and product object
	$database = new Database();
	$db = $database->getConnection();
	 
	// initialize object
	$Vehicle = new Vehicle($db);
	 
	// read products will be here
	
	// query products
	$stmt = $Vehicle->read();
	$num = $stmt->rowCount();
	 
	// check if more than 0 record found
	if($num>0)
	{
	 
		// products array
		$Vehicle_arr=array();
		$Vehicle_arr["records"]=array();
	 
		// retrieve our table contents
		// fetch() is faster than fetchAll()
		// http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
			while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				// extract row
				// this will make $row['name'] to
				// just $name only
				extract($row);
		 
				$Vehicle_item=array(
					"VehId" => $VehId,
					"VehNo" => $VehNo,
					"VehName" => html_entity_decode($VehName),
					"Status" => $Status
				);
		 
				array_push($Vehicle_arr["records"], $Vehicle_item);
			}
		 
			// set response code - 200 OK
			http_response_code(200);
		 
			// show products data in json format
			echo json_encode($Vehicle_arr);
	}
	else // no products found will be here
	{
		// set response code - 404 Not found
		http_response_code(404);	 
		// tell the user no products found
		echo json_encode(array("message" => "No Vehicle found."));
	}

?>