<?php
	class Vehicle
	{ 
		// database connection and table name
		private $conn;
	
		// object properties
		public $id;
		public $VehNo;
		public $VehName;
		public $Status;
	 
		// constructor with $db as database connection
		public function __construct($db){
			$this->conn = $db;
		}
		
		// read products
		function read(){
		 
			// select all query
			$query = "select * from vehicledetail";
		 
			// prepare query statement
			$stmt = $this->conn->prepare($query);
		 
			// execute query
			$stmt->execute();
		 
			return $stmt;
		}
		
		
		// create product
		function create()
		{
		 
			// query to insert record
			$query = "INSERT INTO vehicledetail SET VehNo=:VehNo, VehName=:VehName, Status=:Status";
		 
			// prepare query
			$stmt = $this->conn->prepare($query);
		 
			// sanitize
			$this->VehNo=htmlspecialchars(strip_tags($this->VehNo));
			$this->VehName=htmlspecialchars(strip_tags($this->VehName));
			$this->Status=htmlspecialchars(strip_tags($this->Status));
			
		 
			// bind values
			$stmt->bindParam(":VehNo", $this->VehNo);
			$stmt->bindParam(":VehName", $this->VehName);
			$stmt->bindParam(":Status", $this->Status);
			
			// execute query
			if($stmt->execute())
			{
				return true;
			}
		 	else
			{
				return false;
			}
		}
		
		// used when filling up the update product form
		function ReadSingle()
		{
		 
			// query to read single record
			$query = "select * from vehicledetail WHERE VehId = ?";
		 
			// prepare query statement
			$stmt = $this->conn->prepare( $query );
		 
			// bind id of product to be updated
			$stmt->bindParam(1, $this->id);
		 
			// execute query
			$stmt->execute();
		 
			// get retrieved row
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
		 
			// set values to object properties
			$this->VehNo = $row['VehNo'];
			$this->VehName = $row['VehName'];
			$this->Status = $row['Status'];
		}
		
		// update the product
		function update()
		{
			// update query
			$query = "UPDATE products SET VehNo = :VehNo, VehName = :VehName, Status = :Status WHERE VehId = :id";
		 
			// prepare query statement
			$stmt = $this->conn->prepare($query);
		 
			
			$this->id=htmlspecialchars(strip_tags($this->id));
			$this->VehNo=htmlspecialchars(strip_tags($this->VehNo));
			$this->VehName=htmlspecialchars(strip_tags($this->VehName));
			$this->Status=htmlspecialchars(strip_tags($this->Status));
					 
			// bind values
			$stmt->bindParam(":id", $this->id);
			$stmt->bindParam(":VehNo", $this->VehNo);
			$stmt->bindParam(":VehName", $this->VehName);
			$stmt->bindParam(":Status", $this->Status);
			
			// execute the query
			if($stmt->execute())
			{
				return true;
			}
			else
			{
				return false;
			}		 
		}
		
		// delete the product
		function delete()
		{ 
			// delete query
			$query = "DELETE FROM products WHERE id = ?";
		 
			// prepare query
			$stmt = $this->conn->prepare($query);
		 
			// sanitize
			$this->id=htmlspecialchars(strip_tags($this->id));
		 
			// bind id of record to delete
			$stmt->bindParam(1, $this->id);
		 
			// execute query
			if($stmt->execute())
			{
				return true;
			}
			return false;
		}
		
	}
	
	

?>