<?php
	include"../../Config/Connection.php";
	session_start();
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "IssueStock":
				try
				{
					$conec = new Connection();
					$con = $conec->Open();
					if($con)
					{
						$Count = $_POST['txtLength'];
						$Date = date("y-m-d H:i:s");
						for ($i = 1; $i <= $Count; $i++)
						{
							if (isset($_POST['chk'.$i]))
							{
								
								$Query = "INSERT INTO `issue_stock` (`IssueId`, `StockId`, `CustId`, `UserType`, `UserId`, `IssueTime`, `Price`, `PaymentType`, `RecNo`, `DTId`) 											  										  VALUES (NULL, :StockId, :CustId, :UserType, :UserId, :IssueTime, 
										  (select Price from pricesetting where ProId=(select ProId from stock where StockId= :StockId) 
										  and CustId=".$_REQUEST['CustId']."), :PaymentType, NULL, :DTId);";
								
								
								$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																			
								if($pre->execute(array(':StockId' => $_POST['chk'.$i], ':CustId' => $_REQUEST['CustId'],
													   ':PaymentType' => $_POST['drpPaymentType'], ':UserId' => $_REQUEST['UserId'],
													   ':IssueTime' => $Date, ':UserType' => "Employee", ':DTId' => $_REQUEST['DTId'])))
								{
									
								}												 
							}
						}
						echo "Data Successfully Saved";
					}
					else
					{
						echo $con;
					}
				}
				catch(PDOException $ex)
				{
					echo "Error:<br>".$ex->getMessage();
				}	
		break;
		
		case "ShowIssuedStock":
				$Id = $_REQUEST['DTId'];
				$Query = "select a.StockId,b.Code from loadstock as a join stock as b join dailytask as c on a.StockId=b.StockId and a.DTId=$Id and a.DTId=c.DTId and 
						  a.StockId not in (select StockId from issue_stock where DTId=$Id) and c.Status='Shipping'";
				$res = mysqli_query($Con, $Query);
				$i = 1;
				while ($row = mysqli_fetch_array($res))
				{
			?>
					<tr>
						<td><?php echo $row['Code']; ?></td>
						<td width="50px" align="center"><input type="checkbox" value="<?php echo $row['StockId']; ?>" id="chk<?php echo $i; ?>" name="chk<?php echo $i; ?>" /></td>
					</tr>
			<?php
					$i++;
				}
			?>
				<input type="hidden" name="txtLength" id="txtLength" value="<?php echo $i; ?>" />
			<?php
		break;
		
		case "ShowReturnStock":
				$Id = $_REQUEST['CustId'];
				$Query = "select a.IssueId,b.Code,c.ProName from issue_stock as a join stock as b join productmaster as c on a.StockId=b.StockId and b.ProId=c.ProId and a.IssueId not in (select IssueId from returnstock) and a.CustId=$Id";
				$res = mysqli_query($Con, $Query);
				$i = 1;
				while ($row = mysqli_fetch_array($res))
				{
			?>
					<tr>
						<td><?php echo $row['Code']."<br>".$row['ProName']; ?></td>
						<td width="50px" align="center"><input type="checkbox" value="<?php echo $row['IssueId']; ?>" id="chk<?php echo $i; ?>" name="chk<?php echo $i; ?>" /></td>
					</tr>
			<?php
					$i++;
				}
			?>
				<input type="hidden" name="txtLength" id="txtLength" value="<?php echo $i; ?>" />
			<?php
		break;
		
		case "ShowAllReturnStock":
				$Query = "select a.IssueId,b.Code,c.ProName from issue_stock as a join stock as b join productmaster as c on a.StockId=b.StockId and b.ProId=c.ProId and a.IssueId not in (select IssueId from returnstock)";
				$res = mysqli_query($Con, $Query);
				$i = 1;
				while ($row = mysqli_fetch_array($res))
				{
			?>
					<tr>
						<td><?php echo $row['Code']."<br>".$row['ProName']; ?></td>
						<td width="50px" align="center"><input type="checkbox" value="<?php echo $row['IssueId']; ?>" id="chk<?php echo $i; ?>" name="chk<?php echo $i; ?>" /></td>
					</tr>
			<?php
					$i++;
				}
			?>
				<input type="hidden" name="txtLength" id="txtLength" value="<?php echo $i; ?>" />
			<?php
		break;
		
		case "ShowAllStock":
				$Query = "select b.StockId,b.Code,c.ProName from stock as b join productmaster as c on b.ProId=c.ProId and b.StockId not in (select StockId from damagestock)";
				$res = mysqli_query($Con, $Query);
				$i = 1;
				while ($row = mysqli_fetch_array($res))
				{
			?>
					<tr>
						<td><?php echo $row['Code']."<br>".$row['ProName']; ?></td>
						<td width="50px" align="center"><input type="checkbox" value="<?php echo $row['StockId']; ?>" id="chk<?php echo $i; ?>" name="chk<?php echo $i; ?>" /></td>
					</tr>
			<?php
					$i++;
				}
			?>
				<input type="hidden" name="txtLength" id="txtLength" value="<?php echo $i; ?>" />
			<?php
		break;
		
		case "DamageStock":
			try
			{
				$conec = new Connection();
				$con = $conec->Open();
				if($con)
				{
					$Count = $_POST['txtLength'];
					$Date = date("y-m-d H:i:s");
					for ($i = 1; $i <= $Count; $i++)
					{
						if (isset($_POST['chk'.$i]))
						{
							$Query = "INSERT INTO `damagestock` (`DId`, `StockId`, `TransecId`, `UserId`, `UserType`, `DTId`) VALUES 
									 (NULL, :StockId, :Time, :UserId, :UserType, :DTId);";
							
							
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':UserId' => $_REQUEST['UserId'], ':Time' => $Date, ':DTId' => $_REQUEST['DTId'],
												   ':StockId' => $_POST['chk'.$i], ':UserType' => "Employee")))
							{
								
							}												 
						}
					}
					echo "Data Successfully Saved";
				}
				else
				{
					echo $con;
				}
			}
			catch(PDOException $ex)
			{
				echo "Error:<br>".$ex->getMessage();
			}
		break;
		
		case "ReturnStock":
			try
			{
				$conec = new Connection();
				$con = $conec->Open();
				if($con)
				{
					$Count = $_POST['txtLength'];
					$Date = date("y-m-d H:i:s");
					for ($i = 1; $i <= $Count; $i++)
					{
						if (isset($_POST['chk'.$i]))
						{
							$Query = "INSERT INTO `returnstock` (`RSId`, `IssueId`, `UserType`, `UserId`, `ReturnTime`, `DTId`) VALUES 
									 (NULL, :IssueId, :UserType, :UserId, :Time, :DTId);";
							
							
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':UserId' => $_REQUEST['UserId'], ':Time' => $Date, ':DTId' => $_REQUEST['DTId'],
												   ':IssueId' => $_POST['chk'.$i], ':UserType' => "Employee")))
							{
								
							}												 
						}
					}
					echo "Data Successfully Saved";
				}
				else
				{
					echo $con;
				}
			}
			catch(PDOException $ex)
			{
				echo "Error:<br>".$ex->getMessage();
			}
		break;
		
		case "ShowLoadStock":
				$Id = $_REQUEST['ProId'];
				$DTId = $_REQUEST['DTId'];
				//$Query = "select * from stock where StockId not in (select StockId from issue_stock as a where a.IssueId not in (select IssueId from returnstock))  and ProId=$Id";
				$Query = "select *,(select count(*) from loadstock where DTId=$DTId and StockId=a.StockId) as Status from stock as a where StockId not in (select StockId from issue_stock as a where a.IssueId not in (select IssueId from returnstock))  and ProId=$Id";
				$res = mysqli_query($Con, $Query);
				$i = 1;
				while ($row = mysqli_fetch_array($res))
				{
					$Val = "";
					if ($row['Status'] != '0')
					{
						$Val = "checked='checked'";
					}
			?>
					<tr>
						<td><?php echo $row['Code']; ?></td>
						<td width="50px" align="center">
							<input type="checkbox" value="<?php echo $row['StockId']; ?>" <?php echo $Val; ?> id="chk<?php echo $i; ?>" name="chk<?php echo $i; ?>" />
							<input type="hidden" value="<?php echo $row['StockId']; ?>" id="txtStockId<?php echo $i; ?>" name="txtStockId<?php echo $i; ?>" />
						</td>
					</tr>
			<?php
					$i++;
				}
			?>
				<input type="hidden" name="txtLength" id="txtLength" value="<?php echo $i; ?>" />
			<?php
		break;
			
	}
	
	
	
?>