<?php
	include"../../Config/Connection.php";
	session_start();
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "AddReceivableAmount":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "INSERT INTO `billsreceivable` (`BRId`, `CustId`, `Amount`, `Id`, `UserType`, `RecDate`, `EntryDate`) VALUES 
									 (NULL, :CustId, :Amount, :Id, :UserType, :RecDate, :EntryDate);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
							
							
										
							if($pre->execute(array(':CustId' => $_REQUEST['CustId'], ':Amount' => $_REQUEST['txtAmount'],
													':Id' => $_REQUEST['UserId'], ':UserType' => "Employee",
													':RecDate' => date('Y-m-d'), ':EntryDate' => date('Y-m-d'))))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
			break;
		
		
			
	}
	
	
	
?>