 <?php include"Top.php"; ?>
 <style>
	table {
	  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	  border-collapse: collapse;
	  width: 100%;
	}
	
	td, th {
	  border: 1px solid #ddd;
	  padding: 8px;
	   word-wrap: break-word
	}
	
	tr:nth-child(even){background-color: #f2f2f2;}
	
	tr:hover {background-color: #ddd;}
	
	th {
	  padding-top: 12px;
	  padding-bottom: 12px;
	  text-align: left;
	  background-color: #4CAF50;
	  color: white;
	}
	
	thead, tbody tr {
		display:table;
		width:100%;
		table-layout:fixed;
	}
</style>
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-12">
								<br>
								<table width="100%">
									<tr>
										<td width="50%">
											<a href="CustomerList.php">
												<table width="100%">
													<tr>
														<td align="center">
															<img src="../Icon/Task.png" style="height:80px;width:50%;border-radius:50px 50px 50px 50px" >
														</td>
													</tr>
													<tr>
														<td align="center">Task</td>
													</tr>
												</table>
											</a>	
										</td>
										<td width="50%">
											<a href="ReturnCustomer.php">
												<table width="100%">
													<tr>
														<td align="center">
															<img src="../Icon/Customer.png" style="height:80px;width:50%;border-radius:50px 50px 50px 50px" >
														</td>
													</tr>
													<tr>
														<td align="center">Customer</td>
													</tr>
												</table>
											</a>	
										</td>
									</tr>
									<tr></tr>
									<tr>
										<td width="50%">
											<a href="AllReturn.php">
												<table width="100%">
													<tr>
														<td align="center">
															<img src="../Icon/ReturnDrum.png" style="height:80px;width:50%;border-radius:50px 50px 50px 50px" >
														</td>
													</tr>
													<tr>
														<td align="center">Return Stock</td>
													</tr>
												</table>
											</a>	
										</td>
										<td width="50%">
											<a href="LoadStock.php">
												<table width="100%">
													<tr>
														<td align="center">
															<img src="../Icon/LoadStock.png" style="height:80px;width:50%;border-radius:50px 50px 50px 50px" >
														</td>
													</tr>
													<tr>
														<td align="center">Load Stock</td>
													</tr>
												</table>
											</a>	
										</td>
									</tr>
									<tr>
										<td width="50%">
											<a href="DamageStock.php">
												<table width="100%">
													<tr>
														<td align="center">
															<img src="../Icon/Damage.png" style="height:80px;width:50%;border-radius:50px 50px 50px 50px" >
														</td>
													</tr>
													<tr>
														<td align="center">Damage Stock</td>
													</tr>
												</table>
											</a>	
										</td>
										<td width="50%">
										</td>
									</tr>
								</table>
							</div>		
						</div>  
					</div>
				</div>
			</div>
		</div>
		</form>
	</div>
</div>
<?php include"Bottom.php"; ?>