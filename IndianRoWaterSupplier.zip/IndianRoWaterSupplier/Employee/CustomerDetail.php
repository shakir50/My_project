 <?php include"Top.php"; ?>
 
 <?php
 	if (isset($_REQUEST['CustId']))
	{
		$Query = "Select * from customer where CustId=".$_REQUEST['CustId'];
		$res = mysqli_query($Con, $Query);
		$row = mysqli_fetch_array($res);
	}
	else
	{
?>	
		<script>
			window.location.href="CustomerList.php";
		</script>
<?php			
	}
 ?>
 <style>
	table {
	  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	  border-collapse: collapse;
	  width: 100%;
	}
	
	td, th {
	  border: 1px solid #ddd;
	  padding: 8px;
	  word-wrap: break-word
	}
	
	tr:nth-child(even){background-color: #f2f2f2;}
	
	tr:hover {background-color: #ddd;}
	
	th {
	  padding-top: 12px;
	  padding-bottom: 12px;
	  text-align: left;
	  background-color: #4CAF50;
	  color: white;
	}
	
	thead, tbody tr {
		display:table;
		width:100%;
		table-layout:fixed;
	}
</style>
 <div class="page-content">
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-12" >
								<br>
								<table width="100%" style="table-layout: fixed">
									<tr>
										<td width="80px"><b>Name:</b></td>
										<td><?php echo $row['FullName']; ?></td>
									</tr>
									<tr>
										<td width="80px"><b>Contact:</b></td>
										<td><?php echo $row['Cno']; ?></td>
									</tr>
									<tr>
										<td width="80px"><b>Type:</b></td>
										<td><?php echo $row['CustType']; ?></td>
									</tr>
									<tr>
										<td width="80px"><b>Remain:</b></td>
										<td>
											<?php
												if ($row['CustType'] == "Cash")
												{
													$Query = "select (COALESCE(sum(a.Price),0) - (select COALESCE(sum(Amount),0) from billsreceivable where CustId=a.CustId) ) as 'Remain' from issue_stock as a join customer as b on a.CustId = b.CustId and b.CustType='Cash' and a.PaymentType='Credit' and a.CustId=".$_REQUEST['CustId'];
													$res = mysqli_query($Con, $Query);
													$row = mysqli_fetch_array($res);
													echo $row['Remain'];
													
												}
												else
												{
													$Query = "select (COALESCE(sum(a.Amount),0) - (select COALESCE(sum(Amount),0) from billsreceivable where CustId=a.CustId)) as 'Remain' from receipt as a where a.CustId=".$_REQUEST['CustId'];
													$res = mysqli_query($Con, $Query);
													$row = mysqli_fetch_array($res);
													echo $row['Remain'];
												}
											?>
										</td>
									</tr>
									<tr>
										<td width="80px"><b>Reserved:</b></td>
										<td>
											<?php
												$Query = "select Count(*) as 'Reserved' from issue_stock where 
														  IssueId not in (select IssueId from returnstock) and CustId=".$_REQUEST['CustId'];
												$res = mysqli_query($Con, $Query);
												$remain = mysqli_fetch_array($res);
												echo $remain['Reserved'];
											?>
										</td>
									</tr>	
								</table>
								<br>
								<table width="100%">
									<tr>
										<td width="50%">
											<a href="IssueStock.php?CustId=<?php echo $_REQUEST['CustId']; ?>" style="width:100%" class="btn btn-primary">Issue Stock</a>
										</td>
										<td width="50%">
											<a href="ReturnStock.php?CustId=<?php echo $_REQUEST['CustId']; ?>" style="width:100%" class="btn btn-primary">Return Stock</a>
										</td>
									</tr>
									<tr>
										<td width="50%">
											<a href="#" data-toggle="modal" onclick="FetchRemAmount('<?php echo $row['Remain']; ?>')" data-target="#BillsReceivable" style="width:100%" class="btn btn-primary">Amount Receive</a>
										</td>
										<td width="50%"><a href="#" style="width:100%" class="btn btn-primary">Note</a></td>
									</tr>
									<tr>
										<td colspan="2">
											<a href="#" onclick="window.history.back();" style="width:100%" class="btn btn-primary"><i class='fas fa-backward'></i> Back</a>
										</td>
									</tr>
								</table>
							</div>
						</div>    
					</div>
				</div>
			</div>
		</div>
		<script>
			function FetchRemAmount(Amount)
			{
				document.getElementById("txtRemAmount").value = Amount;
				document.getElementById("txtAmount").value = Amount;
			}
			
			$(document).ready(function() 
			{
				$("#btnRecAmount").click(function() 
				{
					var RemAmount = parseFloat(document.getElementById("txtRemAmount").value);
					var Amount = parseFloat(document.getElementById("txtAmount").value);
					
					if (Amount == "")
					{
						document.getElementById("lblRemAmount").innerText = "*Required";	
					}
					else
					{
						if (Amount <= RemAmount)
						{
							document.getElementById("lblRemAmount").innerText = "*";
							var CustId = "<?php echo $_REQUEST['CustId']; ?>";
							var UserId = "<?php echo $_COOKIE['EmpId']; ?>";
							var form_data = new FormData(document.getElementById("myform"));
							  form_data.append("label", "WEBUPLOAD");
							  $.ajax({
								  url: "Code/ManageReceipt.php?Choice=AddReceivableAmount&UserId=" + UserId + "&CustId=" + CustId,
								  type: "POST",
								  data: form_data,
								  processData: false,  // tell jQuery not to process the data
								  contentType: false   // tell jQuery not to set contentType
							  }).done(function( data ) {
								console.log(data);
								$('#myform')[0].reset();
								//Perform ANy action after successfuly post data
								window.location.href = "CustomerDetail.php?CustId=<?php echo $_REQUEST['CustId']; ?>";
							  });
						}
						else
						{
							document.getElementById("lblRemAmount").innerText = "*Not More Then " + RemAmount + " Amount";
						}
					}
				});
			});
			
		</script>
		
		<!-- Modal -->
		<div class="modal fade" id="BillsReceivable" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Amount Receive</h4>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">
								<label>Amount: <span style="color:red" id="lblRemAmount">*</span></label>
								<input type="hidden" name="txtRemAmount" id="txtRemAmount" />
								<input type="number" name="txtAmount" onkeypress="return isNumber(event)" class="form-control" id="txtAmount" />
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-primary" name="btnRecAmount" id="btnRecAmount" value="Save" />
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

		</form>
	</div>
</div>
<?php include"Bottom.php"; ?>