
<!DOCTYPE html>
<html>

<!-- Mirrored from webarch.revox.io/3.0/html/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Jun 2019 04:50:40 GMT -->
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>Indian RO Water Supplier</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests"> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="../../cdn-cgi/apps/head/QJpHOqznaMvNOv9CGoAdo_yvYKU.js"></script><link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen" />
<link href="../assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="../assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="../assets/plugins/animate.min.css" rel="stylesheet" type="text/css" />
<link href="../assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css" />


<link href="../webarch/css/webarch.css" rel="stylesheet" type="text/css" />
<script>
	$(document).ready(function() 
	{
		$("#btnLogin").click(function() 
		{
			var cnt = 0;
			var Element = ['Cno', 'Pass'];
			
			for (i = 0; i < Element.length; i++)
			{
				var txtName = "txt" + Element[i];
				var lblName = "lbl" + Element[i];
				var Value = document.getElementById(txtName).value;
				if ( Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
			}
			
			if (cnt == 0) 
			{
				  var form_data = new FormData(document.getElementById("myform"));
				  form_data.append("label", "WEBUPLOAD");
				  $.ajax({
					  url: "../Admin/Code/ManageEmployee.php?Choice=Login",
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
				  }).done(function( data ) {
					console.log(data);
					$('#myform')[0].reset();
					if (data == "Success Login")
					{
						window.location.href = "Home.php";
					}
					else
					{
						alert(data);
					}
					//Perform ANy action after successfuly post data
					   
				  });
			}
		});
	});
</script>
</head>


<body class="error-body no-top">
	<div class="container">
		<div class="row login-container column-seperation">
			<div class="col-md-3">
			</div>
			<div class="col-md-9">
				<h1 style="font-size:4vw;">Indian RO Water Supplier</h1>
			</div>
			<div class="col-md-3">
			</div>
			<div class="col-md-6">
				
			<br>
				<form class="login-form validate" id="myform" method="post" name="myform">
					<div class="row">
						<div class="form-group col-md-10">
							<label class="form-label">Username<span style="color:red" id="lblCno">*</span></label>
							<input class="form-control" id="txtCno" placeholder="Enter Contact No here" name="txtCno" type="number" required>
						</div>
						<div class="form-group col-md-10">
							<label class="form-label">Password<span style="color:red" id="lblPass">*</span></label> <span class="help"></span>
							<input class="form-control" id="txtPass" placeholder="Enter Password here" name="txtPass" type="password" required>
						</div>
						<div class="control-group col-md-10">
							<div class="checkbox checkbox check-success">
							<a href="#">Trouble login in?</a>&nbsp;&nbsp;
							<input id="checkbox1" type="checkbox" value="1">
							<label for="checkbox1">Keep me reminded</label>
						</div>
						<div class="col-md-12">
							<input class="btn btn-primary btn-cons pull-right" id="btnLogin" name="btnLogin" type="button" value="Login" />
						</div>
					</div>
				</form>	
			</div>
		
		</div>
	</div>
	
	
	

<script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>

<script src="assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>


<script src="webarch/js/webarch.js" type="text/javascript"></script>
<script src="assets/js/chat.js" type="text/javascript"></script>

</body>

<!-- Mirrored from webarch.revox.io/3.0/html/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Jun 2019 04:50:40 GMT -->
</html>