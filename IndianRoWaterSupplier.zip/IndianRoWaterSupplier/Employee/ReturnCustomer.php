 <?php include"Top.php"; ?>
 <style>
	table {
	  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	  border-collapse: collapse;
	  width: 100%;
	}
	
	td, th {
	  border: 1px solid #ddd;
	  padding: 8px;
	   word-wrap: break-word
	}
	
	tr:nth-child(even){background-color: #f2f2f2;}
	
	tr:hover {background-color: #ddd;}
	
	th {
	  padding-top: 12px;
	  padding-bottom: 12px;
	  text-align: left;
	  background-color: #4CAF50;
	  color: white;
	}
	
	thead, tbody tr {
		display:table;
		width:100%;
		table-layout:fixed;
	}
</style>
 <div class="page-content">
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-12">
								<br>
								<input type="text" name="txtSearch" onkeyup="myFunction()" Placeholder="Search by Customer" class="form-control" id="txtSearch">
							</div>
							<div class="col-md-12" >
								<!-- style="height:400px;overflow:scroll" -->
								<table width="100%" id="myTable">
									<tr>
										<th>Customer List</th>
									</tr>
									<tbody style="display:block;height:380px;overflow:auto;">
										<?php
											$Query = "select CustId,FullName from customer";
											$res = mysqli_query($Con, $Query);
											while ($row = mysqli_fetch_array($res))
											{
										?>
												<tr>
													<td>
														<a href="CustomerDetail.php?CustId=<?php echo $row['CustId']; ?>">
															<div style="width:100%"><?php echo $row['FullName']; ?></div>
														</a>	
													</td>
												</tr>
										<?php
											}
										?>
									</tbody>
								</table>
							</div>
						</div>    
					</div>
				</div>
			</div>
		</div>
		</form>
	</div>
</div>
	<script>
		function myFunction() {
		  var input, filter, table, tr, td, i, txtValue;
		  input = document.getElementById("txtSearch");
		  filter = input.value.toUpperCase();
		  table = document.getElementById("myTable");
		  tr = table.getElementsByTagName("tr");
		  for (i = 0; i < tr.length; i++) {
			td = tr[i].getElementsByTagName("td")[0];
			if (td) {
			  txtValue = td.textContent || td.innerText;
			  if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
			  } else {
				tr[i].style.display = "none";
			  }
			}       
		  }
		}
	</script>
<?php include"Bottom.php"; ?>