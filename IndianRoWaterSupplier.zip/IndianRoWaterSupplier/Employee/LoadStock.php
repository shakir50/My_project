 <?php include"Top.php"; ?>
 
 <script>
 		$(document).ready(function() 
		{
			$("#btnSave").click(function() 
			{
				var cnt = 0;
				var Length = document.getElementById("txtLength").value;
				
				for (i=1; i < Length; i++)
				{
					var chkName = "chk" + i;
					if (document.getElementById(chkName).checked == true)
					{
						cnt++;
					}				
				}
				
				if (cnt == 0)
				{
					document.getElementById("lblProList").innerText = " *Required";
				}
				else
				{
					document.getElementById("lblProList").innerText = " *";
					var form_data = new FormData(document.getElementById("myform"));
						form_data.append("label", "WEBUPLOAD");
						var DTId = "<?php echo $_COOKIE['DTId']; ?>";
						$.ajax({
						  url: "../Admin/Code/ManageCreateTask.php?Choice=AddLoadStock&DTId=" + DTId + "&Status=False",
						  type: "POST",
						  data: form_data,
						  processData: false,  // tell jQuery not to process the data
						  contentType: false   // tell jQuery not to set contentType
						}).done(function( data ) {
						console.log(data);
						ShowData();
						alert(data);
						//$('#myform')[0].reset();
						//Perform ANy action after successfuly post data   
						});
				}
				
			});
		});
 </script>
 
 <style>
	table {
	  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	  border-collapse: collapse;
	  width: 100%;
	}
	
	td, th {
	  border: 1px solid #ddd;
	  padding: 8px;
	  word-wrap: break-word;
	}
	
	tr:nth-child(even){background-color: #f2f2f2;}
	
	tr:hover {background-color: #ddd;}
	
	th {
	  padding-top: 12px;
	  padding-bottom: 12px;
	  text-align: left;
	  background-color: #4CAF50;
	  color: white;
	}
	
	thead, tbody tr {
		display:table;
		width:100%;
		table-layout:fixed;
	}
</style>
 <div class="page-content">
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-12">
								<br>
								<table width="100%">
									<td width="50%">
										<select name="drpPro" onChange="ShowData();" class="form-control" id="drpPro">
											<?php
												$Query = "Select  * from productmaster";
												$Result = mysqli_query($Con, $Query);
												while ($row = mysqli_fetch_array($Result))
												{
											?>
													<option value="<?php echo $row['ProId']; ?>"><?php echo $row['ProName']; ?></option>
											<?php			
												}
											?>
										</select>
									</td>
									<td width="50%">
										<input type="text" name="txtSearch" onkeyup="myFunction()" Placeholder="Search by Code" class="form-control" id="txtSearch">
									</td>
								</table>	
								
							</div>
							<div class="col-md-12" >
								<!-- style="height:400px;overflow:scroll" -->
								<table width="100%" id="myTable">
									<tr>
										<th>Product List <span style="color:red" id="lblProList"> *</span></th>
										<th width="50px" style="text-align:center"><input type="checkbox" onclick="CheckAll();" name="chkAll" id="chkAll" /></th>
									</tr>
									<tbody style="display:block;height:300px;overflow:auto;" id="Disp">
										
									</tbody>
								</table>
								
							</div>
							<div class="col-md-12" align="center">
								<br>
								<a href="#" onclick="window.history.back();" class="btn btn-primary"><i class='fas fa-backward'></i> Back</a>
								<input class="btn btn-primary" id="btnSave" name="btnSave" type="button" value="Save" />
							</div>
						</div>    
					</div>
				</div>
			</div>
		</div>
		</form>
	</div>
</div>
	
	<script>
		function ShowData()
		{
			var ProId = document.getElementById("drpPro").value;
			var DTId = "<?php echo $_COOKIE['DTId'] ?>";
			$('#Disp').load('Code/ManageIssueReturn.php?Choice=ShowLoadStock&ProId='+ProId+"&DTId="+DTId);	
		}
		
		ShowData();
		
		function CheckAll()
		{
			var Length = document.getElementById("txtLength").value;
			if (document.getElementById("chkAll").checked == true)
			{
				for (i=1; i < Length; i++)
				{
					var Id = "chk" + i;
					document.getElementById(Id).checked = true;
				}
			}
			else
			{
				for (i=1; i < Length; i++)
				{
					var Id = "chk" + i;
					document.getElementById(Id).checked = false;
				}
			}			
		}
		
		function myFunction() {
		  var input, filter, table, tr, td, i, txtValue;
		  input = document.getElementById("txtSearch");
		  filter = input.value.toUpperCase();
		  table = document.getElementById("myTable");
		  tr = table.getElementsByTagName("tr");
		  for (i = 0; i < tr.length; i++) {
			td = tr[i].getElementsByTagName("td")[0];
			if (td) {
			  txtValue = td.textContent || td.innerText;
			  if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
			  } else {
				tr[i].style.display = "none";
			  }
			}       
		  }
		}
		
		
	</script>
<?php include"Bottom.php"; ?>