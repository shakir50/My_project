<?php
	$Con = mysqli_connect("localhost","root","","indianrowater");
	date_default_timezone_set('Asia/Kolkata');
	class Connection
	{
		protected $db=null;
		
		public function Open()
		{
			try
			{
				$dsn="mysql:dbname=indianrowater;host=localhost";
				$UserName="root";
				$Password="";
				$options  = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC);
				//PDO::ERRMODE_EXCEPTION : PDO will throw a PDOException and set its properties to reflect the error code and error information
				
				$this->db = new PDO($dsn, $UserName, $Password, $options);
			}
			catch (PDOException $e)
			{
				echo "Error :".$e->getMessage();
			}
			
			 return $this->db;
		}
		
		public function Close()
		{
			$this->db = null;
        	return true;
		}
	}
?>
