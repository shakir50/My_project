 <?php include"Top.php"; ?>
 <script>
 	$(document).ready(function() 
	{
		$("#btnSave").click(function() 
		{
			var cnt = 0;
			var Element = ['DateFrom', 'DateTo'];
			for (i = 0; i < Element.length; i++)
			{
				var txtName = "txt" + Element[i];
				var lblName = "lbl" + Element[i];
				var Value = document.getElementById(txtName).value;
				if ( Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
			}
			
			if (cnt == 0) 
			{
				var form_data = new FormData(document.getElementById("myform"));
			  	form_data.append("label", "WEBUPLOAD");
			 
				$.ajax({
				  url: "Code/ManageReceipt.php?Choice=CreateReceiptList",
				  type: "POST",
				  data: form_data,
				  processData: false,  // tell jQuery not to process the data
				  contentType: false   // tell jQuery not to set contentType
				}).done(function( data ) {
				console.log(data);
				alert(data);
				$('#myform')[0].reset();
				ShowData();
				//Perform ANy action after successfuly post data   
			  });
			}
		});
	});
 </script>
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Receipt <span class="semi-bold">Generate</span></h4>
					</div>
					<div class="grid-body no-border">
						<table width="100%">
							<tr>
								<td width="50%">
									<div class="form-group">
										<label style="font-weight:bold">Date From: <span style="color:red" id="lblDateFrom">*</span></label>
										<div class="control">
											<input type="date" name="txtDateFrom" style="width:95%" id="txtDateFrom" class="form-control" />
										</div>
									</div>
								</td>
								<td width="50%">
									<div class="form-group">
										<label style="font-weight:bold">Date To: <span style="color:red" id="lblDateTo">*</span></label>
										<div class="control">
											<input type="date" name="txtDateTo" id="txtDateTo" onchange="ShowData();" style="width:95%" class="form-control" />
										</div>
									</div>
								</td>
							</tr>
						</table>
						<button type="button" name="btnExcel" onclick="tableToExcel('myTable', 'W3C Example Table')" id="btnExcel" class="btn btn-primary btn-cons">Export to Excel</button>
						<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
						<div class="table-responsive">
							<table class="table" id="myTable">
								<tr>
									<th>Sr No.</th>
									<th>Name</th>
									<th>No. of Issue</th>
									<th>Amount</th>
								</tr>
								<tbody id="Disp">
								
								</tbody>
							</table>
						</div>    
					</div>
				</div>
			</div>
		</div>
		</form>
	</div>
</div>
<script>
	function ShowData()
	{
		var DateFrom = document.getElementById("txtDateFrom").value;
		var DateTo = document.getElementById("txtDateTo").value;
		$('#Disp').load('Code/ManageReceipt.php?Choice=ShowReceiptList&DateFrom='+DateFrom+'&DateTo='+DateTo);
	}
</script>
<?php include"Bottom.php"; ?>