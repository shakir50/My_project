 <?php include"Top.php"; ?>
 <script>
 	function SetVisibility()
	{
		if (document.getElementById("rdbIssue").checked == true)
		{
			document.getElementById("Issue").style.display = "initial";
			document.getElementById("Return").style.display = "none";
		}
		else
		{
			document.getElementById("Return").style.display = "initial";
			document.getElementById("Issue").style.display = "none";
		}
	}
 </script>
<script>
  		$(document).ready(function() 
		{
			$("#btnSave").click(function() 
			{
				var Time = document.getElementById("txtIssueDate").value;
				if (Time == "")
				{
					document.getElementById("lblIssueDate").innerText = "*Required";
				}
				else
				{
					document.getElementById("lblIssueDate").innerText = "*";
					var cnt = 0;
					var Length = document.getElementById("txtLength").value;
					
					for (i=1; i <= Length; i++)
					{
						var chkName = "chk" + i;
						if (document.getElementById(chkName).checked == true)
						{
							cnt++;
						}				
					}
					
					if (cnt == 0) 
					{
						document.getElementById("lblErrStock").innerText = "*Required";
					}
					else
					{
						var form_data = new FormData(document.getElementById("myform"));
						form_data.append("label", "WEBUPLOAD");
						var IssueId = "<?php echo $_SESSION['AdminId']; ?>"; 
						var CustId = "<?php echo $_REQUEST['CustId']; ?>";
						$.ajax({
						  url: "Code/ManageIssueReturnStock.php?Choice=AddLoadStock&CustId=" + CustId + "&IssueId=" + IssueId,
						  type: "POST",
						  data: form_data,
						  processData: false,  // tell jQuery not to process the data
						  contentType: false   // tell jQuery not to set contentType
						}).done(function( data ) {
						console.log(data);
						ShowReturnData();
						ShowData();
						alert(data);
						//$('#myform')[0].reset();
						//Perform ANy action after successfuly post data   
						});
						document.getElementById("lblErrStock").innerText = "*";
					}
				}
				
			});
		});
		
		$(document).ready(function() 
		{
			$("#btnReturnSave").click(function() 
			{
				var Time = document.getElementById("txtReturnDate").value;
				if (Time == "")
				{
					document.getElementById("lblReturnDate").innerText = "*Required";
				}
				else
				{
					document.getElementById("lblReturnDate").innerText = "*";
					var cnt = 0;
					var Length = document.getElementById("txtReturnLength").value;
					
					for (i=1; i <= Length; i++)
					{
						var chkName = "chkReturn" + i;
						if (document.getElementById(chkName).checked == true)
						{
							cnt++;
						}				
					}
					
					if (cnt == 0) 
					{
						document.getElementById("lblReturnStock").innerText = "*Required";
					}
					else
					{
						var form_data = new FormData(document.getElementById("myform"));
						form_data.append("label", "WEBUPLOAD");
						var ReturnId = "<?php echo $_SESSION['AdminId']; ?>"; 
						$.ajax({
						  url: "Code/ManageIssueReturnStock.php?Choice=ReturnStock&ReturnId=" + ReturnId,
						  type: "POST",
						  data: form_data,
						  processData: false,  // tell jQuery not to process the data
						  contentType: false   // tell jQuery not to set contentType
						}).done(function( data ) {
						console.log(data);
						ShowReturnData();
						ShowData();
						alert(data);
						//$('#myform')[0].reset();
						//Perform ANy action after successfuly post data   
						});
						document.getElementById("lblReturnStock").innerText = "*";
					}
				}
				
			});
		});
 	</script>
 <div class="page-content">
	<div class="clearfix">
	</div>
	
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Issue - Return <span class="semi-bold">Stock</span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="radio radio-success">
							<input id="rdbIssue" type="radio" onClick="SetVisibility();" name="optionyes" value="yes" checked="checked">
							<label for="rdbIssue">Issuer</label>
							<input id="rdbReturn" type="radio" onClick="SetVisibility();" name="optionyes" value="no">
							<label for="rdbReturn">Return</label>
						</div>
					</div>
				</div>
			</div>
			
			<div class="col-md-12" id="Issue">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Issue <span class="semi-bold">Stock <span id="lblErrStock" style="color:red">*</span></span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label style="font-weight:bold">Select Product <span style="color:red" id="lblProduct">*</span></label>
									<div class="control">
										<select name="drpPro" id="drpPro" onChange="ShowData();" class="form-control">
											<?php
												try
												{
													$conec = new Connection();
													$con = $conec->Open();
													if($con)
													{
														$sql = "SELECT * FROM productmaster order by ProName desc";
														$re  = $con->query($sql);
														foreach ($con->query($sql) as $row) 
														{										
											?>	
															<option value="<?php echo $row['ProId']; ?>"><?php echo $row['ProName']; ?></option>
											<?php													
														}
													}
													else
													{
														echo $con;
													}
												}
												catch(PDOException $ex)
												{
													echo "Error:<br>".$ex->getMessage();
												}
											?>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label style="font-weight:bold">Payment Type</label>
									<div class="control">
										<select id="drpPayment" name="drpPayment" class="form-control">
											<option value="Credit">Credit</option>
											<option value="Cash">Cash</option>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label style="font-weight:bold">Issue Time<span style="color:red" id="lblIssueDate"> *</span></label>
									<div class="control">
										<input type="datetime-local" id="txtIssueDate" name="txtIssueDate" class="form-control">
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label style="font-weight:bold">Search By Code</label>
									<div class="control">
										<input type="text" id="txtSearch" onkeyup="myFunction(0)" class="form-control" 
											   placeholder="Search By Code">
									</div>
								</div>
							</div>
							
							<div class="col-md-12">
								<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
								<a class="btn btn-primary btn-cons" href="Customer.php" >Back</a>
							</div>
							<div class="col-md-12">
								<div class="table-responsive">
									<table class="table" id="myTable">
										<tr>
											<th width="80px">Sr No</th>
											<th>Code</th>
											<th width="10px"></th>
										</tr>
										<tbody id="LoadStock">
										
										</tbody>
									</table>
								</div>
							</div>
							
						</div>    
					</div>
				</div>
			</div>
			<div class="col-md-12" id="Return">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Return <span class="semi-bold">Stock <span id="lblReturnStock" style="color:red">*</span></span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Return Time<span style="color:red" id="lblReturnDate"> *</span></label>
									<div class="control">
										<input type="datetime-local" id="txtReturnDate" name="txtReturnDate" class="form-control">
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Search By Code</label>
									<div class="control">
										<input type="text" id="txtReturnSearch" onkeyup="myReturnFunction(0)" class="form-control" 
											   placeholder="Search By Code">
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<button type="button" name="btnReturnSave" id="btnReturnSave" class="btn btn-primary btn-cons">Save</button>
								<a class="btn btn-primary btn-cons" href="Customer.php" >Back</a>
							</div>
							<div class="col-md-12">
								<div class="table-responsive">
									<table class="table" id="ReturnTable">
										<tr>
											<th></th>
											<th>Code</th>
											<th>Product Name</th>
											<th>Issue Time</th>
											<th>Issued From</th>
											<th width="10px"></th>
										</tr>
										<tbody id="ReturnStock">
										
										</tbody>
									</table>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
		
		</form>
	</div>
</div>
<script>
 	function ShowData()
	{
		var Id = document.getElementById("drpPro").value;
		$('#LoadStock').load('Code/ManageIssueReturnStock.php?Choice=ShowProduct&Id=' + Id);
	}
	function ShowReturnData()
	{
		var Id = "<?php echo $_REQUEST['CustId']; ?>";
		$('#ReturnStock').load('Code/ManageIssueReturnStock.php?Choice=ShowProductReturn&CustId=' + Id);
	}
 </script>

<script>
	SetVisibility();
	ShowData();
	ShowReturnData();
	function myFunction() {
	  var input, filter, table, tr, td, i, txtValue;
	 
	 input = document.getElementById("txtSearch");
	  
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");
	  
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[1];
		if (td) {
		  txtValue = td.textContent || td.innerText;
		  if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}       
	  }
	}
	
	function myReturnFunction() {
	  var input, filter, table, tr, td, i, txtValue;
	 
	 input = document.getElementById("txtReturnSearch");
	  
	  filter = input.value.toUpperCase();
	  table = document.getElementById("ReturnTable");
	  tr = table.getElementsByTagName("tr");
	  
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[1];
		if (td) {
		  txtValue = td.textContent || td.innerText;
		  if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}       
	  }
	}
</script>

<?php include"Bottom.php"; ?>