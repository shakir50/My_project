 <?php include"Top.php"; ?>
 <script>
 	function ShowData()
	{
		$('#Disp').load('Code/ManageIssueReturnStock.php?Choice=ShowIssuedProductList');
	}
	
	$(document).ready(function() 
		{
			$("#btnReturnSave").click(function() 
			{
				var Time = document.getElementById("txtReturnDate").value;
				var cnt = 0;
				if (Time == "")
				{
					document.getElementById("lblReturnDate").innerText = "*Required";
					cnt++;
				}
				else
				{
					var form_data = new FormData(document.getElementById("myform"));
					form_data.append("label", "WEBUPLOAD");
					var ReturnId = "<?php echo $_SESSION['AdminId']; ?>"; 
					$.ajax({
					  url: "Code/ManageIssueReturnStock.php?Choice=ReturnSingleStock&ReturnId=" + ReturnId,
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
					}).done(function( data ) {
					console.log(data);
					ShowData();
					alert(data);
					//$('#myform')[0].reset();
					//Perform ANy action after successfuly post data   
					});
				}
				
			});
		});
	
	
 </script>
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Current Issue <span class="semi-bold">List</span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-4">
								<b>Search By Name</b>
								<input type="text" id="txtSearch"  onkeyup="myFunction(3)" class="form-control" 
										   placeholder="Search By Name">
							</div>
							<div class="col-md-4">
								<b>Search By Code</b>
								<input type="text" id="txtCode"  onkeyup="myFunction(1)" class="form-control" 
										   placeholder="Search By Code">
							</div>
							<div class="col-md-4">
								<b>Search By Product</b>
								<input type="hidden" name="txtProName" id="txtProName" />
								<select name="drpProName" onChange="myFunction(2)" id="drpProName" class="form-control">
									<option value="">Select Product</option>
									<?php
										try
										{
											$conec = new Connection();
											$con = $conec->Open();
											if($con)
											{
												$sql = "SELECT * FROM productmaster order by ProId";
												$re  = $con->query($sql);
												foreach ($con->query($sql) as $row) 
												{										
									?>	
													<option value="<?php echo $row['ProId']; ?>">
														<?php echo $row['ProName']; ?>
													</option>
									<?php													
												}
											}
											else
											{
												echo $con;
											}
										}
										catch(PDOException $ex)
										{
											echo "Error:<br>".$ex->getMessage();
										}
									?>
								</select>
							</div>
							
						</div>
						
						<button type="button" name="btnExcel" onclick="tableToExcel('myTable', 'W3C Example Table')" id="btnExcel" class="btn btn-primary btn-cons">Export to Excel</button>
						<br /><br />
						<div class="table-responsive">
							<table class="table" id="myTable">
								<tr>
									<th>Sr. No.</th>
									<th>Code</th>
									<th>Product</th>
									<th>Customer Name</th>
									<th>Contact No</th>
									<th>Issued From</th>
									<th>Issued Time</th>
									<th>Total Hours</th>
									<th></th>
								</tr>
								<tbody id="Disp">
								
								</tbody>
							</table>
						</div>     
					</div>
				</div>
			</div>
		</div>
		
		<!-- Modal -->
		<div class="modal fade" id="ReturnStock" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Returm Detail</h4>
					</div>
					<div class="modal-body">
						<input type="hidden" id="txtIssueId" name="txtIssueId" />
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label style="font-weight:bold">Return Time<span style="color:red" id="lblReturnDate"> *</span></label>
									<div class="control">
										<input type="datetime-local" id="txtReturnDate" name="txtReturnDate" class="form-control">
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<button type="button" name="btnSave" id="btnReturnSave" class="btn btn-primary btn-cons">Save</button>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

		</form>
	</div>
</div>

<script>
	function getId(Id)
	{
		document.getElementById("txtIssueId").value = Id;	
	}
	
	function myFunction(ch) {
	  var input, filter, table, tr, td, i, txtValue;
	  if (ch == 3)
	  {
		input = document.getElementById("txtSearch");
	  }
	  else if (ch == 1)
	  {
		input = document.getElementById("txtCode");
	  }
	  else
	  {
		var Drp = document.getElementById("drpProName");
		document.getElementById("txtProName").value = Drp.options[Drp.selectedIndex].text;
		input = document.getElementById("txtProName");
	  }
	  
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");
	  
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[ch];
		if (td) {
		  txtValue = td.textContent || td.innerText;
		  if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}       
	  }
	  
	  if (filter == "SELECT PRODUCT")
	  {
	  	ResetTable();
	  }
	  
	}
	
	function ResetTable()
	{
		table = document.getElementById("myTable");
	  	tr = table.getElementsByTagName("tr");
		for (i = 0; i < tr.length; i++) 
		{
			tr[i].style.display = "";      
		}
	}
	ShowData();
</script>

<?php include"Bottom.php"; ?>