<form method="post" id="myProfileform" name="myProfileform" enctype="multipart/form-data">
			<script>
				function preview_image(event,id) 
				{
					 var reader = new FileReader();
					 reader.onload = function()
					 {
						  var output = document.getElementById(id);
						  output.src = reader.result;
					 }
					 reader.readAsDataURL(event.target.files[0]);
				}
			
				function opendialogbox(inputid){
					document.getElementById(inputid).click();
				}
			</script>	
			
			<script>
				$(document).ready(function() 
				{
					$("#btnProSave").click(function() 
					{
						var cnt = 0;
						var Element = ['FullName', 'Contact', 'Email','Address'];
						
						for (i = 0; i < Element.length; i++)
						{
							var txtName = "txtPro" + Element[i];
							var lblName = "lblPro" + Element[i];
							Value = document.getElementById(txtName).value; 
							if ( Value == "")
							{
								cnt++;
								document.getElementById(lblName).innerText = "*Required";
							}
							else
							{
								document.getElementById(lblName).innerText = "*";
							}
						}
						
						if (cnt == 0) 
						{
							
							 var form_data = new FormData(document.getElementById("myProfileform"));
							  form_data.append("label", "WEBUPLOAD");
							  $.ajax({
								  url: "Code/ManageAdminUser.php?Choice=Edit",
								  type: "POST",
								  data: form_data,
								  processData: false,  // tell jQuery not to process the data
								  contentType: false   // tell jQuery not to set contentType
							  }).done(function( data ) {
								console.log(data);
								//Perform ANy action after successfuly post data
							});
						}
					});
					
					$("#btnPassSave").click(function() 
					{
						var cnt = 0;
						var Element = ['OldPass', 'NewPass', 'ConfirmPass'];
						
						for (i = 0; i < Element.length; i++)
						{
							var txtName = "txt" + Element[i];
							var lblName = "lbl" + Element[i];
							Value = document.getElementById(txtName).value; 
							if ( Value == "")
							{
								cnt++;
								document.getElementById(lblName).innerText = "*Required";
							}
							else
							{
								document.getElementById(lblName).innerText = "*";
							}
						}
						
						var New = document.getElementById("txtNewPass").value;
						var Confirm = document.getElementById("txtConfirmPass").value;
						
						if (Confirm != "")
						{
							if (New == Confirm)
							{
								document.getElementById("lblConfirmPass").innerText = "*";
							}
							else
							{
								document.getElementById("lblConfirmPass").innerText = "*Not Match";
								cnt++;
							}
						}
						
						if (cnt == 0) 
						{
							
							 var form_data = new FormData(document.getElementById("myProfileform"));
							  form_data.append("label", "WEBUPLOAD");
							  $.ajax({
								  url: "Code/ManageAdminUser.php?Choice=ChangePassword",
								  type: "POST",
								  data: form_data,
								  processData: false,  // tell jQuery not to process the data
								  contentType: false   // tell jQuery not to set contentType
							  }).done(function( data ) {
								if (data == "Success Saved")
								{
									alert('Successfully Saved');
								}
								else
								{
									alert('Old Password is Incorrect');
								}
								//Perform ANy action after successfuly post data
							});
						}
					});
					
				});
				</script>
			<!-- Modal -->
			  <div class="modal fade" id="ChangeProfile" role="dialog">
				<div class="modal-dialog">
				
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title">Admin User</h4>
					</div>
					<div class="modal-body">
					
					  <input type="hidden" id="txtProfileId" name="txtProfileId" value="<?php echo $_SESSION['AdminId'] ?>" />	
					  <input type="hidden" id="txtProPhoto" name="txtProPhoto" value="<?php echo $_SESSION['Photo'] ?>" />
					  <div class="row">
						<div class="col-md-3">
							<div class="row">
								<div class="col-sm-12 col-xl-12 m-b-30">
									<label class="border-checkbox-label" for="checkbox2"></label><br />
									<div id="uploadpic1" class="thumbimg">
										<span onClick="javascript:opendialogbox('inpProfile');">
											<img class="thumb"  id="ImgProfile1" src="<?php echo $Path; ?>" style="height:150px;width:100%">
											<input type="file" accept='image/*' onchange='preview_image(event,"ImgProfile1")' id="inpProfile" 
												   name="inpProfile" style="visibility:hidden" name="picture" />
										</span>
									</div>	
								</div>
							</div>
						</div>
						<div class="col-md-9">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label style="font-weight:bold">Full Name <span style="color:red" id="lblProFullName">*</span></label>
										<div class="control">
											<input type="text" name="txtProFullName" id="txtProFullName" placeholder="Enter Full Name" class="form-control" value="<?php echo $_SESSION['FullName']; ?>" />
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label style="font-weight:bold">Contact No <span style="color:red" id="lblProContact">*</span></label>
										<div class="control">
											<input type="text" name="txtProContact" id="txtProContact" placeholder="Enter Contact No" class="form-control" value="<?php echo $_SESSION['ContactNo']; ?>" />
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label style="font-weight:bold">Email <span style="color:red" id="lblProEmail">*</span></label>
										<div class="control">
											<input type="text" name="txtProEmail" id="txtProEmail" placeholder="Enter Email" class="form-control" value="<?php echo $_SESSION['Email']; ?>" />
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label style="font-weight:bold">Address <span style="color:red" id="lblProAddress">*</span></label>
										<div class="control">
											<textarea name="txtProAddress" id="txtProAddress" placeholder="Enter Address" class="form-control" ><?php echo $_SESSION['Address']; ?></textarea>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<button type="button" name="btnProSave" id="btnProSave" class="btn btn-primary btn-cons">Save</button>
									<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
								</div>
							</div>
						</div>
						
					  </div>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>
			  
			   <!-- Modal -->
				  <div class="modal fade" id="ChangePassword" role="dialog">
					<div class="modal-dialog">
					
					  <!-- Modal content-->
					  <div class="modal-content">
						<div class="modal-header">
						  <button type="button" class="close" data-dismiss="modal">&times;</button>
						  <h4 class="modal-title">Change Password</h4>
						</div>
						<div class="modal-body">
						  <div class="row">
						  	<div class="col-md-12">
								<div class="form-group">
									<label style="font-weight:bold">Old Password <span style="color:red" id="lblOldPass">*</span></label>
									<div class="control">
										<input type="password" name="txtOldPass" id="txtOldPass" placeholder="Enter Old Password" class="form-control" />
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label style="font-weight:bold">New Password <span style="color:red" id="lblNewPass">*</span></label>
									<div class="control">
										<input type="password" name="txtNewPass" id="txtNewPass" placeholder="Enter New Password" class="form-control" />
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label style="font-weight:bold">Confirm Password <span style="color:red" id="lblConfirmPass">*</span></label>
									<div class="control">
										<input type="password" name="txtConfirmPass" id="txtConfirmPass" placeholder="Enter Confirm Password" class="form-control" />
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<button type="button" name="btnPassSave" id="btnPassSave" class="btn btn-primary btn-cons">Save</button>
								<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
							</div>
						  </div>
						</div>
						<div class="modal-footer">
						  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						</div>
					  </div>
					  
					</div>
				  </div>

		</form>	  
			  
    <script src="../assets/plugins/pace/pace.min.js" type="text/javascript"></script>
    <script src="../assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
    <script src="../assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
    <script src="../assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
    <script src="../assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
    <script src="../assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
    <script src="../assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
    <script src="../assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
    <script src="../webarch/js/webarch.js" type="text/javascript"></script>
    <script src="../assets/js/chat.js" type="text/javascript"></script>
</body>
<!-- Mirrored from webarch.revox.io/3.0/html/blank_template.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Jun 2019 04:52:34 GMT -->
</html>