 <?php include"Top.php"; ?>
	
	 <div class="page-content">
	 	<form method="post" id="myform" name="myform">
		<script>
			$(document).ready(function() 
			{
				$("#btnSave").click(function() 
				{
					var cnt = 0;
					var Element = ['VehName', 'VehNo', 'VehStatus'];
					
					for (i = 0; i < Element.length; i++)
					{
						var txtName = "txt" + Element[i];
						var lblName = "lbl" + Element[i];
						var Value = document.getElementById(txtName).value;
						
						if ( Value == "")
						{
							cnt++;
							document.getElementById(lblName).innerText = "*Required";
						}
						else
						{
							document.getElementById(lblName).innerText = "*";
						}
					}
					
					if (cnt == 0) 
					{
						var Id = document.getElementById("txtId").value;
						var Ch = "";
						if (Id != "")
						{
							Ch = "Edit";
						}
						else
						{
							Ch = "Add";
						}
						
						 var form_data = new FormData(document.getElementById("myform"));
						  form_data.append("label", "WEBUPLOAD");
						  $.ajax({
							  url: "Code/ManageVehicle.php?Choice=" + Ch,
							  type: "POST",
							  data: form_data,
							  processData: false,  // tell jQuery not to process the data
							  contentType: false   // tell jQuery not to set contentType
						  }).done(function( data ) {
							console.log(data);
							$('#myform')[0].reset();
							ShowData();
							//Perform ANy action after successfuly post data
							   
						  });
					}
				});
			});
			
			function Delete(DelId)
			{
				var Result = confirm('Are You Sure Want to Delete...');
				if (Result == true)
				{
					$.post("Code/ManageVehicle.php", 
					{
						Id: DelId,
						Choice: "Delete"
					}, 
					function(data) 
					{
						alert(data);
						$('#myform')[0].reset(); // To reset form fields
						ShowData();
					})
				}
			}
			
			function ShowData()
			{
				$('#Disp').load('Code/ManageVehicle.php?Choice=Show');
			}
			
			function Clear()
			{
				document.getElementById("txtId").value = "";
			}
			
			function Update(Id, Name, No, Status)
			{
				document.getElementById("txtId").value = Id;
				document.getElementById("txtVehName").value = Name;
				document.getElementById("txtVehNo").value = No;
				document.getElementById("txtVehStatus").value = Status;
			}
		</script>
		
		
			<input type="hidden" id="txtId" name="txtId" value="" />
			<div class="clearfix">
			</div>
			<div class="content">
				<div class="row">
					<div class="col-md-6">
						<div class="grid simple">
							<div class="grid-title no-border">
								<h4>Add Vehicle</h4>
							</div>
							<div class="grid-body no-border">
								 <div class="row">
								 	<div class="col-md-6">
										<div class="form-group">
											<label style="font-weight:bold">Vehicle No <span style="color:red" id="lblVehNo">*</span></label>
											<div class="control">
												<input type="text" name="txtVehNo" id="txtVehNo" placeholder="Enter Vehicle No" 
													   class="form-control" />
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label style="font-weight:bold">Vehicle Name <span style="color:red" id="lblVehName">*</span></label>
											<div class="control">
												<input type="text" name="txtVehName" id="txtVehName" placeholder="Enter Vehicle Name" 
													   class="form-control" />
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label style="font-weight:bold">Vehicle Status <span style="color:red" id="lblVehStatus">*</span></label>
											<div class="control">
												<select name="txtVehStatus" id="txtVehStatus" class="form-control" >
													<option value="">Select Status</option>
													<option value="Continue">Continue</option>
													<option value="Repair">Repair</option>
													<option value="Sold">Sold</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
										<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
									</div>
								 </div>   
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="grid simple">
							<div class="grid-title no-border">
								<h4>Show Vehicle</h4>
							</div>
							<div class="grid-body no-border">
								<div class="table-responsive">
									<table class="table">
										<tr>
											<th>Vehicle No</th>
											<th>Vehicle Name</th>
											<th>Status</th>
											<th>Action</th>
										</tr>
										<tbody id="Disp">
										
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
	<script>
		ShowData();
	</script>
<?php include"Bottom.php"; ?>