 <?php include"Top.php"; ?>
 
 <script>
 	$(document).ready(function() 
	{
		$("#btnSave").click(function() 
		{
			var cnt = 0;
			var Element = ['Customer', 'Deposit', 'Contact','Address'];
			
			for (i = 0; i < Element.length; i++)
			{
				var txtName = "txt" + Element[i];
				var lblName = "lbl" + Element[i];
				var Value = document.getElementById(txtName).value;
				
				if ( Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
			}
			
			if (cnt == 0) 
			{
				var Id = document.getElementById("txtId").value;
				var Ch = "";
				if (Id != "")
				{
					Ch = "Edit";
				}
				else
				{
					Ch = "Add";
				}
				
				 var form_data = new FormData(document.getElementById("myform"));
				  form_data.append("label", "WEBUPLOAD");
				  $.ajax({
					  url: "Code/ManageCustomer.php?Choice=" + Ch,
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
				  }).done(function( data ) {
					console.log(data);
					$('#myform')[0].reset();
					ShowData();
					//Perform ANy action after successfuly post data
					   
				  });
			}
		});
		
	});
	
	$(document).ready(function() 
	{
		$("#btnSavePs").click(function() 
		{
			var cnt = 0;
			var Length = document.getElementById("txtLength").value;
			
			for (i=1; i <= Length; i++)
			{
				var txtName = "txtProPrice" + i;
				var lblName = "lblProName" + i;
				
				var Value = document.getElementById(txtName).value;
				
				if (Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
				
			}
			
			if (cnt == 0) 
			{
				 var form_data = new FormData(document.getElementById("myform"));
				  form_data.append("label", "WEBUPLOAD");
				  $.ajax({
					  url: "Code/ManagePriceSetting.php?Choice=ChangeProductPrice",
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
				  }).done(function( data ) {
					console.log(data);
					//$('#myform')[0].reset();
					//Perform ANy action after successfuly post data
					   
				  });
			}
		});
		
	});
	
	
	
	function Delete(DelId)
	{
		var Result = confirm('Are You Sure Want to Delete...');
		if (Result == true)
		{
			$.post("Code/ManageCustomer.php", 
			{
				Id: DelId,
				Choice: "Delete"
			}, 
			function(data) 
			{
				alert(data);
				ShowData();
			})
		}
	}
	
	
	function Edit(CustId, FullName, Cno, Address, RouteId, Status, CustType, Deposit)
	{
		document.getElementById("txtId").value = CustId;
		document.getElementById("txtCustomer").value = FullName;
		document.getElementById("txtContact").value = Cno;
		document.getElementById("txtAddress").value = Address;
		document.getElementById("txtRoute").value = RouteId;
		document.getElementById("txtStatus").value = Status;
		document.getElementById("txtType").value = CustType;
		document.getElementById("txtDeposit").value = Deposit;
	}
	
	function ShowData()
	{
		$('#Disp').load('Code/ManageCustomer.php?Choice=Show');
	}
	
	function ShowPrice(Id)
	{
		$('#DispPrice').load('Code/ManagePriceSetting.php?Choice=ShowCustomerProductPrice&Id=' + Id);
	}
 </script>
 
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
			<input type="hidden" id="txtId" name="txtId" value="" />
			<input type="hidden" name="txRouteName" id="txtRouteName">
			
			<div class="row">
				<div class="col-md-12">
					<div class="grid simple">
						<div class="grid-title no-border">
							<h4>Customer <span class="semi-bold">Details</span></h4>
						</div>
						<div class="grid-body no-border">
							<a href="#" data-toggle="modal" data-target="#AddCustomer" class="btn btn-primary btn-cons">Add</a>
							<button type="button" name="btnExcel" onclick="tableToExcel('myTable', 'W3C Example Table')" id="btnExcel" class="btn btn-primary btn-cons">Export to Excel</button>
							<table width="100%">
								<tr>
									<td width="50%">
										<input type="text" id="txtSearch" style="width:95%" onkeyup="myFunction(0)" class="form-control" 
											   placeholder="Search By Name">		
									</td>
									<td width="50%">
										<select name="drpRoutName" onChange="myFunction(3)" id="drpRoutName" class="form-control">
											<option value="">Select Route</option>
											<?php
												try
												{
													$conec = new Connection();
													$con = $conec->Open();
													if($con)
													{
														$sql = "SELECT * FROM rout order by RoutName";
														$re  = $con->query($sql);
														foreach ($con->query($sql) as $row) 
														{										
											?>	
															<option value="<?php echo $row['RoutId']; ?>">
																<?php echo $row['RoutName']; ?>
															</option>
											<?php													
														}
													}
													else
													{
														echo $con;
													}
												}
												catch(PDOException $ex)
												{
													echo "Error:<br>".$ex->getMessage();
												}
											?>
										</select>					
									</td>
								</tr>
							</table>
							<br><br>
							<div class="table-responsive">
								<table class="table" id="myTable">
									<tr>
										<th>Name</th>
										<th width="100px">Contact No</th>
										<th width="250px">Address</th>
										<th>Route</th>
										<th>Type</th>
										<th>Deposit</th>
										<th>Status</th>
										<th width="130px">Action</th>
									</tr>
									<tbody id="Disp">
									
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Modal -->
		  <div class="modal fade" id="AddCustomer" role="dialog">
			<div class="modal-dialog">
			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Customer Details</h4>
				</div>
				<div class="modal-body">
				  <div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Customer Type <span style="color:red" id="lblType">*</span></label>
									<div class="control">
										<select name="txtType" id="txtType" class="form-control" >
											<option value="Daily">Daily</option>
											<option value="Loose">Loose</option>
											<option value="Cash">Cash</option>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Customer Name <span style="color:red" id="lblCustomer">*</span></label>
									<div class="control">
										<input type="text" name="txtCustomer" id="txtCustomer" placeholder="Enter Customer Name" class="form-control" />
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Contact No <span style="color:red" id="lblContact">*</span></label>
									<div class="control">
										<input type="text" name="txtContact" id="txtContact" placeholder="Enter Contact No" class="form-control" />
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Deposit <span style="color:red" id="lblDeposit">*</span></label>
									<div class="control">
										<input type="text" name="txtDeposit" id="txtDeposit" placeholder="Enter Deposite" class="form-control" />
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label style="font-weight:bold">Address <span style="color:red" id="lblAddress">*</span></label>
									<div class="control">
										<textarea name="txtAddress" id="txtAddress" placeholder="Enter Address" class="form-control" ></textarea>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Rout <span style="color:red" id="lblStatus">*</span></label>
									<div class="control">
										<select name="txtRoute" id="txtRoute" class="form-control" >
											<?php
												try
												{
													$conec = new Connection();
													$con = $conec->Open();
													if($con)
													{
														$sql = "SELECT * FROM rout order by RoutName desc";
														$re  = $con->query($sql);
														foreach ($con->query($sql) as $row) 
														{										
											?>	
															<option value="<?php echo $row['RoutId']; ?>">
																<?php echo $row['RoutName']; ?>
															</option>
											<?php													
														}
													}
													else
													{
														echo $con;
													}
												}
												catch(PDOException $ex)
												{
													echo "Error:<br>".$ex->getMessage();
												}
											?>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Status <span style="color:red" id="lblStatus">*</span></label>
									<div class="control">
										<select name="txtStatus" id="txtStatus" class="form-control" >
											<option value="Continue">Continue</option>
											<option value="Finish">Finish</option>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
								<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
							</div>
						</div>
					</div>
				  </div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div>
		  
		   <!-- Modal -->
		  <div class="modal fade" id="PriceSetting" role="dialog">
			<div class="modal-dialog">
			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Prices</h4>
				</div>
				<div class="modal-body">
				  <div class="row" id="DispPrice">
				  
				  </div>
				  <button type="button" name="btnSavePs" id="btnSavePs" class="btn btn-primary btn-cons">Save</button>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			  
			</div>
		  </div>

		</form>
	</div>
</div>

<script>
	function myFunction(ch) {
	  var input, filter, table, tr, td, i, txtValue;
	  if (ch == 0)
	  {
		input = document.getElementById("txtSearch");
	  }
	  else
	  {
		var Drp = document.getElementById("drpRoutName");
		document.getElementById("txtRouteName").value = Drp.options[Drp.selectedIndex].text;
		input = document.getElementById("txtRouteName");
	  }
	  
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");
	  
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[ch];
		if (td) {
		  txtValue = td.textContent || td.innerText;
		  if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}       
	  }
	}
	ShowData();
</script>
<?php include"Bottom.php"; ?>