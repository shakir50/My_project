 <?php include"Top.php"; ?>
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Simple <span class="semi-bold">Elemets</span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="row">
							
						</div>


    
					</div>
				</div>
			</div>
		</div>
		</form>
	</div>
</div>
<?php include"Bottom.php"; ?>