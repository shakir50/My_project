<?php
	
	session_start();
	if (isset($_SESSION['AdminId']))
	{
		include"../Config/Connection.php";
	}
	else
	{
	?>
		<script>window.location.href='index.php';</script>
	<?php
	}
?>
<!DOCTYPE html>
<html>
<!-- Mirrored from webarch.revox.io/3.0/html/blank_template.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Jun 2019 04:52:34 GMT -->
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
	<link rel='stylesheet' href='../all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
	<script src="../jquery.min.js"></script>
	<link rel = "icon" href="../Icon/Icon.ico" type = "image/x-icon"> 
    <title>Indian RO Water Suplier</title>
	<link rel="stylesheet" href="../fontawesome/css/all.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="" name="description" />
    <meta content="" name="author" />
	<script src="tableToExcel.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="../../cdn-cgi/apps/head/QJpHOqznaMvNOv9CGoAdo_yvYKU.js"></script>
    <link href="../assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css"
        media="screen" />
    <link href="../assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="../assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet"
        type="text/css" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="../assets/plugins/animate.min.css" rel="stylesheet" type="text/css" />
    <link href="../assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet"
        type="text/css" />
    <link href="../webarch/css/webarch.css" rel="stylesheet" type="text/css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="../assets/js/icon.js" type="text/javascript"></script>
  <script src="https://kit.fontawesome.com/4b0c027abd.js"></script>
  <script>
  	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57)) {
			return false;
		}
		return true;
	}
  </script>
</head>
<body class="">
	<?php
		if ($_SESSION['Photo'] == "")
		{
			$Path = "../Icon/Profile.png";
		} 
		else
		{
			$Path = "AdminPhoto/".$_SESSION['Photo'];
		}
	?>
    <div class="header navbar navbar-inverse ">
        <div class="navbar-inner">
            <div class="header-seperation">
                <ul class="nav pull-left notifcation-center visible-xs visible-sm">
                    <li class="dropdown"><a href="#main-menu" data-webarch="toggle-left-side"><i class="material-icons">
                        menu</i> </a></li>
                </ul>
                <a href="#">
				
					<img src="../Icon/Icon.png" class="logo" alt="" data-src="../Icon/Icon.png"
                        data-src-retina="../Icon/Icon.png" width="60" height="30" />
						<font size="+1" color="white">Ro Water Supplier</font>
                </a>
                <ul class="nav pull-right notifcation-center">
                    <li class="dropdown visible-xs visible-sm">
						<div class="dropdown">
							  <a class="dropbtn">
							  	<i class="fas fa-users-cog"></i>
							  </a>
							  <div class="dropdown-content" style="text-align:left">
								<a href="#" data-toggle="modal" data-target="#ChangeProfile">
									<img src="../Icon/Profile.png" style="height:25px; width:25px">&nbsp;<b>Profile</b>
								</a><br>
								<a href="#" data-toggle="modal" data-target="#ChangePassword">
									<img src="../Icon/ChangePassword.png" style="height:25px; width:25px">&nbsp;<b>Setting</b></a><br>
								<a href="#" onClick="ConfirmLogout();"><img src="../Icon/logout-icon-14-256.png" style="height:25px; width:25px">&nbsp;<b>Logout</b></a>
							  	
							  </div>
							</div>
					</li>
                </ul>
            </div>
            <div class="header-quick-nav">
                <div class="pull-left">
                    <ul class="nav quick-section">
                        <li class="quicklinks"><a href="#" class="" id="layout-condensed-toggle"><i class="material-icons">
                            menu</i> </a></li>
                    </ul>
                    <ul class="nav quick-section">
                        <li class="quicklinks  m-r-10"><a href="#" class=""><i class="material-icons">refresh</i>
                        </a></li>
                        <li class="quicklinks"><a href="#" class=""><i class="material-icons">apps</i> </a>
                        </li>
                        <li class="quicklinks"><span class="h-seperate"></span></li>
                       
                    </ul>
                </div>
                <div id="notification-list" style="display: none">
                    <div style="width: 300px">
                        <div class="notification-messages info">
                            <div class="user-profile">
                                <img src="../assets/img/profiles/d.jpg" alt="" data-src="../assets/img/profiles/d.jpg"
                                    data-src-retina="../assets/img/profiles/d2x.jpg" width="35" height="35">
                            </div>
                            <div class="message-wrapper">
                                <div class="heading">
                                    David Nester - Commented on your wall
                                </div>
                                <div class="description">
                                    Meeting postponed to tomorrow
                                </div>
                                <div class="date pull-left">
                                    A min ago
                                </div>
                            </div>
                            <div class="clearfix">
                            </div>
                        </div>
                       
                    </div>
                </div>
                <div class="pull-right">
                   	<ul class="nav quick-section">
                       <li class="quicklinks">
							<div class="dropdown">
							  <a class="dropbtn">
							  	
							  	<img src="<?php echo $Path; ?>" style="border-radius: 50%;height:40px;width:40px">&nbsp;<?php echo $_SESSION['FullName']; ?>
							  </a>
							  <div class="dropdown-content" style="text-align:left">
								<a href="#" data-toggle="modal" data-target="#ChangeProfile">
									<img src="../Icon/Profile.png" style="height:25px; width:25px">&nbsp;<b>Profile</b>
								</a>
								<a href="#" data-toggle="modal" data-target="#ChangePassword">
									<img src="../Icon/ChangePassword.png" style="height:25px; width:25px">&nbsp;<b>Setting</b></a>
								<a href="#" onClick="ConfirmLogout();"><img src="../Icon/logout-icon-14-256.png" style="height:25px; width:25px">&nbsp;<b>Logout</b></a>
							  	
							  </div>
							</div>
						</li>
					</ul>
                </div>
            </div>
        </div>
    </div>
	<script>
		function ConfirmLogout()
		{
			var res = confirm('Are You Sure Want to Logout..!');
			if (res == true)
			{
				window.location.href = "Logout.php";
			}
		}
	</script>
<style>
	.dropdown {
	  position: relative;
	  display: inline-block;
	}
	
	.dropdown-content {
	  display: none;
	  position: absolute;
	  background-color: #f1f1f1;
	  min-width: 160px;
	  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
	  z-index: 1;
	}
	
	.dropdown-content a {
	  color: black;
	  padding: 12px 16px;
	  text-decoration: none;
	  display: block;
	}
	
	.dropdown-content a:hover {background-color: #ddd;}
	
	.dropdown:hover .dropdown-content {display: block;}
</style>
	
    <div class="page-container row-fluid">
        <div class="page-sidebar " id="main-menu">
            <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
                <div class="user-info-wrapper sm">
                    <div class="profile-wrapper sm">
                        <img src="<?php echo $Path; ?>" alt="" data-src="<?php echo $Path; ?>"
                            data-src-retina="<?php echo $Path; ?>" width="69" height="69" />
                        <div class="availability-bubble online">
                        </div>
                    </div>
                    <div class="user-info sm">
                        <div class="username">
                        	<?php echo $_SESSION['FullName']; ?>
						</div>
                        <div class="status">
                            Life goes on...</div>
                    </div>
                </div>
                <p class="menu-title sm">
                    Menu<span class="pull-right"><a href="javascript:;"><i class="material-icons">refresh</i></a></span></p>
                <ul>
					<li><a href="javascript:;"><span class="title"><i class='fas fa-table'></i>&nbsp; Master Data</span> <span class=" arrow"></span></a>
                        <ul class="sub-menu">
                            <li>
								<a href="Rout.php"><span class="title">Route</span></a>
							</li>
							<li>
								<a href="EmployeDetail.php"><span class="title">Employee</span></a>
							</li>
							<li>
								<a href="VehicleDetail.php"><span class="title">Vehicle</span></a>
							</li>
                        </ul>
                    </li>
                   <li><a href="javascript:;"><span class="title"><i class='fas fa-users'></i>&nbsp; Manage Customer</span> <span class=" arrow"></span></a>
                        <ul class="sub-menu">
                            <li>
								<a href="Customer.php"><span class="title">New Customer</span></a>
							</li>
							<li>
								<a href="CustomerSequence.php"><span class="title">Customer Sequence</span></a>
							</li>
                        </ul>
                    </li>
                  	<li><a href="javascript:;"><span class="title"><i class="fas fa-tint"></i>&nbsp;Manage Product</span> <span class=" arrow"></span></a>
                        <ul class="sub-menu">
                            <li>
								<a href="Product.php"><span class="title">Product</span></a>
							</li>
							<li>
								<a href="Stock.php"><span class="title">Stock</span></a>
							</li>
                        </ul>
                    </li>
				  	<li><a href="javascript:;"><span class="title"><i class="fas fa-tasks"></i>&nbsp;Manage Task</span> <span class=" arrow"></span></a>
                        <ul class="sub-menu">
                            <li>
								<a href="TaskMaster.php"><span class="title">Task</span></a>
							</li>
							<li>
								<a href="CreateTask.php"><span class="title">Create Task</span></a>
							</li>
							<li>
								<a href="ShowCreateTask.php"><span class="title">Task List</span></a>
							</li>
                        </ul>
                    </li>
					<li><a href="javascript:;"><span class="title"><i class="far fa-clipboard"></i>&nbsp;Manage Issue/Return</span> <span class=" arrow"></span></a>
                        <ul class="sub-menu">
                            <li>
								<a href="ProductIssueList.php"><span class="title">Issue List</span></a>
							</li>
							<li>
								<a href="ProductIssueList.php"><span class="title">Return</span></a>
							</li>
							
                        </ul>
                    </li>
					<li><a href="javascript:;"><span class="title"><i class='fas fa-rupee-sign'></i>&nbsp;Inventory</span> <span class=" arrow"></span></a>
                        <ul class="sub-menu">
                            <li>
								<a href="CreateReceipt.php"><span class="title">Generate Receipt</span></a>
							</li>
							<li>
								<a href="BillsReceivable.php"><span class="title">Bills Receivable</span></a>
							</li>
							<li>
								<a href="ExpenseType.php"><span class="title">Expense Type</span></a>
							</li>
							<li>
								<a href="Expense.php"><span class="title">Expense</span></a>
							</li>
                        </ul>
                    </li>
					<li>
						<a href="AdminUser.php"><span class="title"><i class="fas fa-users-cog"></i>&nbsp;Admin User</span></a>
					</li>
					<li><a href="javascript:;"><span class="title"><i class="fas fa-file-invoice"></i>&nbsp;Reports</span> <span class=" arrow"></span></a>
                        <ul class="sub-menu">
                            <li>
								<a href="IssueReport.php"><span class="title">Issue Report</span></a>
							</li>
							<li>
								<a href="ReceiptReport.php"><span class="title">Bills Report</span></a>
							</li>
							<li>
								<a href="AmountReceivedReport.php"><span class="title">Amount Received Report</span></a>
							</li>
							<li>
								<a href="DemageReport.php"><span class="title">Demage Report</span></a>
							</li>
							<li>
								<a href="ExpenseReport.php"><span class="title">Expense Report</span></a>
							</li>
							<li>
								<a href="#"><span class="title">Employee Report</span></a>
							</li>
							
						</ul>
                    </li>
                </ul>
               
            </div>
        </div>
        