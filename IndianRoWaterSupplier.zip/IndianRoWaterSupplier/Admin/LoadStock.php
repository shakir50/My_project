 <?php include"Top.php"; ?>
 
  	<script>
  		$(document).ready(function() 
		{
			$("#btnSave").click(function() 
			{
				var cnt = 0;
				var Length = document.getElementById("txtLength").value;
				
				for (i=1; i < Length; i++)
				{
					var chkName = "chk" + i;
					if (document.getElementById(chkName).checked == true)
					{
						cnt++;
					}				
				}
				
				if (cnt == 0) 
				{
					document.getElementById("lblStock").innerText = "*Required";
				}
				else
				{
					var form_data = new FormData(document.getElementById("myform"));
					form_data.append("label", "WEBUPLOAD");
				 
					$.ajax({
					  url: "Code/ManageCreateTask.php?Choice=AddLoadStock&DTId=<?php echo $_REQUEST['DTId']; ?>",
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
					}).done(function( data ) {
					console.log(data);
					alert(data);
					//$('#myform')[0].reset();
					//Perform ANy action after successfuly post data   
				  	});
					document.getElementById("lblStock").innerText = "*";
				}
			});
		});
 	</script>
 
 <script>
 	function ShowData()
	{
		var Id = document.getElementById("drpPro").value;
		var TaskId= "<?php echo $_REQUEST['DTId']; ?>";
		$('#disp').load('Code/ManageCreateTask.php?Choice=LoadStock&ProId=' + Id + '&txtDTId=' + TaskId);
	}
 </script>
 <div class="page-content">
	<div class="clearfix">
	</div>
	
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Load<span class="semi-bold">Stock <span id="lblStock" style="color:red">*</span></span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Select Product <span style="color:red" id="lblProduct">*</span></label>
									<div class="control">
										<select name="drpPro" id="drpPro" onChange="ShowData();" class="form-control">
											<?php
												try
												{
													$conec = new Connection();
													$con = $conec->Open();
													if($con)
													{
														$sql = "SELECT * FROM productmaster order by ProName desc";
														$re  = $con->query($sql);
														foreach ($con->query($sql) as $row) 
														{										
											?>	
															<option value="<?php echo $row['ProId']; ?>"><?php echo $row['ProName']; ?></option>
											<?php													
														}
													}
													else
													{
														echo $con;
													}
												}
												catch(PDOException $ex)
												{
													echo "Error:<br>".$ex->getMessage();
												}
											?>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Code<span style="color:red" id="lblProduct">*</span></label>
									<div class="control">
										<input type="text" name="txtSearch" onkeyup="myFunction()" id="txtSearch" class="form-control" />
									</div>
								</div>
							</div>
						</div>
						<div class="row" id="disp">
							
						</div>  
						<div class="row">
							<div class="col-md-12">
								<br>
								<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
								<a class="btn btn-primary btn-cons" href="ShowCreateTask.php" >Back</a>
							</div>
						</div> 
					</div>
					
				</div>
			</div>
		</div>
		
		</form>
	</div>
</div>
	<script>
		function myFunction() 
		{
			var input, filter, Div, i, txtValue;
			input = document.getElementById("txtSearch");
			filter = input.value.toUpperCase();
			var Length = document.getElementById("txtLength").value;
			
			for (i = 1; i <= Length; i++) 
			{
				Div = document.getElementById("Div" + i);
				if (Div) 
				{
					txtValue = Div.textContent || Div.innerText;
					if (txtValue.toUpperCase().indexOf(filter) > -1) 
					{
						Div.style.display = "";
					} 
					else
					{
						Div.style.display = "none";
					}
				}       
			}
		}
	</script>

<script>
	ShowData();
</script>
<?php include"Bottom.php"; ?>