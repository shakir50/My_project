 <?php include"Top.php"; ?>
 
 <script>
 	function getCustomer(val) {
		$.ajax({
		type: "POST",
		url: "Code/ManageCustomer.php?Choice=PopulateCustomer",
		data:'RouteId='+val,
		success: function(data){
			$("#txtCustomer").html(data);
		}
		});
	}
	$(document).ready(function() 
	{
		$("#btnSave").click(function() 
		{
			var cnt = 0;
			var Element = ['Customer', 'Route'];
			
			for (i = 0; i < Element.length; i++)
			{
				var txtName = "txt" + Element[i];
				var lblName = "lbl" + Element[i];
				var Value = document.getElementById(txtName).value;
				
				if ( Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
			}
			
			if (cnt == 0) 
			{
				var RouteId = document.getElementById("txtRoute").value;
				var form_data = new FormData(document.getElementById("myform"));
				  form_data.append("label", "WEBUPLOAD");
				  $.ajax({
					  url: "Code/ManageCustomerSequence.php?Choice=Add",
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
				  }).done(function( data ) {
					console.log(data);
					getCustomer(RouteId);
					ShowData();
					//Perform ANy action after successfuly post data
					   
				  });
			}
		});
	});
	
	$(document).ready(function() 
	{
		$("#btnSaveSeq").click(function() 
		{
			var cnt = 0;
			var tableLength = document.getElementById("myTable").rows.length;
			document.getElementById("txtTableLength").value = tableLength;
			for (i=1; i < tableLength; i++)
			{
				var txtName = "txtSeqNo" + i;
				Value = document.getElementById(txtName).value;
				
				if (Value == "")
				{
					cnt++;
					$("#" + txtName).css("border", "1px solid red");
				}
				else
				{
					$("#" + txtName).css("border", "1px solid black");
				}
			}
			
			if (cnt == 0)
			{
				var form_data = new FormData(document.getElementById("myform"));
				  form_data.append("label", "WEBUPLOAD");
				 
					$.ajax({
					  url: "Code/ManageCustomerSequence.php?Choice=Edit",
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
					}).done(function( data ) {
					console.log(data);
					ShowData();
					//Perform ANy action after successfuly post data   
				  });
			}
			
		});
	});
	
	
	function ShowData()
	{
		var Id = document.getElementById("drpRoute").value;
		$('#Disp').load('Code/ManageCustomerSequence.php?Choice=Show&Id='+Id);
	}
	
	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57)) {
			return false;
		}
		return true;
	}
 </script>
 
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
			<input type="hidden" id="txtTableLength" name="txtTableLength" />
			<div class="row">
				<div class="col-md-12">
					<div class="grid simple">
						<div class="grid-title no-border">
							<h4>Customer<span class="semi-bold"> Sequence</span></h4>
						</div>
						<div class="grid-body no-border">
							<div class="row">
								<div class="col-md-12">
									<a href="#" data-toggle="modal" data-target="#AddCustomer" class="btn btn-primary btn-cons">Add Customer</a>
									<button type="button" name="btnSaveSeq" id="btnSaveSeq" class="btn btn-primary btn-cons">Save</button>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label style="font-weight:bold">Route </label>
										<div class="control">
											<select name="drpRoute" onchange="ShowData()" id="drpRoute" class="form-control" >
												<option value="0">Select Route</option>
												<?php
													try
													{
														$conec = new Connection();
														$con = $conec->Open();
														if($con)
														{
															$sql = "SELECT * FROM rout order by RoutName desc";
															$re  = $con->query($sql);
															foreach ($con->query($sql) as $row) 
															{										
												?>	
																<option value="<?php echo $row['RoutId']; ?>">
																	<?php echo $row['RoutName']; ?>
																</option>
												<?php													
															}
														}
														else
														{
															echo $con;
														}
													}
													catch(PDOException $ex)
													{
														echo "Error:<br>".$ex->getMessage();
													}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="table-responsive">
										<table class="table" id="myTable">
											<tr>
												<th width="120px">Sequence No</th>
												<th>Customer Name</th>
											</tr>
											<tbody id="Disp">
												
											</tbody>
										</table>
									</div>
								</div>
							</div>    
						</div>
					</div>
				</div>
			</div>
			
			<div class="modal fade" id="AddCustomer" role="dialog">
			<div class="modal-dialog">
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Add Customer for Sequence</h4>
				</div>
				<div class="modal-body">
				  <div class="row">
				  	<div class="col-md-12">
						<div class="form-group">
							<label style="font-weight:bold">Route <span style="color:red" id="lblRoute">*</span></label>
							<div class="control">
								<select name="txtRoute" onchange="getCustomer(this.value)" id="txtRoute" class="form-control" >
									<option value="">Select Route</option>
									<?php
										try
										{
											$conec = new Connection();
											$con = $conec->Open();
											if($con)
											{
												$sql = "SELECT * FROM rout order by RoutName desc";
												$re  = $con->query($sql);
												foreach ($con->query($sql) as $row) 
												{										
									?>	
													<option value="<?php echo $row['RoutId']; ?>">
														<?php echo $row['RoutName']; ?>
													</option>
									<?php													
												}
											}
											else
											{
												echo $con;
											}
										}
										catch(PDOException $ex)
										{
											echo "Error:<br>".$ex->getMessage();
										}
									?>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label style="font-weight:bold">Customer <span style="color:red" id="lblCustomer">*</span></label>
							<div class="control">
								<select name="txtCustomer" id="txtCustomer" class="form-control" >
									<option value="">Select Customer</option>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
						<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
					</div>
				  </div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			  
			</div>
		  </div>

			
		</form>
	</div>
</div>
<?php include"Bottom.php"; ?>