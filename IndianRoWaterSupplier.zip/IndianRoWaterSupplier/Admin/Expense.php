 <?php include"Top.php"; ?>
 
 <script>
 	$(document).ready(function() 
	{
		$("#btnSave").click(function() 
		{
			var cnt = 0;
			var Element = ['Type', 'BillNo', 'ExpFor', 'Amount', 'Date', 'Desc'];
			
			for (i = 0; i < Element.length; i++)
			{
				var txtName = "txt" + Element[i];
				var lblName = "lbl" + Element[i];
				var Value = document.getElementById(txtName).value;
				
				if ( Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
			}
			
			if (cnt == 0) 
			{
				var Id = document.getElementById("txtId").value;
				var Ch = "";
				if (Id != "")
				{
					Ch = "Edit";
				}
				else
				{
					Ch = "Add";
				}
				
				 var form_data = new FormData(document.getElementById("myform"));
				  form_data.append("label", "WEBUPLOAD");
				  $.ajax({
					  url: "Code/ManageExpense.php?Choice=" + Ch,
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
				  }).done(function( data ) {
					console.log(data);
					$('#myform')[0].reset();
					ShowData();
					//Perform ANy action after successfuly post data
					   
				  });
			}
		});
		
	});

	
	
	
	function Delete(DelId)
	{
		var Result = confirm('Are You Sure Want to Delete...');
		if (Result == true)
		{
			$.post("Code/ManageExpense.php", 
			{
				Id: DelId,
				Choice: "Delete"
			}, 
			function(data) 
			{
				alert(data);
				ShowData();
			})
		}
	}
	
	function Edit(ExpId, Type, BillNo, ExpFor, Amount, ExpDate, Desc)
	{
		document.getElementById("txtId").value = ExpId;
		document.getElementById("txtType").value = Type;
		document.getElementById("txtBillNo").value = BillNo;
		document.getElementById("txtExpFor").value = ExpFor;
		document.getElementById("txtAmount").value = Amount;
		document.getElementById("txtDate").value = ExpDate;
		document.getElementById("txtDesc").value = Desc;
	}
	
	function ShowData()
	{
		$('#Disp').load('Code/ManageExpense.php?Choice=Show');
	}
	
	
 </script>
 
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
			<input type="hidden" id="txtId" name="txtId" value="" />
			<input type="hidden" name="txtExpType" id="txtExpType">
			
			<div class="row">
				<div class="col-md-12">
					<div class="grid simple">
						<div class="grid-title no-border">
							<h4>Expenses <span class="semi-bold">List</span></h4>

						</div>
						<div class="grid-body no-border">
							<a href="#" data-toggle="modal" data-target="#AddExpense" class="btn btn-primary btn-cons">Add</a>
							<button type="button" name="btnExcel" onClick="tableToExcel('myTable', 'W3C Example Table')" id="btnExcel" class="btn btn-primary btn-cons">Export to Excel</button>
							<table width="100%">
								<tr>
									<td width="50%">
										<input type="text" id="txtSearch" style="width:95%" onKeyUp="myFunction(3)" class="form-control" 
											   placeholder="Search By Name">		
									</td>
									<td width="50%">
										<select name="drpExpType" onChange="myFunction(1)" id="drpExpType" class="form-control">
											<option value="">Select Type</option>
											<?php
												try
												{
													$conec = new Connection();
													$con = $conec->Open();
													if($con)
													{
														$sql = "SELECT * FROM expensetype order by ExpTypeName";
														$re  = $con->query($sql);
														foreach ($con->query($sql) as $row) 
														{										
											?>	
															<option value="<?php echo $row['ExpTypeId']; ?>">
																<?php echo $row['ExpTypeName']; ?>
															</option>
											<?php													
														}
													}
													else
													{
														echo $con;
													}
												}
												catch(PDOException $ex)
												{
													echo "Error:<br>".$ex->getMessage();
												}
											?>
										</select>					
									</td>
								</tr>
							</table>
							<br><br>
							<div class="table-responsive">
								<table class="table" id="myTable">
									<tr>
										<th>Sr. No</th>
										<th>Expense Type</th>
										<th>Bill No</th>
										<th>Expense For</th>
										<th>Amount</th>
										<th width="200px">Description</th>
										<th width="100px">Exp. Date</th>
										<th>Transect Time</th>
										<th width="130px">Action</th>
									</tr>
									<tbody id="Disp">
									
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Modal -->
		  <div class="modal fade" id="AddExpense" role="dialog">
			<div class="modal-dialog">
			
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">New Expense</h4>
				</div>
				<div class="modal-body">
				  <div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Expense Type <span style="color:red" id="lblType">*</span></label>
									<div class="control">
										<select name="txtType" id="txtType" class="form-control">
											<option value="">Select Expense Type</option>
											<?php
												$Query = "SELECT * FROM `expensetype` order by ExpTypeName";
												$res = mysqli_query($Con, $Query);
												while ($row = mysqli_fetch_array($res))
												{
											?>
													<option value="<?php echo $row['ExpTypeId']; ?>"><?php echo $row['ExpTypeName']; ?></option>
											<?php
												}
											?>
											
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Bill No <span style="color:red" id="lblBillNo">*</span></label>
									<div class="control">
										<input type="text" name="txtBillNo" id="txtBillNo" placeholder="Enter Bill No" class="form-control" />
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Expense For <span style="color:red" id="lblExpFor">*</span></label>
									<div class="control">
										<input type="text" name="txtExpFor" id="txtExpFor" placeholder="Enter Expense For" class="form-control" />
									</div>
								</div>
								<div class="form-group">
									<label style="font-weight:bold">Amount <span style="color:red" id="lblAmount">*</span></label>
									<div class="control">
										<input type="text" name="txtAmount" id="txtAmount" placeholder="Enter Amount" class="form-control" />
									</div>
								</div>
								<div class="form-group">
									<label style="font-weight:bold">Date <span style="color:red" id="lblDate">*</span></label>
									<div class="control">
										<input type="date" name="txtDate" id="txtDate" class="form-control" />
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label style="font-weight:bold">Description <span style="color:red" id="lblDesc">*</span></label>
									<div class="control">
										<textarea name="txtDesc" style="height:200px" id="txtDesc" placeholder="Enter Description" class="form-control" ></textarea>
									</div>
								</div>
							</div>
							
							<div class="col-md-12">
								<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
								<input type="reset" onClick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
							</div>
						</div>
					</div>
				  </div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div>
		  
		 
		</form>
	</div>
</div>

<script>
	function myFunction(ch) {
	  var input, filter, table, tr, td, i, txtValue;
	  if (ch == 3)
	  {
		input = document.getElementById("txtSearch");
	  }
	  else
	  {
		var Drp = document.getElementById("drpExpType");
		document.getElementById("txtExpType").value = Drp.options[Drp.selectedIndex].text;
		input = document.getElementById("txtExpType");
	  }
	  
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");
	  
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[ch];
		if (td) {
		  txtValue = td.textContent || td.innerText;
		  if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}       
	  }
	  if (filter == "SELECT TYPE")
	  {
	  	ResetTable();
	  }
	}
	
	function ResetTable()
	{
		table = document.getElementById("myTable");
	  	tr = table.getElementsByTagName("tr");
		for (i = 0; i < tr.length; i++) 
		{
			tr[i].style.display = "";      
		}
	}
	ShowData();
</script>
<?php include"Bottom.php"; ?>