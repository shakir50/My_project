 <?php include"Top.php"; ?>
 <script>

	function Fiilter() 
	{
		var from = document.getElementById("txtDateFrom").value;
		var to = document.getElementById("txtDateTo").value;
		$('#Disp').load('Code/ManageReport.php?Choice=ShowDamageReport&DateFrom='+from+'&DateTo='+to);	
	}
	
	
 </script>
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Damage Stock <span class="semi-bold">Report</span></h4>
					</div>
					<div class="grid-body no-border">
						<table width="100%">
							<tr>
								<td width="50%">
									<div class="form-group">
										<label style="font-weight:bold">Date From: <span style="color:red" id="lblDateFrom">*</span></label>
										<div class="control">
											<input type="date" name="txtDateFrom" style="width:95%" id="txtDateFrom" class="form-control" />
										</div>
									</div>
								</td>
								<td width="50%">
									<div class="form-group">
										<label style="font-weight:bold">Date To: <span style="color:red" id="lblDateTo">*</span></label>
										<div class="control">
											<input type="date" name="txtDateTo" onChange="Fiilter();" id="txtDateTo" style="width:95%" class="form-control" />
										</div>
									</div>
								</td>
							</tr>
						</table>
						<button type="button" name="btnExcel" onclick="tableToExcel('myTable', 'W3C Example Table')" id="btnExcel" class="btn btn-primary btn-cons">
							Export to Excel
						</button>
						<input type="text" id="txtSearch" onkeyup="myFunction()" class="form-control" placeholder="Search By Name"><br>
						<div class="table-responsive">
							<table class="table" id="myTable">
								<tr>
									<th>Sr. No</th>
									<th>Code</th>
									<th>Product</th>
									<th>Transec Time</th>
									<th>Entry By</th>
								</tr>
								<tbody id="Disp">
								
								</tbody>
							</table>
						</div>    
					</div>
				</div>
			</div>
		</div>

		</form>
	</div>
</div>

<script>
	function ShowData()
	{
		$('#Disp').load('Code/ManageReport.php?Choice=ShowDamageReport');
	}
	ShowData();
	
	function myFunction() {
	  var input, filter, table, tr, td, i, txtValue;
	  input = document.getElementById("txtSearch");
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[1];
		if (td) {
		  txtValue = td.textContent || td.innerText;
		  if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}       
	  }
	 }
	
</script>

<?php include"Bottom.php"; ?>