 <?php include"Top.php"; ?>
 <form method="post" id="myform" name="myform" enctype="multipart/form-data">
 <script>
 	function ShowData()
	{
		$('#Disp').load('Code/ManageEmployee.php?Choice=Show');
	}
	
	function Delete(DelId)
	{
		var Result = confirm('Are You Sure Want to Delete...');
		if (Result == true)
		{
			$.post("Code/ManageEmployee.php", 
			{
				Id: DelId,
				Choice: "Delete"
			}, 
			function(data) 
			{
				alert(data);
				$('#form')[0].reset(); // To reset form fields
				ShowData();
			})
		}
	}
	
	$(document).ready(function() 
	{
		$("#btnSave").click(function() 
		{
			var cnt = 0;
			var Element = ['Employee', 'Contact', 'Adhar','Address'];
			var Values = ['Employee', 'Contact', 'Adhar','Address'];
			for (i = 0; i < Element.length; i++)
			{
				var txtName = "txt" + Element[i];
				var lblName = "lbl" + Element[i];
				var Value = document.getElementById(txtName).value;
				Values[i] = Value;
				if ( Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
			}
			
			if (cnt == 0) 
			{
				var Id = document.getElementById("txtId").value;
				var Ch = "";
				if (Id != "")
				{
					Ch = "Edit";
				}
				else
				{
					Ch = "Add";
				}
				
				 var form_data = new FormData(document.getElementById("myform"));
				  form_data.append("label", "WEBUPLOAD");
				  $.ajax({
					  url: "Code/ManageEmployee.php?Choice=" + Ch,
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
				  }).done(function( data ) {
					console.log(data);
					//this is in the 'success' function for an ajax post
					
					
					
					$('#myform')[0].reset();
					ShowData();
					//Perform ANy action after successfuly post data
					   
				  });
			}
		});
	});
	
	
	function Edit(Id, Name, Cno, Adhar, Address, Photo)
	{
		document.getElementById("txtId").value = Id;
		document.getElementById("txtEmployee").value = Name;
		document.getElementById("txtContact").value = Cno;
		document.getElementById("txtAdhar").value = Adhar;
		document.getElementById("txtAddress").value = Address;
		document.getElementById("txtPhoto").value = Photo;
		document.getElementById("Img1").src = "EmployeePhoto/" + Photo;
	}
	
	function Clear()
	{
		document.getElementById("txtId").value = "";
		document.getElementById("txtPhoto").value = "";
		document.getElementById("Img1").src = "../Icon/PhotoCover.png";
	}
 </script>
 
 <div class="success-popup">Success!</div>
 
 <style>
 	.success-popup{
	  position:absolute;
	  left:50%;
	  margin-left:-150px;
	  width:300px;
	  height:200px;
	  background:green;
	  color:white;
	  z-index:100;
	  display:none;
	}
 </style>
 
 <input type="hidden" id="txtId" name="txtId" value="" />
 <input type="hidden" id="txtPhoto" name="txtPhoto" value="" />
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Manage<span class="semi-bold">Employe</span></h4>
					</div>
					<div class="grid-body no-border">
						<a href="#" data-toggle="modal" data-target="#AddEmployee" class="btn btn-primary btn-cons">Add</a>
						<button type="button" name="btnExcel" onclick="tableToExcel('myTable', 'W3C Example Table')" id="btnExcel" class="btn btn-primary btn-cons">Export to Excel</button>
						<input type="text" id="txtSearch" onkeyup="myFunction()" class="form-control" placeholder="Search By Name">
						<div class="table-responsive">
							
							<table class="table" id="myTable">
								<tr>
									<th></th>
									<th>Employee Name</th>
									<th>Contact No</th>
									<th>Address</th>
									<th>Adhar No</th>
									<th>Action</th>
								</tr>
								<tbody id="Disp">
								
								</tbody>
							</table>
						</div>    
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

 <!-- Modal -->
  <div class="modal fade" id="AddEmployee" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Employee Details</h4>
        </div>
        <div class="modal-body">
          <div class="row">
		  	<div class="col-md-3">
				<div class="row">
					<div class="col-sm-12 col-xl-12 m-b-30">
						<label class="border-checkbox-label" for="checkbox2"></label><br />
						<div id="uploadpic1" class="thumbimg">
							<span onClick="javascript:opendialogbox('imgInp1');">
								<img class="thumb"  id="Img1" src="../Icon/PhotoCover.png" style="height:150px;width:100%">
								<input type="file" accept='image/*' onchange='preview_image(event,"Img1")' id="imgInp1" name="imgInp1" style="visibility:hidden" name="picture" />
							</span>
						</div>	
					</div>
				</div>
			</div>
			<div class="col-md-9">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label style="font-weight:bold">Employee Name <span style="color:red" id="lblEmployee">*</span></label>
							<div class="control">
								<input type="text" name="txtEmployee" id="txtEmployee" placeholder="Enter Employee Name" class="form-control" />
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label style="font-weight:bold">Contact No <span style="color:red" id="lblContact">*</span></label>
							<div class="control">
								<input type="text" name="txtContact" id="txtContact" placeholder="Enter Contact No" class="form-control" />
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label style="font-weight:bold">Adhar No <span style="color:red" id="lblAdhar">*</span></label>
							<div class="control">
								<input type="text" name="txtAdhar" id="txtAdhar" placeholder="Enter Adhar No" class="form-control" />
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label style="font-weight:bold">Address <span style="color:red" id="lblAddress">*</span></label>
							<div class="control">
								<textarea name="txtAddress" id="txtAddress" placeholder="Enter Address" class="form-control" ></textarea>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
						<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
					</div>
				</div>
			</div>
		  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
	
	<script>
		function preview_image(event,id) 
		{
			 var reader = new FileReader();
			 reader.onload = function()
			 {
				  var output = document.getElementById(id);
				  output.src = reader.result;
			 }
			 reader.readAsDataURL(event.target.files[0]);
		}
	
		function opendialogbox(inputid){
			document.getElementById(inputid).click();
		}
		ShowData();
	</script>	

	<script>
		function myFunction() {
		  var input, filter, table, tr, td, i, txtValue;
		  input = document.getElementById("txtSearch");
		  filter = input.value.toUpperCase();
		  table = document.getElementById("myTable");
		  tr = table.getElementsByTagName("tr");
		  for (i = 0; i < tr.length; i++) {
			td = tr[i].getElementsByTagName("td")[1];
			if (td) {
			  txtValue = td.textContent || td.innerText;
			  if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
			  } else {
				tr[i].style.display = "none";
			  }
			}       
		  }
		}
	</script>

</form>

<?php include"Bottom.php"; ?>