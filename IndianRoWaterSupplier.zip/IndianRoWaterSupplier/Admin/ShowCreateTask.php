 <?php include"Top.php"; ?>
 <script>
 	function ShowData()
	{
		$('#Disp').load('Code/ManageCreateTask.php?Choice=Show');
	}
 </script>
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Task<span class="semi-bold">List</span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="table-responsive">
							<table class="table" id="myTable">
								<tr>
									<th>Sr No.</th>
									<th>Task</th>
									<th>Route</th>
									<th>Veh No</th>
									<th>Employee</th>
									<th>Stock</th>
									<th>Date</th>
									<th></th>
								</tr>
								<tbody id="Disp">
									
								</tbody>
							</table>
						</div>    
					</div>
				</div>
			</div>
		</div>
		
		 <script>
				$(document).ready(function() 
				{
					$("#btnSave").click(function() 
					{
						var form_data = new FormData(document.getElementById("myform"));
						form_data.append("label", "WEBUPLOAD");
						$.ajax({
						  url: "Code/ManageCreateTask.php?Choice=ChangeStatus",
						  type: "POST",
						  data: form_data,
						  processData: false,  // tell jQuery not to process the data
						  contentType: false   // tell jQuery not to set contentType
						}).done(function( data ) {
						console.log(data);
						ShowData();
						alert(data);
						//$('#myform')[0].reset();
						//Perform ANy action after successfuly post data   
						});	
					});
				});
		 </script>
		
		<script>
			function GetData(Id, Status)
			{
				document.getElementById("txtDTId").value = Id;
				document.getElementById("drpStatus").value = Status;
			}
		</script>
		 <!-- Modal -->
		<div class="modal fade" id="ChangeStatus" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Task Verification</h4>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="form-label">Change Status To<span style="color:red" id="lblStatus">*</span></label>
									<input type="hidden" name="txtDTId" id="txtDTId" />
									<select class="form-control" id="drpStatus" name="drpStatus">
										<option value="Pending">Pending</option>
										<option value="Shipping">Shipping</option>
										<option value="Finish">Finish</option>
									</select>
								</div>
							</div>
							<div class="col-md-12">
								<input class="btn btn-primary" id="btnSave" name="btnSave" type="button" value="Save" />
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

		
		</form>
	</div>
</div>



<script>
	ShowData();
</script>
<?php include"Bottom.php"; ?>