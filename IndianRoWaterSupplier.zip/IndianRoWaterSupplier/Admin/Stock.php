<?php include"Top.php"; ?>
<script>
	$(document).ready(function() 
	{
		$("#btnSave").click(function() 
		{
			var cnt = 0;
			var Element = ['Nos', 'Date'];
			for (i = 0; i < Element.length; i++)
			{
				var txtName = "txt" + Element[i];
				var lblName = "lbl" + Element[i];
				var Value = document.getElementById(txtName).value;
				if ( Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
			}
			
			if (cnt == 0) 
			{
				 var form_data = new FormData(document.getElementById("myform"));
				  form_data.append("label", "WEBUPLOAD");
				  $.ajax({
					  url: "Code/ManageStock.php?Choice=Add",
					  type: "POST",
					  data: form_data,
					  processData: false,  // tell jQuery not to process the data
					  contentType: false   // tell jQuery not to set contentType
				  }).done(function( data ) {
					console.log(data);
					$('#myform')[0].reset();
					ShowData();
					//Perform ANy action after successfuly post data
					   
				  });
			}
		});
	});
	
	function ShowData()
	{
		$('#Disp').load('Code/ManageStock.php?Choice=Show');
	}
	
</script>
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<input type="hidden" name="txtProName" id="txtProName">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Stock <span class="semi-bold">Elemets</span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-12">
								<a href="#" data-toggle="modal" data-target="#AddStock" class="btn btn-primary btn-cons">Add</a>
								<div class="table-responsive">
									<table width="100%">
										<tr>
											<td width="50%">
												<input type="text" id="txtSearch" style="width:95%" onkeyup="myFunction(0)" class="form-control" 
												       placeholder="Search By Code">		
											</td>
											<td width="50%">
												<select name="drpProName" onChange="myFunction(1)" id="drpProName" class="form-control">
													<?php
														try
														{
															$conec = new Connection();
															$con = $conec->Open();
															if($con)
															{
																$sql = "SELECT * FROM productmaster order by ProName desc";
																$re  = $con->query($sql);
																foreach ($con->query($sql) as $row) 
																{										
													?>	
																	<option value="<?php echo $row['ProId']; ?>">
																		<?php echo $row['ProName']; ?>
																	</option>
													<?php													
																}
															}
															else
															{
																echo $con;
															}
														}
														catch(PDOException $ex)
														{
															echo "Error:<br>".$ex->getMessage();
														}
													?>
												</select>					
											</td>
										</tr>
									</table>
									
									<br>
									<table class="table" id="myTable">
										<tr>
											<th>Code</th>
											<th>Product</th>
											<th>Inward Date</th>
											<th style="width:50px"></th>
										</tr>
										<tbody id="Disp">
										
										</tbody>
									</table>
								</div> 
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="AddStock" role="dialog">
			<div class="modal-dialog">
			  <!-- Modal content-->
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Add Stock</h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label style="font-weight:bold">Select Product <span style="color:red" id="lblProduct">*</span></label>
								<div class="control">
									<select name="drpPro" id="drpPro" class="form-control">
										<?php
											try
											{
												$conec = new Connection();
												$con = $conec->Open();
												if($con)
												{
													$sql = "SELECT * FROM productmaster order by ProName desc";
													$re  = $con->query($sql);
													foreach ($con->query($sql) as $row) 
													{										
										?>	
														<option value="<?php echo $row['ProId']; ?>"><?php echo $row['ProName']; ?></option>
										<?php													
													}
												}
												else
												{
													echo $con;
												}
											}
											catch(PDOException $ex)
											{
												echo "Error:<br>".$ex->getMessage();
											}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="col-md-6">								
							<div class="form-group">
								<label style="font-weight:bold">No of Stock<span style="color:red" id="lblNos">*</span></label>
								<div class="control">
									<input type="text" name="txtNos" id="txtNos" class="form-control" />
								</div>
							</div>
						</div>
						<div class="col-md-6">								
							<div class="form-group">
								<label style="font-weight:bold">Inward Date <span style="color:red" id="lblDate">*</span></label>
								<div class="control">
									<input type="date" name="txtDate" id="txtDate" class="form-control" />
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
							<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
						</div>
					</div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			  
			</div>
		</div>
		</form>
	</div>
</div>


	<script>
		ShowData();
	</script>
	<script>
	
		function ConfirmDamage(StockId)
		{
			var Result = confirm("Are Your Sure This Stock is Damage..!");
			if (Result == true)
			{
				var form_data = new FormData(document.getElementById("myform"));
				form_data.append("label", "WEBUPLOAD");
				$.ajax({
					url: "Code/ManageStock.php?Choice=DamageStock&StockId=" + StockId + "&UserId=<?php echo $_SESSION['AdminId']; ?>",
					type: "POST",
					data: form_data,
					processData: false,  // tell jQuery not to process the data
					contentType: false   // tell jQuery not to set contentType
				}).done(function( data ) {
					console.log(data);
					alert(data);
					$('#myform')[0].reset();
					ShowData();
					//Perform ANy action after successfuly post data
				});
			
			}
		}
		
		function myFunction(ch) {
		  
		  var input, filter, table, tr, td, i, txtValue;
		  if (ch == 0)
		  {
		  	input = document.getElementById("txtSearch");
		  }
		  else
		  {
		  	var Drp = document.getElementById("drpProName");
			document.getElementById("txtProName").value = Drp.options[Drp.selectedIndex].text;
			input = document.getElementById("txtProName");
		  }
		  
		  filter = input.value.toUpperCase();
		  table = document.getElementById("myTable");
		  tr = table.getElementsByTagName("tr");
		  
		  for (i = 0; i < tr.length; i++) {
			td = tr[i].getElementsByTagName("td")[ch];
			if (td) {
			  txtValue = td.textContent || td.innerText;
			  if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
			  } else {
				tr[i].style.display = "none";
			  }
			}       
		  }
		}
	</script>
<?php include"Bottom.php"; ?>