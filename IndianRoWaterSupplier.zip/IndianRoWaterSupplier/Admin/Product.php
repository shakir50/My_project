 <?php include"Top.php"; ?>
	
	 <div class="page-content">
	 	<form method="post" id="form" name="form">
		<script>
			$(document).ready(function() 
			{
				$("#btnSave").click(function() 
				{
					var cnt = 0;
					var Element = ['ProName','Price','Code'];
					var Values = ['ProName','Price','Code'];
					for (i = 0; i < Element.length; i++)
					{
						var txtName = "txt" + Element[i];
						var lblName = "lbl" + Element[i];
						var Value = document.getElementById(txtName).value;
						Values[i] = Value;
						if ( Value == "")
						{
							cnt++;
							document.getElementById(lblName).innerText = "*Required";
						}
						else
						{
							document.getElementById(lblName).innerText = "*";
						}
					}
					
					if (cnt == 0) 
					{
						var Id = document.getElementById("txtId").value;
						var Ch = "";
						if (Id != "")
						{
							Ch = "Edit";
						}
						else
						{
							Ch = "Add";
						}
						
						// Returns successful data submission message when the entered information is stored in database.
						$.post("Code/ManageProduct.php", 
						{							
							ProName: Values[0],
							Price: Values[1],
							Code: Values[2],
							ProId: Id,
							Choice: Ch
						}, 
						function(data) 
						{
							alert(data);
							$('#form')[0].reset(); // To reset form fields
							ShowData();
						});
					}
				});
			});
			
			function Delete(DelId)
			{
				var Result = confirm('Are You Sure Want to Delete...');
				if (Result == true)
				{
					$.post("Code/ManageProduct.php", 
					{
						Id: DelId,
						Choice: "Delete"
					}, 
					function(data) 
					{
						alert(data);
						$('#form')[0].reset(); // To reset form fields
						ShowData();
					})
				}
			}
			
			function ShowData()
			{
				$('#Disp').load('Code/ManageProduct.php?Choice=Show');
			}
			
			function Clear()
			{
				document.getElementById("txtId").value = "";
			}
			
			function Update(ProId, ProName, Price, Code)
			{
				document.getElementById("txtId").value = ProId;
				document.getElementById("txtProName").value = ProName;
				document.getElementById("txtPrice").value = Price;
				document.getElementById("txtCode").value = Code;
			}
		</script>
		
		
			<input type="hidden" id="txtId" name="txtId" value="" />
			<div class="clearfix">
			</div>
			<div class="content">
				<div class="row">
					<div class="col-md-6">
						<div class="grid simple">
							<div class="grid-title no-border">
								<h4>Add Product</h4>
							</div>
							<div class="grid-body no-border">
								 <div class="row">
								 	<div class="col-md-12">
										<div class="form-group">
											<label style="font-weight:bold">Product Name <span style="color:red" id="lblProName">*</span></label>
											<div class="control">
												<input type="text" name="txtProName" id="txtProName" placeholder="Enter Product Name" class="form-control" />
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label style="font-weight:bold">Product Price <span style="color:red" id="lblPrice">*</span></label>
											<div class="control">
												<input type="text" name="txtPrice" id="txtPrice" placeholder="Enter Product Price" class="form-control" />
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label style="font-weight:bold">Product Code <span style="color:red" id="lblCode">*</span></label>
											<div class="control">
												<input type="text" name="txtCode" id="txtCode" placeholder="Enter Product Code" class="form-control" />
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
										<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
									</div>
								 </div>   
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="grid simple">
							<div class="grid-title no-border">
								<h4>Show Product</h4>
							</div>
							<div class="grid-body no-border">
								<div class="table-responsive">
									<table class="table">
										<tr>
											<th>Product Name</th>
											<th>Price</th>
											<th>Code</th>
											<th>Action</th>
										</tr>
										<tbody id="Disp">
										
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
	<script>
		ShowData();
	</script>
<?php include"Bottom.php"; ?>