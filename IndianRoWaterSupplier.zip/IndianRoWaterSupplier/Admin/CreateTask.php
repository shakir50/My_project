 <?php include"Top.php"; ?>
 
 <script>
 	$(document).ready(function() 
	{
		$("#btnSave").click(function() 
		{
			var cnt = 0;
			var Element = ['Task', 'Vehicle', 'Route'];
			for (i = 0; i < Element.length; i++)
			{
				var txtName = "txt" + Element[i];
				var lblName = "lbl" + Element[i];
				var Value = document.getElementById(txtName).value;
				if ( Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
			}
			
			
			var tableLength = document.getElementById("EmpTable").rows.length;
			document.getElementById("txtTableLength").value = tableLength;
			
			var EmpCount = 0;
			for (i=1; i < tableLength; i++)
			{
				var ChkName = "chkEmp" + i;
				if (document.getElementById(ChkName).checked == true)
				{
					EmpCount++;
				}
			}
			
			if (EmpCount == 0)
			{
				cnt++;
				document.getElementById("lblEmployee").innerText = "*Required";	
			}
			else
			{
				document.getElementById("lblEmployee").innerText = "*";	
			}
			
			
			if (cnt == 0) 
			{
				var form_data = new FormData(document.getElementById("myform"));
			  	form_data.append("label", "WEBUPLOAD");
			 
				$.ajax({
				  url: "Code/ManageCreateTask.php?Choice=Add",
				  type: "POST",
				  data: form_data,
				  processData: false,  // tell jQuery not to process the data
				  contentType: false   // tell jQuery not to set contentType
				}).done(function( data ) {
				console.log(data);
				alert(data);
				$('#myform')[0].reset();
				//Perform ANy action after successfuly post data   
			  });
			}
		});
	});
 </script>
 
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<input type="hidden" id="txtTableLength" name="txtTableLength" />
		<div class="row">
			<div class="col-md-6">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Create<span class="semi-bold">Task</span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label style="font-weight:bold">Task <span style="color:red" id="lblTask">*</span></label>
									<div class="control">
										<select name="txtTask" id="txtTask" class="form-control" >
											<option value="">Select Task</option>
											<?php
												$Query = "select * from taskmaster";
												$Result = mysqli_query($Con,$Query);
												while ($row = mysqli_fetch_array($Result))
												{
											?>
													<option value="<?php echo $row['TaskId']; ?>"><?php echo $row['TaskName']; ?></option>
											<?php
												}
											?>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label style="font-weight:bold">Vehicle <span style="color:red" id="lblVehicle">*</span></label>
									<div class="control">
										<select name="txtVehicle" id="txtVehicle" class="form-control" >
											<option value="">Select Vehicle</option>
											<?php
												$Query = "select * from vehicledetail";
												$Result = mysqli_query($Con,$Query);
												while ($row = mysqli_fetch_array($Result))
												{
											?>
													<option value="<?php echo $row['VehId']; ?>"><?php echo $row['VehNo']; ?></option>
											<?php
												}
											?>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label style="font-weight:bold">Route <span style="color:red" id="lblRoute">*</span></label>
									<div class="control">
										<select name="txtRoute" id="txtRoute" class="form-control" >
											<option value="">Select Route</option>
											<?php
												$Query = "select * from rout";
												$Result = mysqli_query($Con,$Query);
												while ($row = mysqli_fetch_array($Result))
												{
											?>
													<option value="<?php echo $row['RoutId']; ?>"><?php echo $row['RoutName']; ?></option>
											<?php
												}
											?>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
								<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
							</div>
						</div>   
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Select Employee <span class="semi-bold">From List <span style="color:red" id="lblEmployee">*</span></span></h4>
					</div>
					<div class="grid-body no-border">
						<div class="table-responsive">
							<table class="table" id="EmpTable">
								<tr>
									<th width="65px">Sr No.</th>
									<th>Employee Name</th>
									<th width="30px"></th>
								</tr>	
								<tbody>
									<?php
										$Query = "select * from employeedetail";
										$Result = mysqli_query($Con,$Query);
										$i=0;
										while ($row = mysqli_fetch_array($Result))
										{
											$i++;
									?>
											<tr>
												<td align="center">
													<?php echo $i; ?>
													<input type="hidden" id="txtId<?php echo $i; ?>" name="txtId<?php echo $i; ?>" 
														   value="<?php echo $row['EmpId']; ?>" />
												</td>
												<td><?php echo $row['FullName']; ?></td>
												<td align="center"><input type="checkbox" name="chkEmp<?php echo $i; ?>" 
												 					id="chkEmp<?php echo $i; ?>" /></td>
											</tr>
									<?php
										}
									?>	
								</tbody>
							</table>
						</div>   
					</div>
				</div>
			</div>
			
			
		</div>
		</form>
	</div>
</div>
<?php include"Bottom.php"; ?>