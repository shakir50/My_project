 <?php include"Top.php"; ?>
	
	 <div class="page-content">
	 	<form method="post" id="form" name="form">
		<script>
			$(document).ready(function() 
			{
				$("#btnSave").click(function() 
				{
					var cnt = 0;
					var Element = ['TaskName'];
					var Values = ['TaskName'];
					for (i = 0; i < Element.length; i++)
					{
						var txtName = "txt" + Element[i];
						var lblName = "lbl" + Element[i];
						var Value = document.getElementById(txtName).value;
						Values[i] = Value;
						if ( Value == "")
						{
							cnt++;
							document.getElementById(lblName).innerText = "*Required";
						}
						else
						{
							document.getElementById(lblName).innerText = "*";
						}
					}
					
					if (cnt == 0) 
					{
						var Id = document.getElementById("txtId").value;
						var Ch = "";
						if (Id != "")
						{
							Ch = "Edit";
						}
						else
						{
							Ch = "Add";
						}
						
						// Returns successful data submission message when the entered information is stored in database.
						$.post("Code/ManageTask.php", 
						{							
							txtTaskName: Values[0],
							TaskId: Id,
							Choice: Ch
						}, 
						function(data) 
						{
							alert(data);
							$('#form')[0].reset(); // To reset form fields
							ShowData();
						});
					}
				});
			});
			
			function Delete(DelId)
			{
				var Result = confirm('Are You Sure Want to Delete...');
				if (Result == true)
				{
					$.post("Code/ManageTask.php", 
					{
						Id: DelId,
						Choice: "Delete"
					}, 
					function(data) 
					{
						alert(data);
						$('#form')[0].reset(); // To reset form fields
						ShowData();
					})
				}
			}
			
			function ShowData()
			{
				$('#Disp').load('Code/ManageTask.php?Choice=Show');
			}
			
			function Clear()
			{
				document.getElementById("txtId").value = "";
			}
			
			function Update(Id, RoutName)
			{
				document.getElementById("txtId").value = Id;
				document.getElementById("txtTaskName").value = RoutName;
			}
		</script>
		
		
			<input type="hidden" id="txtId" name="txtId" value="" />
			<div class="clearfix">
			</div>
			<div class="content">
				<div class="row">
					<div class="col-md-6">
						<div class="grid simple">
							<div class="grid-title no-border">
								<h4>Add Task</h4>
							</div>
							<div class="grid-body no-border">
								 <div class="row">
								 	<div class="col-md-12">
										<div class="form-group">
											<label style="font-weight:bold">Task Name <span style="color:red" id="lblTaskName">*</span></label>
											<div class="control">
												<input type="text" name="txtTaskName" id="txtTaskName" placeholder="Enter Task Name" class="form-control" />
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
										<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
									</div>
								 </div>   
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="grid simple">
							<div class="grid-title no-border">
								<h4>Show Task</h4>
							</div>
							<div class="grid-body no-border">
								<div class="table-responsive">
									<table class="table">
										<tr>
											<th>Task Name</th>
											<th>Action</th>
										</tr>
										<tbody id="Disp">
										
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
	<script>
		ShowData();
	</script>
<?php include"Bottom.php"; ?>