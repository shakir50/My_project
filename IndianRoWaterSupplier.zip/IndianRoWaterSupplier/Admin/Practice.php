<script>
	$('.success-popup').show();
	  setTimeout(function(){
	  $('.success-popup').hide();
	},3000)
</script>

<div class="success-popup">Success!</div>
 
 <style>
 	.success-popup{
	  position:absolute;
	  left:50%;
	  margin-left:-150px;
	  width:300px;
	  height:200px;
	  background:green;
	  color:white;
	  z-index:100;
	  display:none;
	}
 </style>
 
 
 <a class="btn btn-success waves-effect waves-light" onclick="toastr.success('Hi! I am success message.');">Success message</a>