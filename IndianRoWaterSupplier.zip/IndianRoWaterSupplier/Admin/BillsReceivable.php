 <?php include"Top.php"; ?>
 <script>
 	$(document).ready(function() 
	{
		$("#btnSave").click(function() 
		{
			var cnt = 0;
			var Element = ['Amount', 'RecDate'];
			for (i = 0; i < Element.length; i++)
			{
				var txtName = "txt" + Element[i];
				var lblName = "lbl" + Element[i];
				var Value = document.getElementById(txtName).value;
				if ( Value == "")
				{
					cnt++;
					document.getElementById(lblName).innerText = "*Required";
				}
				else
				{
					document.getElementById(lblName).innerText = "*";
				}
			}
			
			var Amount = parseFloat(document.getElementById("txtAmount").value);
			var RemAmount = parseFloat(document.getElementById("txtRecAmt").value);
			
			if (Amount <= RemAmount)
			{
				document.getElementById("lblAmount").innerText = "*";
			}
			else
			{
				cnt++;
				document.getElementById("lblAmount").innerText = "*Not More then " + RemAmount;
			}
			
			if (cnt == 0) 
			{
				var form_data = new FormData(document.getElementById("myform"));
			  	form_data.append("label", "WEBUPLOAD");
			 	var Id = "<?php echo $_SESSION['AdminId']; ?>";
				$.ajax({
				  url: "Code/ManageReceipt.php?Choice=AddReceivableAmount&Id=" + Id,
				  type: "POST",
				  data: form_data,
				  processData: false,  // tell jQuery not to process the data
				  contentType: false   // tell jQuery not to set contentType
				}).done(function( data ) {
				console.log(data);
				alert(data);
				$('#myform')[0].reset();
				ShowData();
				//Perform ANy action after successfuly post data   
			  });
			}
		});
	});
 </script>
 <div class="page-content">
	<div class="clearfix">
	</div>
	<div class="content">
		<form method="post" id="myform" name="myform" enctype="multipart/form-data">
		<div class="row">
			<div class="col-md-12">
				<div class="grid simple">
					<div class="grid-title no-border">
						<h4>Amount Yet <span class="semi-bold">to be Receive</span></h4>
					</div>
					<div class="grid-body no-border">
						
						<button type="button" name="btnExcel" onclick="tableToExcel('myTable', 'W3C Example Table')" id="btnExcel" class="btn btn-primary btn-cons">
							Export to Excel
						</button>
						<input type="text" id="txtSearch" onkeyup="myFunction()" class="form-control" placeholder="Search By Name"><br>
						<div class="table-responsive">
							<table class="table" id="myTable">
								<tr>
									<th>Sr No.</th>
									<th>Name</th>
									<th>Contact No</th>
									<th>Received</th>
									<th>Remain</th>
									<th>Total</th>
									<th></th>
								</tr>
								<tbody id="Disp">
								
								</tbody>
							</table>
						</div>    
					</div>
				</div>
			</div>
		</div>
		<!-- Modal -->
<div class="modal fade" id="BillReceivable" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Amount Receive from <span style="font-weight:bold" id="lblName"></span></h4>
			</div>
			<div class="modal-body">
				<input type="hidden" name="txtId" id="txtId">
				<input type="hidden" name="txtRecAmt" id="txtRecAmt">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label style="font-weight:bold">Amount <span style="color:red" id="lblAmount">*</span></label>
							<div class="control">
								<input type="text" name="txtAmount" onkeypress="return isNumber(event)" id="txtAmount" placeholder="Enter Amount" class="form-control" />
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label style="font-weight:bold">Received Date <span style="color:red" id="lblRecDate">*</span></label>
							<div class="control">
								<input type="date" name="txtRecDate" id="txtRecDate" placeholder="Enter Amount" class="form-control" />
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
		</form>
	</div>
</div>

<script>
	function GetData(Id, Name, Amount)
	{
		document.getElementById("txtRecAmt").value = Amount;
		document.getElementById("txtAmount").value = Amount;
		document.getElementById("txtId").value = Id;
		document.getElementById("lblName").innerText = Name;
	}
	
	function myFunction() {
	  var input, filter, table, tr, td, i, txtValue;
	  input = document.getElementById("txtSearch");
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");
	  for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[1];
		if (td) {
		  txtValue = td.textContent || td.innerText;
		  if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
		  } else {
			tr[i].style.display = "none";
		  }
		}       
	  }
	}
</script>
<script>
	function ShowData()
	{
		$('#Disp').load('Code/ManageReceipt.php?Choice=ShowBillsReceivable');
	}
	ShowData();
</script>

<?php include"Bottom.php"; ?>