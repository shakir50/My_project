<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{	
			case "ShowCustomerProductPrice":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select *,a.Price as 'CustPrice' from pricesetting as a join productmaster as b 
								    on a.ProId=b.ProId and a.CustId=".$_REQUEST['Id'];
							$re  = $con->query($sql);
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{		
								$i++;								
				?>	
								<div class="col-md-6">
									<div class="form-group">
										<label style="font-weight:bold">
											<?php echo $row['ProName']; ?> <span style="color:red" id="lblProName<?php echo $i; ?>">*</span>
										</label>
										<div class="control">
											<input type="hidden" name="txtId<?php echo $i; ?>" id="txtId<?php echo $i; ?>" 
												   value="<?php echo $row['PSId']; ?>" />
											<input type="text" name="txtProPrice<?php echo $i; ?>" id="txtProPrice<?php echo $i; ?>" 
											       placeholder="Enter <?php echo $row['ProName']; ?> Price" class="form-control" 
												   value="<?php echo $row['CustPrice']; ?>" />
										</div>
									</div>
								</div>
								
				<?php													
							}
							echo '<input type="hidden" name="txtLength" value="'.$i.'" id="txtLength" />';
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
										
					break;
					
				case "ChangeProductPrice":
						try
						{
							$conec = new Connection();
							$con = $conec->Open();
							if($con)
							{
								$Length = $_POST['txtLength'];
								for ($i =1; $i <= $Length; $i++)
								{
									$Query = "update pricesetting set Price= :Price where PSId= :Id";
									$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																				
									if($pre->execute(array(':Price' => $_REQUEST['txtProPrice'.$i], ':Id' => $_REQUEST['txtId'.$i])))
									{
														   
									}
								}
								echo "Data Successfully Saved";
								
							}
							else
							{
								echo $con;
							}
						}
						catch(PDOException $ex)
						{
							echo "Error:<br>".$ex->getMessage();
						}
										
					break;
	}
	
?>