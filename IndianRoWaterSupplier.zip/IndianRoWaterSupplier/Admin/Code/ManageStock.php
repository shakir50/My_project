<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];
	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Select *,(select count(*) from stock where ProId=".$_POST['drpPro'].") as 'CountNo' 
								      from productmaster where ProId=".$_POST['drpPro'];
							$pre = $con->prepare($Query);
										
							if($pre->execute())
							{
								$Value = $pre->fetch();
							}
							
							$Code = $Value['Code'];
							$Count = $Value['CountNo'];
							
							$Tot = $_POST['txtNos'];
							
							for ($i = 0; $i < $Tot; $i++)
							{
								$Count++;
								$Query = "INSERT INTO `stock` (`StockId`, `ProId`, `Code`, `InwardDate`) VALUES (NULL,  :ProId, :Code, :InDate);";
								$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																			
								if($pre->execute(array(':ProId' => $_REQUEST['drpPro'], ':Code' => $Code."".$Count,
												       ':InDate' => $_REQUEST['txtDate'])))
								{
									
								}
							}
							echo "Data Successfully Saved";
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
					
			case "Show":
				try
				{
					$conec = new Connection();
					$con = $conec->Open();
					if($con)
					{
						$sql = "select *, a.Code as 'ProCode' from stock as a join productmaster as b on a.ProId=b.ProId and a.StockId not in (select StockId from damagestock) order by StockId desc";
						$re  = $con->query($sql);
						foreach ($con->query($sql) as $row) 
						{										
			?>	
							<tr>
								<td><?php echo $row['ProCode']; ?></td>
								<td><?php echo $row['ProName']; ?></td>
								<td><?php echo $row['InwardDate']; ?></td>
								<td align="center">
									<span onclick="ConfirmDamage('<?php echo $row['StockId']; ?>');"><img src="../Icon/Damage.png" style="height:30px;width:30px" /></span>
								</td>
							</tr>
			<?php													
						}
					}
					else
					{
						echo $con;
					}
				}
				catch(PDOException $ex)
				{
					echo "Error:<br>".$ex->getMessage();
				}
				break;
				
		case "DamageStock":
			try
			{
				$conec = new Connection();
				$con = $conec->Open();
				if($con)
				{
					
					$Date = date("y-m-d H:i:s");
					$Query = "INSERT INTO `damagestock` (`DId`, `StockId`, `TransecId`, `UserId`, `UserType`, `DTId`) VALUES 
							 (NULL, :StockId, :Time, :UserId, :UserType, NULL);";
					
					
					$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																
					if($pre->execute(array(':UserId' => $_REQUEST['UserId'], ':Time' => $Date, ':StockId' => $_REQUEST['StockId'], ':UserType' => "Admin")))
					{
						echo "Data Successfully Saved";	
					}
					
				}
				else
				{
					echo $con;
				}
			}
			catch(PDOException $ex)
			{
				echo "Error:<br>".$ex->getMessage();
			}
		break;
			
	}
	
?>