<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "INSERT INTO `productmaster` (`ProId`, `ProName`, `Price`, `Code`) VALUES (NULL, :ProName, :Price, :Code);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':ProName' => $_REQUEST['ProName'], ':Price' => $_REQUEST['Price'], 
												   ':Code' => $_REQUEST['Code'])))
							{
								$Query = "select * from customer";
								if (!$Result = mysqli_query($Con, $Query))
								{
									echo mysqli_error($Con);
								}
								while ($row = mysqli_fetch_array($Result))
								{
									$Query = "INSERT INTO `pricesetting` (`PSId`, `ProId`, `CustId`, `Price`) VALUES 
											 (NULL, (select COALESCE(MAX(ProId),1) from productmaster), '".$row['CustId']."', '".$_POST['Price']."');";
									mysqli_query($Con, $Query);
								}
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Edit":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Update productmaster set ProName= :ProName, Price= :Price, Code= :Code Where ProId= :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':ProName' => $_REQUEST['ProName'], ':Price' => $_REQUEST['Price'], 
												   ':Code' => $_REQUEST['Code'], ':Id' => $_REQUEST['ProId'])))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Show":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "SELECT * FROM productmaster order by ProId desc";
							$re  = $con->query($sql);
							foreach ($con->query($sql) as $row) 
							{										
				?>	
								<tr>
									<td><?php echo $row['ProName']; ?></td>
									<td><?php echo $row['Price']; ?></td>
									<td><?php echo $row['Code']; ?></td>
									<td>
										<a href="#" onClick="Update('<?php echo $row['ProId']; ?>','<?php echo $row['ProName']; ?>','<?php echo $row['Price']; ?>','<?php echo $row['Code']; ?>')"><img src="../Icon/Edit.png" style="width:20px;height:20px" ></a>
										<a href="#" onClick="Delete('<?php echo $row['ProId']; ?>')">
											<img src="../Icon/Delete.png" style="width:20px;height:20px" ></a>
									</td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "Delete":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Delete From productmaster where ProId = :ProId";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':ProId' => $_REQUEST['Id'])))
							{
								echo "Data Successfully Removed";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
	}
	
?>