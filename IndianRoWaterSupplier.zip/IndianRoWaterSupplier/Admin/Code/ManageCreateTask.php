<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];
	
	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Count = $_POST['txtTableLength'];
							$Date = date('y-m-d H:i:s');
							
							$Query = "INSERT INTO `dailytask` (`DTId`, `TaskId`, `TransecTime`, `Status`) VALUES (NULL, '".$_REQUEST['txtTask']."', '".$Date."', 'Pending');";
							mysqli_query($Con, $Query);
							
							for ($i = 1; $i < $Count; $i++)
							{
								if (isset($_POST['chkEmp'.$i]))
								{
									$Query = "INSERT INTO `createtask` (`CTId`, `DTId`, `RoutId`, `EmpId`, `VehId`, `TransecTime`) VALUES 
									         (NULL, (select coalesce(MAX(DTId), 1) from dailytask), :RouteId, :EmpId, :VehId, :TransecTime);";
									$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																				
									if($pre->execute(array(':RouteId' => $_REQUEST['txtRoute'],':EmpId' => $_REQUEST['txtId'.$i], ':VehId' => $_REQUEST['txtVehicle'],
														   ':TransecTime' => $Date)))
									{
										
									}
								}
							}
							echo "Data Successfully Saved";
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
				case "Show":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select DISTINCT e.DTId,d.TaskName,b.RoutName,c.VehNo,a.TransecTime,e.Status from createtask as a join rout as b join vehicledetail as c join taskmaster as d join dailytask as e on a.VehId = c.VehId and a.RoutId=b.RoutId and a.DTId=e.DTId and e.TaskId = d.TaskId and DATE(e.TransecTime)  = '".date('Y-m-d')."' order by e.TransecTime";
							$re  = $con->query($sql);
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{		
								$i++;								
				?>	
								<tr>
									<td style="vertical-align:middle"><?php echo $i; ?></td>
									<td style="vertical-align:middle"><?php echo $row['TaskName']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['RoutName']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['VehNo']; ?></td>
									<td style="vertical-align:middle">
										
										<?php
											$Query = "select * from employeedetail where EmpId in 
													 (SELECT EmpId from createtask where DTId=".$row['DTId'].")";
											$Result = mysqli_query($Con,$Query);
											while ($ChildRow = mysqli_fetch_array($Result))
											{
												echo "<li>".$ChildRow['FullName']."</li>";
											}
										?>
									
									</td>
									<td style="vertical-align:middle">
										<table width="100%">
											<tr>
												<th>Product</th>
												<th>Stock</th>
											</tr>
										<?php
											$Query = "select a.ProName,
													 (select count(*) from loadstock where ProId=a.ProId and 
												      DTId=".$row['DTId'].") as 'NoS' from productmaster as a 
													  where (select count(*) from loadstock where ProId=a.ProId and DTId=".$row['DTId'].") > 0";
													  
											$Result = mysqli_query($Con,$Query);
											while ($ChildRow = mysqli_fetch_array($Result))
											{
												echo "<tr>";
												echo "<td>".$ChildRow['ProName']."</td>";
												echo "<td>".$ChildRow['NoS']."</td>";
												echo "</tr>";
											}
										?>
										</table>
									</td>
									<td style="vertical-align:middle"><?php echo $row['TransecTime']; ?></td>
									<td style="vertical-align:middle;">
										<span onclick="GetData('<?php echo $row['DTId']; ?>', '<?php echo $row['Status']; ?>')" data-toggle="modal" data-target="#ChangeStatus">
										<?php
											if ($row['Status'] == 'Pending')
											{
										?>
												<img src="../Icon/Pending.png" style="height:30px;width:30px" />
										<?php
											}
											else if ($row['Status'] == 'Shiping')
											{
										?>
												<img src="../Icon/LoadStock.png" style="height:30px;width:30px" />
										<?php	
											}
											else
											{
										?>
												<img src="../Icon/Accept-icon.png" style="height:30px;width:30px" />
										<?php
											}
										?>
										</span>
										<a href="<?php echo "LoadStock.php?DTId=".$row['DTId']; ?>">
											<img src="../Icon/View Detail.png" style="height:30px;width:30px" />
										</a>
										<a href="#">
											<img src="../Icon/Complete.ico" style="height:35px;width:30px" />
										</a>
									</td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
			break;	
			case "LoadStock":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							session_start();
							$sql = "select *,(select count(*) from loadstock where DTId=".$_REQUEST['txtDTId']." and StockId=stk.StockId) as Status from stock as stk where stk.ProId=".$_REQUEST['ProId']." order by StockId";
							$re  = $con->query($sql);
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{	
								$i++;
								$Status = "";
								if ($row['Status'] == "1")
								{
									$Status = "checked='checked'";
								}	
								else
								{
									$Status = "";
								}
																
				?>	
								<div class="col-md-2" id="<?php echo "Div".$i; ?>">
									<div class="row-fluid">
										<div class="checkbox check-success 	">
											<input id="chk<?php echo $i; ?>" name="chk<?php echo $i; ?>" type="checkbox" 
											       value="<?php echo $row['StockId']; ?>" <?php echo $Status; ?>  >
											<label for="chk<?php echo $i; ?>"><?php echo $row['Code']; ?></label>
											<input type="hidden" id="txtStockId<?php echo $i; ?>" value="<?php echo $row['StockId']; ?>" name="txtStockId<?php echo $i; ?>" />
										</div>
									</div>
								</div>
				<?php													
							}
							echo '<input type="hidden" id="txtLength" name="txtLength" value="'.$i.'" />';
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
			break;
			case "AddLoadStock":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Count = $_POST['txtLength'];
							
							for ($i = 1; $i < $Count; $i++)
							{
								if (isset($_POST['chk'.$i]))
								{
									
									$Query = "SELECT count(*) as res FROM loadstock WHERE DTId = ".$_REQUEST['DTId']." 
											  and ProId= ".$_REQUEST['drpPro']." and StockId= ".$_POST['chk'.$i];
									$Result = mysqli_query($Con, $Query);
									$Row = mysqli_fetch_array($Result);
									
									if ($Row['res'] == 0)
									{
										$Query = "INSERT INTO `loadstock` (`LSId`, `DTId`, `ProId`, `StockId`) VALUES 
											 	 (NULL, :DTId, :ProId, :StockId);";
										$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																					
										if($pre->execute(array(':DTId' => $_REQUEST['DTId'], ':ProId' => $_REQUEST['drpPro'], ':StockId' => $_POST['chk'.$i])))
										{
											
										}
									}													 
								}
								else
								{
									$Query = "delete from loadstock where DTId=".$_REQUEST['DTId']."  and StockId=".$_POST['txtStockId'.$i];
									if (!mysqli_query($Con,$Query))
									{
										echo mysqli_error($Con);
									}
								}
							}
							echo "Data Successfully Saved";
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
			break;
			case "ChangeStatus":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Update dailytask set Status= :Status where DTId= :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Status' => $_REQUEST['drpStatus'], ':Id' => $_REQUEST['txtDTId'])))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
			break;
			
	}
	
?>