<?php
	include"../../Config/Connection.php";
	session_start();
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							move_uploaded_file($_FILES["imgInp1"]["tmp_name"], "../AdminPhoto/".$_FILES["imgInp1"]["name"]);
							$Query = "INSERT INTO `adminuser` (`AdminId`, `FullName`, `Cno`, `Email`, `Address`, `Photo`, `Password`) VALUES (NULL, :FullName, :Contact, :Email, :Address, :Photo, :Pass);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':FullName' => $_REQUEST['txtFullName'], ':Contact' => $_REQUEST['txtContact'], 
												   ':Address' => $_REQUEST['txtAddress'], ':Email' => $_REQUEST['txtEmail'],
												   ':Photo' => $_FILES["imgInp1"]["name"], ':Pass' => "123456")))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Edit":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Update adminuser set FullName= :FullName, Cno= :Cno, Address= :Address, Photo= :Photo, Email= :Email 
									  where AdminId= :AdminId";
							$FileName = "";
							if ( $_FILES["inpProfile"]["name"] !=  "")
							{
								move_uploaded_file($_FILES["inpProfile"]["tmp_name"], "../AdminPhoto/".$_FILES["inpProfile"]["name"]);
								$FileName = $_FILES["inpProfile"]["name"];
							}
							else
							{
								$FileName = $_POST['txtProPhoto'];
							}
							
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':FullName' => $_REQUEST['txtProFullName'], ':Cno' => $_REQUEST['txtProContact'], 
												   ':Address' => $_REQUEST['txtProAddress'], ':Email' => $_REQUEST['txtProEmail'],
												   ':Photo' => $FileName, 'AdminId' => $_POST['txtProfileId'])))
							{
								$_SESSION['ContactNo'] = $_REQUEST['txtProContact']; 
								$_SESSION['FullName'] = $_REQUEST['txtProFullName'];
								$_SESSION['Email'] = $_REQUEST['txtProEmail'];
								$_SESSION['Address'] = $_REQUEST['txtProAddress'];
								$_SESSION['Photo'] = $FileName;
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Show":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "SELECT * FROM adminuser order by AdminId desc";
							$re  = $con->query($sql);
							foreach ($con->query($sql) as $row) 
							{	
								$Path = "";
								if ($row['Photo'] == "")
								{
									$Path = "../Icon/User.png";
								}
								else
								{
									$Path = "AdminPhoto/".$row['Photo'];
								}
																	
				?>	
								<tr>
									<td align="center"><img src="<?php echo $Path; ?>" style="height:80px;width:80px;border-radius: 50%"></td>
									<td style="vertical-align:middle"><?php echo $row['FullName']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Email']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Cno']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Address']; ?></td>
									<td style="vertical-align:middle">
									<a href="#" onClick="Delete('<?php echo $row['AdminId']; ?>')">
											<img src="../Icon/Delete.png" style="width:20px;height:20px" ></a>
									</td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "Delete":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Delete From adminuser where AdminId = :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Id' => $_REQUEST['Id'])))
							{
								echo "Data Successfully Removed";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "Login":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "select * from adminuser where Cno= :Cno and Password= :Pass";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
										
							if($pre->execute(array(':Cno' => $_POST['txtCno'], ':Pass' => $_POST['txtPass'])))
							{
								$Value = $pre->fetch();
								if ($Value['Cno'] == $_POST['txtCno'] && $Value['Password'] == $_POST['txtPass'])
								{
									
									$_SESSION['ContactNo'] = $Value['Cno']; 
									$_SESSION['FullName'] = $Value['FullName'];
									$_SESSION['Email'] = $Value['Email'];
									$_SESSION['Address'] = $Value['Address'];
									$_SESSION['Photo'] = $Value['Photo'];
									$_SESSION['AdminId'] = $Value['AdminId'];
									echo "Success Login";
								}
								else
								{
									echo "Wrong UserName or Password";
								}
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
									
					break;
				case "ChangePassword":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "select * from adminuser where Password= :Pass and AdminId= :AdminId";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
										
							if($pre->execute(array(':AdminId' => $_POST['txtProfileId'], ':Pass' => $_POST['txtOldPass'])))
							{
								$Value = $pre->fetch();
								if ($Value['Password'] == $_POST['txtOldPass'])
								{
									$Query = "Update adminuser set Password= :Password where AdminId= :AdminId";
									$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																				
									$pre->execute(array(':Password' => $_REQUEST['txtNewPass'], ':AdminId' => $_POST['txtProfileId']));
									echo "Success Saved";
								}
								else
								{
									echo "Incorrect Old Password";
								}
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
									
					break;
	}
	
	
	
?>