<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "ShowBillsReceivableReport":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							if (isset($_REQUEST['DateFrom']))
							{
								$sql = "select a.BRId,b.FullName,b.Cno,a.Amount,a.RecDate,a.EntryDate, if (a.UserType = 'Admin', (select FullName from adminuser where AdminId=a.Id), (select FullName from employeedetail where EmpId=a.Id)) as 'CollectBy' from billsreceivable as a join customer as b on a.CustId=b.CustId and a.RecDate between '".$_REQUEST['DateFrom']."' and '".$_REQUEST['DateTo']."'";
							}
							else
							{
								$sql = "select a.BRId,b.FullName,b.Cno,a.Amount,a.RecDate,a.EntryDate, if (a.UserType = 'Admin', (select FullName from adminuser where AdminId=a.Id), (select FullName from employeedetail where EmpId=a.Id)) as 'CollectBy' from billsreceivable as a join customer as b on a.CustId=b.CustId";
							}
						
							
							
							$re  = $con->query($sql);
							$i = 0;
							
							foreach ($con->query($sql) as $row) 
							{		
								$i++;								
				?>		
								<tr>
									<td><?php echo $i; ?></td>
									<td>
										<?php echo $row['FullName']; ?>
									</td>
									<td>
										<?php echo $row['Cno']; ?>
									</td>
									<td>
										<?php echo $row['Amount']; ?>
									</td>
									<td>
										<?php echo $row['CollectBy']; ?>
									</td>
									<td>
										<?php echo $row['RecDate']; ?>
									</td>
									<td>
										<?php echo $row['EntryDate']; ?>
									</td>
								</tr>
				<?php												
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "ShowReceiptReport":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							if (isset($_REQUEST['DateFrom']))
							{
								$sql = "select a.RecId,b.FullName,b.Cno,a.Amount,a.RecDate from receipt as a join customer as b on a.CustId=b.CustId and a.RecDate between '".$_REQUEST['DateFrom']."' and '".$_REQUEST['DateTo']."'";
							}
							else
							{
								$sql = "select a.RecId,b.FullName,b.Cno,a.Amount,a.RecDate from receipt as a join customer as b on a.CustId=b.CustId";
							}
						
							
							
							$re  = $con->query($sql);
							
							
							foreach ($con->query($sql) as $row) 
							{										
				?>		
								<tr>
									
									<td>
										<?php echo $row['RecId']; ?>
									</td>
									<td>
										<?php echo $row['FullName']; ?>
									</td>
									<td>
										<?php echo $row['Cno']; ?>
									</td>
									<td>
										<?php echo $row['Amount']; ?>
									</td>
									<td>
										<?php echo $row['RecDate']; ?>
									</td>
								</tr>
				<?php												
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "ShowIssueReport":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							if (isset($_REQUEST['DateFrom']))
							{
								$sql = "select e.FullName,e.Cno,c.Code,d.ProName,a.Price,a.IssueTime,b.ReturnTime,
if (a.UserType = 'Admin', (select FullName from adminuser where AdminId=a.UserId), (select FullName from employeedetail where EmpId=a.UserId)) as 'IssueFrom',
if (b.UserType = 'Admin', (select FullName from adminuser where AdminId=b.UserId), (select FullName from employeedetail where EmpId=b.UserId)) as 'ReturnBy'
from issue_stock as a join returnstock as b join stock as c join productmaster as d join customer as e
on a.IssueId=b.IssueId and a.StockId=c.StockId and c.ProId=d.ProId and a.CustId = e.CustId and a.IssueTime  between '".$_REQUEST['DateFrom']."' and '".$_REQUEST['DateTo']."'";
							}
							else
							{
								$sql = "select e.FullName,e.Cno,c.Code,d.ProName,a.Price,a.IssueTime,b.ReturnTime,
if (a.UserType = 'Admin', (select FullName from adminuser where AdminId=a.UserId), (select FullName from employeedetail where EmpId=a.UserId)) as 'IssueFrom',
if (b.UserType = 'Admin', (select FullName from adminuser where AdminId=b.UserId), (select FullName from employeedetail where EmpId=b.UserId)) as 'ReturnBy'
from issue_stock as a join returnstock as b join stock as c join productmaster as d join customer as e
on a.IssueId=b.IssueId and a.StockId=c.StockId and c.ProId=d.ProId and a.CustId = e.CustId";
							}
						
							
							
							$re  = $con->query($sql);
							
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{	
								$i++;									
				?>		
								<tr>
									
									<td>
										<?php echo $i; ?>
									</td>
									<td>
										<?php echo $row['FullName']."<br>".$row['Cno']; ?>
									</td>
									<td>
										<?php echo $row['Code']."<br>".$row['ProName']; ?>
									</td>
									<td>
										<?php echo $row['Price']; ?>
									</td>
									<td>
										<?php echo $row['IssueTime']; ?>
									</td>
									<td>
										<?php echo $row['ReturnTime']; ?>
									</td>
									<td>
										<?php echo $row['IssueFrom']; ?>
									</td>
									<td>
										<?php echo $row['ReturnBy']; ?>
									</td>
								</tr>
				<?php												
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
					
			case "ShowDamageReport":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							if (isset($_REQUEST['DateFrom']))
							{
								$sql = "select b.StockId,b.Code,c.ProName,a.TransecId,if (a.UserType = 'Admin', (select FullName from adminuser where AdminId=a.UserId), (select FullName from employeedetail where EmpId=a.UserId)) as 'EntryBy' from damagestock as a join stock as b join productmaster as c on a.StockId=b.StockId and b.ProId=c.ProId and a.TransecId BETWEEN  '".$_REQUEST['DateFrom']."' and '".$_REQUEST['DateTo']."'";
							}
							else
							{
								$sql = "select b.StockId,b.Code,c.ProName,a.TransecId,if (a.UserType = 'Admin', (select FullName from adminuser where AdminId=a.UserId), (select FullName from employeedetail where EmpId=a.UserId)) as 'EntryBy' from damagestock as a join stock as b join productmaster as c on a.StockId=b.StockId and b.ProId=c.ProId";
							}
						
							
							
							$re  = $con->query($sql);
							
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{	
								$i++;									
				?>		
								<tr>
									
									<td>
										<?php echo $i; ?>
									</td>
									<td>
										<?php echo $row['Code']; ?>
									</td>
									<td>
										<?php echo $row['ProName']; ?>
									</td>
									<td>
										<?php echo $row['TransecId']; ?>
									</td>
									<td>
										<?php echo $row['EntryBy']; ?>
									</td>
								</tr>
				<?php												
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "ShowExpenseReport":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							if (isset($_REQUEST['DateFrom']))
							{
								$sql = "select * from expense as a join expensetype as b on a.ExpTypeId=b.ExpTypeId and 
									    a.ExpDate BETWEEN  '".$_REQUEST['DateFrom']."' and '".$_REQUEST['DateTo']."' order by a.ExpId Desc";
							}
							else
							{
								$sql = "select * from expense as a join expensetype as b on a.ExpTypeId=b.ExpTypeId order by a.ExpId Desc";
							}
						
							$re  = $con->query($sql);
							
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{	
								$i++;
																	
				?>	
								<tr>
									<td style="vertical-align:middle"><?php echo $i; ?></td>
									<td style="vertical-align:middle"><?php echo $row['ExpTypeName']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['BillNo']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['ExpFor']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Amount']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Description']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['ExpDate']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['EntryDate']; ?></td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			
	}
	
?>