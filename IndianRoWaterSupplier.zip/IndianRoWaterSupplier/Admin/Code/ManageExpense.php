<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "INSERT INTO `expense` (`ExpId`, `ExpTypeId`, `ExpFor`, `BillNo`, `Amount`, `Description`, `ExpDate`, `EntryDate`) VALUES (NULL, :ExpTypeId, :ExpFor, :BillNo, :Amount, :Description, :ExpDate, :TransecTime);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':ExpTypeId' => $_REQUEST['txtType'], ':ExpFor' => $_REQUEST['txtExpFor'], 
												   ':BillNo' => $_REQUEST['txtBillNo'], ':Amount' => $_REQUEST['txtAmount'],
												   ':Description' => $_REQUEST['txtDesc'], ':ExpDate' => $_REQUEST['txtDate'], ':TransecTime' => date("Y-m-d H:i:s"))))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Edit":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Update expense set `ExpTypeId` = :ExpTypeId, `ExpFor` = :ExpFor, `BillNo` = :BillNo, `Amount` = :Amount, 
									 `Description` = :Description, `ExpDate` = :ExpDate where ExpId= :Id";
							
							
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':ExpTypeId' => $_REQUEST['txtType'], ':ExpFor' => $_REQUEST['txtExpFor'], ':Id' => $_REQUEST['txtId'], 
												   ':BillNo' => $_REQUEST['txtBillNo'], ':Amount' => $_REQUEST['txtAmount'],
												   ':Description' => $_REQUEST['txtDesc'], ':ExpDate' => $_REQUEST['txtDate'])))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Show":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select * from expense as a join expensetype as b on a.ExpTypeId=b.ExpTypeId order by a.ExpId Desc";
							$re  = $con->query($sql);
							$i=0;
							foreach ($con->query($sql) as $row) 
							{	
								$i++;
																	
				?>	
								<tr>
									<td style="vertical-align:middle"><?php echo $i; ?></td>
									<td style="vertical-align:middle"><?php echo $row['ExpTypeName']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['BillNo']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['ExpFor']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Amount']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Description']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['ExpDate']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['EntryDate']; ?></td>
									<td style="vertical-align:middle">
									<a href="#" onClick="Delete('<?php echo $row['ExpId']; ?>')">
											<img src="../Icon/Delete.png" style="width:20px;height:20px" ></a>
									<a href="#"  onClick="Edit('<?php echo $row['ExpId']; ?>', '<?php echo $row['ExpTypeId']; ?>', '<?php echo $row['BillNo']; ?>', '<?php echo $row['ExpFor']; ?>', '<?php echo $row['Amount']; ?>', '<?php echo $row['ExpDate']; ?>', '<?php echo $row['Description']; ?>')" data-toggle="modal" data-target="#AddExpense" >
											<img src="../Icon/Edit.png" style="width:20px;height:20px" ></a>
											
											
											
									</td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "Delete":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Delete From expense where ExpId = :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Id' => $_REQUEST['Id'])))
							{
								echo "Data Successfully Removed";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
			break;	
			
			
				
	}
	
	
	
?>