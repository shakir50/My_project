<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "INSERT INTO `expensetype` (`ExpTypeId`, `ExpTypeName`) VALUES (NULL, :Name);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Name' => $_REQUEST['Name'])))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Edit":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Update expensetype set ExpTypeName= :Name where ExpTypeId= :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Name' => $_REQUEST['Name'], ':Id' => $_REQUEST['Id'])))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Show":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "SELECT * FROM expensetype order by ExpTypeId desc";
							$re  = $con->query($sql);
							foreach ($con->query($sql) as $row) 
							{										
				?>	
								<tr>
									<td><?php echo $row['ExpTypeName']; ?></td>
									<td>
										<a href="#" onClick="Update('<?php echo $row['ExpTypeId']; ?>','<?php echo $row['ExpTypeName']; ?>')">
											<img src="../Icon/Edit.png" style="width:20px;height:20px" ></a>
										<a href="#" onClick="Delete('<?php echo $row['ExpTypeId']; ?>')">
											<img src="../Icon/Delete.png" style="width:20px;height:20px" ></a>
									</td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "Delete":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Delete From expensetype where ExpTypeId = :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Id' => $_REQUEST['Id'])))
							{
								echo "Data Successfully Removed";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
	}
	
?>