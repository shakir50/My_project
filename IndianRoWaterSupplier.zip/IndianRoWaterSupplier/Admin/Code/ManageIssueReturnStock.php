<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
			case "ShowProduct":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							//$sql = "select a.Code,a.StockId from stock as a join productmaster as b on a.ProId=b.ProId and a.ProId=".$_REQUEST['Id']." and a.StockId not in (select StockId from issuestock where isnull(ReturnTime)) order by a.StockId";
							
							$sql = "select a.StockId,a.Code from stock as a where a.StockId not in (select StockId from issue_stock as b where b.IssueId not in (select IssueId from returnstock)) and a.ProId = ".$_REQUEST['Id'];
							$re  = $con->query($sql);
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{		
								$i++;								
				?>		
								<tr>
									<td><?php echo $i; ?></td>
									<td>
										<?php echo $row['Code']; ?>
									</td>
									<td>
										<div class="checkbox check-success 	">
											<input id="chk<?php echo $i; ?>" name="chk<?php echo $i; ?>" type="checkbox" 
											       value="<?php echo $row['StockId']; ?>">
											<label for="chk<?php echo $i; ?>"></label>
											<input type="hidden" id="txtStockId<?php echo $i; ?>" value="<?php echo $row['StockId']; ?>" 
												   name="txtStockId<?php echo $i; ?>" />
										</div>
									</td>
									
								</tr>
				<?php													
							}
							echo '<input type="hidden" id="txtLength" name="txtLength" value="'.$i.'" />';
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
				case "AddLoadStock":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Count = $_POST['txtLength'];
							
							for ($i = 1; $i <= $Count; $i++)
							{
								if (isset($_POST['chk'.$i]))
								{
									
									$Query = "INSERT INTO `issue_stock` (`IssueId`, `StockId`, `CustId`, `UserType`, `UserId`, `IssueTime`, `Price`, `PaymentType`, `RecNo`, `DTId`) 											  VALUES (NULL, :StockId, :CustId, :UserType, :UserId, :IssueTime, 
											 (select Price from pricesetting where ProId=".$_POST['drpPro']." and CustId=".$_REQUEST['CustId']."), :PaymentType, NULL, NULL);";
									
									
									$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																				
									if($pre->execute(array(':StockId' => $_POST['chk'.$i], ':CustId' => $_REQUEST['CustId'],
														   ':PaymentType' => $_POST['drpPayment'], ':UserId' => $_REQUEST['IssueId'],
														   ':IssueTime' => $_POST['txtIssueDate'], ':UserType' => "Admin")))
									{
										
									}												 
								}
							}
							echo "Data Successfully Saved";
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
				case "ShowProductReturn":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select a.IssueId,c.ProName,b.Code,
									if(a.UserType = 'Admin',(select FullName from adminuser where AdminId=a.UserId),
															(select FullName from employeedetail where EmpId=a.UserId)) as 'IssuedBy',
									a.IssueTime from issue_stock as a join stock as b join productmaster as c 
									on a.StockId=b.StockId and b.ProId=c.ProId and a.IssueId not in (select IssueId from returnstock) and a.CustId=".$_REQUEST['CustId'];		
							$re  = $con->query($sql);
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{		
								$i++;								
				?>		
								<tr>
									<td><?php echo $i; ?></td>
									<td>
										<?php echo $row['Code']; ?>
									</td>
									<td>
										<?php echo $row['ProName']; ?>
									</td>
									<td>
										<?php echo $row['IssueTime']; ?>
									</td>
									<td>
										<?php echo $row['IssuedBy']; ?>
									</td>
									<td>
										<div class="checkbox check-success 	">
											<input id="chkReturn<?php echo $i; ?>" name="chkReturn<?php echo $i; ?>" type="checkbox" 
											       value="<?php echo $row['IssueId']; ?>">
											<label for="chkReturn<?php echo $i; ?>"></label>
											<input type="hidden" id="txtIssueId<?php echo $i; ?>" value="<?php echo $row['IssueId']; ?>" 
												   name="txtIssueId<?php echo $i; ?>" />
										</div>
									</td>
									
								</tr>
				<?php													
							}
							echo '<input type="hidden" id="txtReturnLength" name="txtReturnLength" value="'.$i.'" />';
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
				case "ReturnStock":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Count = $_POST['txtReturnLength'];
							
							for ($i = 1; $i <= $Count; $i++)
							{
								if (isset($_POST['chkReturn'.$i]))
								{
									$Query = "INSERT INTO `returnstock` (`RSId`, `IssueId`, `UserType`, `UserId`, `ReturnTime`, `DTId`) VALUES 
											 (NULL, :IssueId, :UserType, :UserId, :Time, NULL);";
									
									
									$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																				
									if($pre->execute(array(':UserId' => $_REQUEST['ReturnId'], ':Time' => $_REQUEST['txtReturnDate'],
														   ':IssueId' => $_POST['chkReturn'.$i], ':UserType' => "Admin")))
									{
										
									}												 
								}
							}
							echo "Data Successfully Saved";
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
				
				case "ShowProductReturn":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select a.ISId,c.ProName,b.Code,a.Price,a.IssueTime,
									(select FullName from employeedetail where EmpId=a.IssueEmpId) as 'Emp',
									(select FullName from adminuser where AdminId=a.AdminIssueId) as 'Admin' 
									from issuestock as a join stock as b join productmaster as c
									on a.StockId=b.StockId and b.ProId=c.ProId AND a.CustId=".$_REQUEST['CustId']." and isnull(a.ReturnTime)";
							$re  = $con->query($sql);
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{		
								$i++;								
				?>		
								<tr>
									<td><?php echo $i; ?></td>
									<td>
										<?php echo $row['Code']; ?>
									</td>
									<td>
										<?php echo $row['ProName']; ?>
									</td>
									<td>
										<?php echo $row['IssueTime']; ?>
									</td>
									<td>
										<?php 
										
											if ($row['Emp'] != "")
											{
												echo $row['Emp'];
											}
											else
											{
												echo $row['Admin'];
											} 
											
											?>
									</td>
									<td>
										<div class="checkbox check-success 	">
											<input id="chkReturn<?php echo $i; ?>" name="chkReturn<?php echo $i; ?>" type="checkbox" 
											       value="<?php echo $row['ISId']; ?>">
											<label for="chkReturn<?php echo $i; ?>"></label>
											<input type="hidden" id="txtIssueId<?php echo $i; ?>" value="<?php echo $row['ISId']; ?>" 
												   name="txtIssueId<?php echo $i; ?>" />
										</div>
									</td>
									
								</tr>
				<?php													
							}
							echo '<input type="hidden" id="txtReturnLength" name="txtReturnLength" value="'.$i.'" />';
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
				case "ShowIssuedProductList":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select a.IssueId,b.Code,c.ProName,a.Price,d.FullName,d.Cno,a.IssueTime,TIMESTAMPDIFF(HOUR,a.IssueTime,CURRENT_TIMESTAMP) as 'NoH',
										   if(a.UserType = 'Admin',(select FullName from adminuser where AdminId=a.UserId),
										     (select FullName from employeedetail where EmpId=a.UserId)) as 'IssuedBy'
									from issue_stock as a join stock as b join productmaster as c join customer as d on a.StockId=b.StockId and b.ProId=c.ProId and 
									a.CustId=d.CustId and a.IssueId not in (select IssueId from returnstock)
									order by TIMESTAMPDIFF(HOUR,a.IssueTime,CURRENT_TIMESTAMP) desc";
							$re  = $con->query($sql);
							$i = 0;
							foreach ($con->query($sql) as $row) 
							{		
								$i++;								
				?>		
								<tr>
									<td style="vertical-align:middle"><?php echo $i; ?></td>
									<td style="vertical-align:middle">
										<?php echo $row['Code']; ?>
									</td>
									<td style="vertical-align:middle">
										<?php echo $row['ProName']; ?>
									</td>
									<td style="vertical-align:middle">
										<?php echo $row['FullName']; ?>
									</td>
									<td style="vertical-align:middle">
										<?php echo $row['Cno']; ?>
									</td>
									<td style="vertical-align:middle">
										<?php echo $row['IssuedBy']; ?>
									</td>
									<td style="vertical-align:middle">
										<?php echo $row['IssueTime']; ?>
									</td>
									<td align="center" style="vertical-align:middle">
										<?php echo $row['NoH']; ?>
									</td>
									<td align="center" style="vertical-align:middle">
										<span onclick="getId('<?php echo $row['IssueId']; ?>')" data-toggle="modal" data-target="#ReturnStock"><img src="../Icon/Return.png" style="height:30px;width:30px" /></span>
									</td>
								</tr>
				<?php													
							}
							
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "ReturnSingleStock":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							//$Query = "UPDATE `issuestock` SET `AdminReturnId` = :ReturnId, `ReturnTime` = :Time WHERE `issuestock`.`ISId` = :Id";
									  
							$Query = "INSERT INTO `returnstock` (`RSId`, `IssueId`, `UserType`, `UserId`, `ReturnTime`, `DTId`) VALUES 
											 (NULL, :IssueId, :UserType, :UserId, :Time, NULL);";
											 
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':UserId' => $_REQUEST['ReturnId'], ':Time' => $_REQUEST['txtReturnDate'],
												   ':IssueId' => $_POST['txtIssueId'], ':UserType' => "Admin")))
							{
								echo "Data Successfully Saved";
							}
							
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
	}
	
?>