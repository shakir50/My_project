<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "select COALESCE(max(SeqNo), 0) as 'SeqNo' from customerseq where RoutId=".$_REQUEST['txtRoute'];
							$pre = $con->prepare($Query);
										
							if($pre->execute())
							{
								$Value = $pre->fetch();
							}
							
							$SeqNo = $Value['SeqNo'];
							
							$Query = "INSERT INTO `customerseq` (`CSId`, `CustId`, `SeqNo`, `RoutId`) VALUES (NULL, :CustId, :SeqNo, :RouteId);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':CustId' => $_REQUEST['txtCustomer'], ':SeqNo' => ($SeqNo + 1),
												   ':RouteId' => $_REQUEST['txtRoute'])))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Edit":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							for ($i = 1; $i < $_REQUEST['txtTableLength']; $i++)
							{
								$Query = "update customerseq set SeqNo= :SeqNo where CSId= :Id";
								$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
								
								if($pre->execute(array(':SeqNo' => $_REQUEST['txtSeqNo'.$i], ':Id' => $_REQUEST['txtSeqId'.$i])))
								{
									echo $Query;				   
								}
							}							
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Show":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select b.CSId,b.SeqNo,a.FullName,a.CustId from customer as a join customerseq as b on a.CustId=b.CustId and a.RoutId=".$_REQUEST['Id']." order by b.SeqNo";
							$re  = $con->query($sql);
							$i=0;
							foreach ($con->query($sql) as $row) 
							{	
								$i++;									
				?>	
								<tr>
									<td>
										<input type="text" style="width:100%;text-align:center" name="txtSeqNo<?php echo $i; ?>" 
											   id="txtSeqNo<?php echo $i; ?>" onkeypress="return isNumber(event)" value="<?php echo $row['SeqNo']; ?>" />
									</td>
									<td style="vertical-align:middle">
										<?php echo $row['FullName']; ?>
										<input type="hidden" name="txtSeqId<?php echo $i; ?>" id="txtSeqId<?php echo $i; ?>" 
										 	   value="<?php echo $row['CSId']; ?>" />
									</td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "Delete":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Delete From customer where CustId = :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Id' => $_REQUEST['Id'])))
							{
								echo "Data Successfully Removed";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "PopulateCustomer":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select * from customer where RoutId=".$_POST['RouteId']." and CustId not in (select CustId from customerseq)";
							$re  = $con->query($sql);
							echo "<option value=''>Select Customer</option>";
							foreach ($con->query($sql) as $row) 
							{										
				?>	
								<option value="<?php echo $row['CustId']; ?>">
									<?php echo $row['FullName']; ?>
								</option>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
										
					break;
	}
	
?>