<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "INSERT INTO `customer` (`CustId`, `FullName`, `Cno`, `Address`, `RoutId`, `Password`, `Status`, `CustType`, `Deposit`) VALUES (NULL, :FullName, :Cno, :Address, :RouteId, :Password, :Status, :Type, :Deposit);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':FullName' => $_REQUEST['txtCustomer'], ':Cno' => $_REQUEST['txtContact'],
												   ':Address' => $_REQUEST['txtAddress'], ':RouteId' => $_REQUEST['txtRoute'],
												   ':Password' => "123456", ':Status' => $_REQUEST['txtStatus'],
												   ':Type' => $_REQUEST['txtType'], ':Deposit' => $_REQUEST['txtDeposit'])))
							{
								$Query = "select * from productmaster";
								if (!$Result = mysqli_query($Con, $Query))
								{
									echo mysqli_error($Con);
								}
								while ($row = mysqli_fetch_array($Result))
								{
									$Query = "INSERT INTO `pricesetting` (`PSId`, `ProId`, `CustId`, `Price`) VALUES 
											 (NULL, '".$row['ProId']."',(select COALESCE(MAX(CustId),1) from customer), '".$row['Price']."');";
									mysqli_query($Con, $Query);
								}
							
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Edit":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Update customer set FullName= :FullName, Cno= :Cno, Address= :Address, RoutId= :RoutId, Status= :Status, CustType= :CustType, Deposit= :Deposit where CustId= :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':FullName' => $_REQUEST['txtCustomer'], ':Cno' => $_REQUEST['txtContact'],
												   ':Address' => $_REQUEST['txtAddress'], ':RoutId' => $_REQUEST['txtRoute'],
												   ':Id' => $_REQUEST['txtId'], ':Status' => $_REQUEST['txtStatus'],
												   ':CustType' => $_REQUEST['txtType'], ':Deposit' => $_REQUEST['txtDeposit'])))
							{
												   
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Show":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select * from customer as a join rout as b on a.RoutId = b.RoutId order by a.CustId desc";
							$re  = $con->query($sql);
							foreach ($con->query($sql) as $row) 
							{										
				?>	
								<tr>
									<td style="vertical-align:middle"><?php echo $row['FullName']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Cno']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Address']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['RoutName']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['CustType']; ?></td>
									<td style="vertical-align:middle">&#x20B9;<?php echo $row['Deposit']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Status']; ?></td>
									<td style="vertical-align:middle">
										<a href="#" data-toggle="modal" data-target="#PriceSetting" 
													onClick="ShowPrice('<?php echo $row['CustId']; ?>')">
											<img src="../Icon/Setting.png" style="width:20px;height:20px" ></a>
										<a href="#" data-toggle="modal" data-target="#AddCustomer" onClick="Edit('<?php echo $row['CustId']; ?>', '<?php echo $row['FullName']; ?>', '<?php echo $row['Cno']; ?>', '<?php echo $row['Address']; ?>', '<?php echo $row['RoutId']; ?>', '<?php echo $row['Status']; ?>', '<?php echo $row['CustType']; ?>', '<?php echo $row['Deposit']; ?>')">
											<img src="../Icon/Edit.png" style="width:20px;height:20px" ></a>
										<a href="#" onClick="Delete('<?php echo $row['CustId']; ?>')">
											<img src="../Icon/Delete.png" style="width:20px;height:20px" ></a>
										<a href="IssueReturnStock.php?CustId=<?php echo $row['CustId']; ?>" onClick="#">
											<img src="../Icon/Bottle.jpg" style="width:30px;height:30px" ></a>
									</td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "Delete":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Delete From customer where CustId = :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Id' => $_REQUEST['Id'])))
							{
								echo "Data Successfully Removed";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "PopulateCustomer":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select * from customer where RoutId=".$_POST['RouteId']." and CustId not in (select CustId from customerseq)";
							$re  = $con->query($sql);
							echo "<option value=''>Select Customer</option>";
							foreach ($con->query($sql) as $row) 
							{										
				?>	
								<option value="<?php echo $row['CustId']; ?>">
									<?php echo $row['FullName']; ?>
								</option>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
										
					break;
				
	}
	
?>