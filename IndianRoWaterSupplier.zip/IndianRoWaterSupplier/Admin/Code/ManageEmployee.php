<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							move_uploaded_file($_FILES["imgInp1"]["tmp_name"], "../EmployeePhoto/".$_FILES["imgInp1"]["name"]);
							$Query = "INSERT INTO `employeedetail` (`EmpId`, `FullName`, `Cno`, `Address`, `AdharNo`, `Photo`, `Status`, `Password`) VALUES (NULL, :Name, :Cno, :Address, :Adhar, :Photo, :Status, :Pass);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Name' => $_REQUEST['txtEmployee'], ':Cno' => $_REQUEST['txtContact'], 
												   ':Address' => $_REQUEST['txtAddress'], ':Adhar' => $_REQUEST['txtAdhar'],
												   ':Photo' => $_FILES["imgInp1"]["name"], ':Status' => "True", ':Pass' => "123456")))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Edit":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Update employeedetail set FullName= :Name, Cno= :Cno, Address= :Address, AdharNo= :AdharNo, Photo= :Photo where EmpId= :EmpId";
							$FileName = "";
							if ( $_FILES["imgInp1"]["name"] !=  "")
							{
								move_uploaded_file($_FILES["imgInp1"]["tmp_name"], "../EmployeePhoto/".$_FILES["imgInp1"]["name"]);
								$FileName = $_FILES["imgInp1"]["name"];
							}
							else
							{
								$FileName = $_POST['txtPhoto'];
							}
							
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Name' => $_REQUEST['txtEmployee'], ':Cno' => $_REQUEST['txtContact'], 
												   ':Address' => $_REQUEST['txtAddress'], ':AdharNo' => $_REQUEST['txtAdhar'],
												   ':Photo' => $FileName, 'EmpId' => $_POST['txtId'])))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Show":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "SELECT * FROM employeedetail order by EmpId desc";
							$re  = $con->query($sql);
							foreach ($con->query($sql) as $row) 
							{	
								$Path = "";
								if ($row['Photo'] == "")
								{
									$Path = "../Icon/User.png";
								}
								else
								{
									$Path = "EmployeePhoto/".$row['Photo'];
								}
																	
				?>	
								<tr>
									<td align="center"><img src="<?php echo $Path; ?>" style="height:80px;width:80px;border-radius: 50%"></td>
									<td style="vertical-align:middle"><?php echo $row['FullName']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Cno']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['Address']; ?></td>
									<td style="vertical-align:middle"><?php echo $row['AdharNo']; ?></td>
									<td style="vertical-align:middle">
									<a href="#" onClick="Delete('<?php echo $row['EmpId']; ?>')">
											<img src="../Icon/Delete.png" style="width:20px;height:20px" ></a>
									
									<a href="#"  onClick="Edit('<?php echo $row['EmpId']; ?>', '<?php echo $row['FullName']; ?>', '<?php echo $row['Cno']; ?>', '<?php echo $row['AdharNo']; ?>', '<?php echo $row['Address']; ?>', '<?php echo $row['Photo']; ?>')" data-toggle="modal" data-target="#AddEmployee" >
											<img src="../Icon/Edit.png" style="width:20px;height:20px" ></a>		
											
											
									</td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "Delete":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Delete From employeedetail where EmpId = :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Id' => $_REQUEST['Id'])))
							{
								echo "Data Successfully Removed";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
			break;	
			
			case "Login":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "select * from employeedetail where Cno= :Cno and Password= :Pass";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
										
							if($pre->execute(array(':Cno' => $_POST['txtCno'], ':Pass' => $_POST['txtPass'])))
							{
								$Value = $pre->fetch();
								if ($Value['Cno'] == $_POST['txtCno'] && $Value['Password'] == $_POST['txtPass'])
								{
									$Query = "select b.DTId,a.RoutId 
												from createtask as a 
												join dailytask as b on a.DTId=b.DTId and 
												date(b.TransecTime)='".date("Y-m-d")."' and 
												a.EmpId=".$Value['EmpId'];
									$res = mysqli_query($Con, $Query);
									
									if ($row = mysqli_fetch_array($res))
									{
										session_start();
										setcookie("EmpId", $Value['EmpId'], time() + (86400 * 30), "/");
										setcookie("DTId", $row['DTId'], time() + (86400 * 30), "/");
										setcookie("RouteId", $row['RoutId'], time() + (86400 * 30), "/");
										setcookie("Time", date('Y-m-d'), time() + (86400 * 30), "/");
										$_SESSION['ContactNo'] = $Value['Cno']; 
										$_SESSION['EmpId'] = $Value['EmpId'];
										$_SESSION['DTId'] = $row['DTId'];
										$_SESSION['FullName'] = $Value['FullName']; 
										$_SESSION['RouteId'] = $row['RoutId'];
										$_SESSION['Photo'] = $Value['Photo'];
										echo "Success Login";
									}
									else
									{
										echo "No Task For You Right Now";
									}
								}
								else
								{
									echo "Wrong UserName or Password";
								}
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
									
			break;
				
	}
	
	
	
?>