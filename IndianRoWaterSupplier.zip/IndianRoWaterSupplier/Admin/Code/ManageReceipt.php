<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
			case "ShowReceiptList":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
									
							$sql = "select b.CustId,b.FullName,sum(a.Price) as 'Total',COUNT(b.CustId) as 'NoI' from issue_stock as a join customer as b 									
on a.CustId=b.CustId and isnull(a.RecNo) and a.PaymentType='Credit' and a.IssueTime between '".$_REQUEST['DateFrom']."' and '".$_REQUEST['DateTo']."' group by b.FullName,b.CustId";
							$re  = $con->query($sql);
							$i = 0;
							
							foreach ($con->query($sql) as $row) 
							{		
								$i++;								
				?>		
								<tr>
									<td><?php echo $i; ?></td>
									<td>
										<?php echo $row['FullName']; ?>
									</td>
									<td>
										<?php echo $row['NoI']; ?>
									</td>
									<td>
										<?php echo $row['Total']; ?>
									</td>
									
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			
			case "CreateReceiptList":
					
						$sql = "select b.CustId,b.FullName,sum(a.Price) as 'Total',COUNT(b.CustId) as 'NoI' from issue_stock as a join customer as b 									
on a.CustId=b.CustId and isnull(a.RecNo) and a.PaymentType='Credit' and a.IssueTime between '".$_REQUEST['txtDateFrom']."' and '".$_REQUEST['txtDateTo']."' group by b.FullName,b.CustId";
								
						$res = mysqli_query($Con,$sql);
						
						while ($row = mysqli_fetch_row($res))
						{
							$Query = "INSERT INTO `receipt` (`RecId`, `CustId`, `Amount`, `RecDate`) VALUES (NULL, '".$row[0]."', '".$row[2]."', '".date('Y-m-d')."');";
							mysqli_query($Con, $Query);
							
							$Query = "update issue_stock set RecNo=(select COALESCE(MAX(RecId),1) from receipt) where isnull(RecNo) and CustId=".$row[0]." and
									  IssueTime between '".$_REQUEST['txtDateFrom']."' and '".$_REQUEST['txtDateTo']."'";
							if (! mysqli_query($Con, $Query))
							{
								echo mysqli_error($Con);
							}
						}
						echo "Data Successfully Saved";
					
					break;
		case "ShowBillsReceivable":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "select c.CustId,c.FullName,c.Cno, (select COALESCE(sum(Amount),0) from  billsreceivable where CustId=c.CustId) as 'Received',
								   (sum(b.Amount) - (select COALESCE(sum(Amount),0) from  billsreceivable where CustId=c.CustId)) as 'Remain',sum(b.Amount) as 'Total'
								   from receipt as b join customer as c on b.CustId=c.CustId 
								   group by c.CustId,c.FullName,c.Cno 
								   order by (sum(b.Amount) - (select COALESCE(sum(Amount),0) from  billsreceivable where CustId=c.CustId)) desc";
							
							$re  = $con->query($sql);
							$i = 0;
							
							foreach ($con->query($sql) as $row) 
							{	
								if ($row['Remain'] != "0")
								{	
								$i++;								
				?>		
									<tr>
										<td><?php echo $i; ?></td>
										<td>
											<?php echo $row['FullName']; ?>
										</td>
										<td>
											<?php echo $row['Cno']; ?>
										</td>
										<td>
											<?php echo $row['Received']; ?>
										</td>
										<td>
											<?php echo $row['Remain']; ?>
										</td>
										<td>
											<?php echo $row['Total']; ?>
										</td>
										<td>
											<span onclick="GetData('<?php echo $row['CustId']; ?>', '<?php echo $row['FullName']; ?>', '<?php echo $row['Remain']; ?>')" data-toggle="modal" data-target="#BillReceivable"><i class='fas fa-plus-square'></i></span>
										</td>
									</tr>
				<?php			
								}										
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "AddReceivableAmount":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "INSERT INTO `billsreceivable` (`BRId`, `CustId`, `Amount`, `Id`, `UserType`, `RecDate`, `EntryDate`) VALUES 
									 (NULL, :CustId, :Amount, :Id, :UserType, :RecDate, :EntryDate);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
							
							
										
							if($pre->execute(array(':CustId' => $_REQUEST['txtId'], ':Amount' => $_REQUEST['txtAmount'],
													':Id' => $_REQUEST['Id'], ':UserType' => "Admin",
													':RecDate' => $_REQUEST['txtRecDate'], ':EntryDate' => date('Y-m-d'))))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
	}
	
?>