<?php
	include"../../Config/Connection.php";
	$Choice = $_REQUEST['Choice'];

	switch($Choice)
	{
		case "Add":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "INSERT INTO `vehicledetail` (`VehId`, `VehNo`, `VehName`, `Status`) VALUES 
									 (NULL, :VehNo, :VehName, :Status);";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':VehNo' => $_REQUEST['txtVehNo'], ':VehName' => $_REQUEST['txtVehName'], 
											       ':Status' => $_REQUEST['txtVehStatus'])))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Edit":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Update vehicledetail set VehNo= :VehNo, VehName= :VehName, Status= :Status where VehId= :VehId";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':VehNo' => $_REQUEST['txtVehNo'], ':VehName' => $_REQUEST['txtVehName'], 
											       ':Status' => $_REQUEST['txtVehStatus'], ':VehId' => $_REQUEST['txtId'])))
							{
								echo "Data Successfully Saved";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;
			case "Show":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$sql = "SELECT * FROM vehicledetail order by VehId desc";
							$re  = $con->query($sql);
							foreach ($con->query($sql) as $row) 
							{										
				?>	
								<tr>
									<td><?php echo $row['VehNo']; ?></td>
									<td><?php echo $row['VehName']; ?></td>
									<td><?php echo $row['Status']; ?></td>
									<td>
										<a href="#" onClick="Update('<?php echo $row['VehId']; ?>', '<?php echo $row['VehName']; ?>', '<?php echo $row['VehNo']; ?>', '<?php echo $row['Status']; ?>')">
											<img src="../Icon/Edit.png" style="width:20px;height:20px" ></a>
										<a href="#" onClick="Delete('<?php echo $row['VehId']; ?>')">
											<img src="../Icon/Delete.png" style="width:20px;height:20px" ></a>
									</td>
								</tr>
				<?php													
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
			case "Delete":
					try
					{
						$conec = new Connection();
						$con = $conec->Open();
						if($con)
						{
							$Query = "Delete From vehicledetail where VehId = :Id";
							$pre = $con->prepare($Query,array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
																		
							if($pre->execute(array(':Id' => $_REQUEST['Id'])))
							{
								echo "Data Successfully Removed";
							}
						}
						else
						{
							echo $con;
						}
					}
					catch(PDOException $ex)
					{
						echo "Error:<br>".$ex->getMessage();
					}
					break;	
	}
	
?>