 <?php include"Top.php"; ?>
	
	 <div class="page-content">
	 	<form method="post" id="form" name="form">
		<script>
			$(document).ready(function() 
			{
				$("#btnSave").click(function() 
				{
					var cnt = 0;
					var Element = ['RoutName'];
					var Values = ['RoutName'];
					for (i = 0; i < Element.length; i++)
					{
						var txtName = "txt" + Element[i];
						var lblName = "lbl" + Element[i];
						var Value = document.getElementById(txtName).value;
						Values[i] = Value;
						if ( Value == "")
						{
							cnt++;
							document.getElementById(lblName).innerText = "*Required";
						}
						else
						{
							document.getElementById(lblName).innerText = "*";
						}
					}
					
					if (cnt == 0) 
					{
						var Id = document.getElementById("txtId").value;
						var Ch = "";
						if (Id != "")
						{
							Ch = "Edit";
						}
						else
						{
							Ch = "Add";
						}
						
						// Returns successful data submission message when the entered information is stored in database.
						$.post("Code/ManageRout.php", 
						{							
							RoutName: Values[0],
							RoutId: Id,
							Choice: Ch
						}, 
						function(data) 
						{
							alert(data);
							$('#form')[0].reset(); // To reset form fields
							ShowData();
						});
					}
				});
			});
			
			function Delete(DelId)
			{
				var Result = confirm('Are You Sure Want to Delete...');
				if (Result == true)
				{
					$.post("Code/ManageRout.php", 
					{
						Id: DelId,
						Choice: "Delete"
					}, 
					function(data) 
					{
						alert(data);
						$('#form')[0].reset(); // To reset form fields
						ShowData();
					});
				}
			}
			
			function ShowData()
			{
				$('#Disp').load('Code/ManageRout.php?Choice=Show');
			}
			
			function Clear()
			{
				document.getElementById("txtId").value = "";
			}
			
			function Update(Id, RoutName)
			{
				document.getElementById("txtId").value = Id;
				document.getElementById("txtRoutName").value = RoutName;
			}
		</script>
		
		
			<input type="hidden" id="txtId" name="txtId" value="" />
			<div class="clearfix">
			</div>
			<div class="content">
				<div class="row">
					<div class="col-md-6">
						<div class="grid simple">
							<div class="grid-title no-border">
								<h4>Add Route</h4>
							</div>
							<div class="grid-body no-border">
								 <div class="row">
								 	<div class="col-md-12">
										<div class="form-group">
											<label style="font-weight:bold">Route Name <span style="color:red" id="lblRoutName">*</span></label>
											<div class="control">
												<input type="text" name="txtRoutName" id="txtRoutName" placeholder="Enter Rout Name" class="form-control" />
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<button type="button" name="btnSave" id="btnSave" class="btn btn-primary btn-cons">Save</button>
										<input type="reset" onclick="Clear();" value="Cancle" class="btn btn-primary btn-cons" />
									</div>
								 </div>   
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="grid simple">
							<div class="grid-title no-border">
								<h4>Show Route</h4>
							</div>
							<div class="grid-body no-border">
								<div class="table-responsive">
									<table class="table">
										<tr>
											<th>Route Name</th>
											<th>Action</th>
										</tr>
										<tbody id="Disp">
										
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
	<script>
		ShowData();
	</script>
<?php include"Bottom.php"; ?>