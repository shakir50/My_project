-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 07, 2019 at 02:15 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `indianrowater`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminuser`
--

DROP TABLE IF EXISTS `adminuser`;
CREATE TABLE IF NOT EXISTS `adminuser` (
  `AdminId` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` text NOT NULL,
  `Cno` text NOT NULL,
  `Email` text NOT NULL,
  `Address` text NOT NULL,
  `Photo` text NOT NULL,
  `Password` text NOT NULL,
  PRIMARY KEY (`AdminId`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminuser`
--

INSERT INTO `adminuser` (`AdminId`, `FullName`, `Cno`, `Email`, `Address`, `Photo`, `Password`) VALUES
(3, 'Asif Bhai Diwan', '9409205913', 'asifdiwan@gmail.com', 'Bharuch', '14750_Arafat-Passport Size.jpg', '123');

-- --------------------------------------------------------

--
-- Table structure for table `billsreceivable`
--

DROP TABLE IF EXISTS `billsreceivable`;
CREATE TABLE IF NOT EXISTS `billsreceivable` (
  `BRId` int(11) NOT NULL AUTO_INCREMENT,
  `CustId` int(11) NOT NULL,
  `Amount` float NOT NULL,
  `Id` int(11) NOT NULL,
  `UserType` text NOT NULL,
  `RecDate` date NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`BRId`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billsreceivable`
--

INSERT INTO `billsreceivable` (`BRId`, `CustId`, `Amount`, `Id`, `UserType`, `RecDate`, `EntryDate`) VALUES
(5, 24, 50, 2, 'Employee', '2019-07-31', '2019-07-31'),
(6, 17, 100, 2, 'Employee', '2019-07-31', '2019-07-31');

-- --------------------------------------------------------

--
-- Table structure for table `createtask`
--

DROP TABLE IF EXISTS `createtask`;
CREATE TABLE IF NOT EXISTS `createtask` (
  `CTId` int(11) NOT NULL AUTO_INCREMENT,
  `DTId` int(11) NOT NULL,
  `RoutId` int(11) NOT NULL,
  `EmpId` int(11) NOT NULL,
  `VehId` int(11) NOT NULL,
  `TransecTime` datetime NOT NULL,
  PRIMARY KEY (`CTId`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `createtask`
--

INSERT INTO `createtask` (`CTId`, `DTId`, `RoutId`, `EmpId`, `VehId`, `TransecTime`) VALUES
(9, 3, 8, 3, 3, '2019-08-04 11:32:43'),
(8, 3, 8, 2, 3, '2019-08-04 11:32:43'),
(7, 2, 8, 3, 3, '2019-07-28 11:29:26'),
(6, 2, 8, 2, 3, '2019-07-28 11:29:26');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `CustId` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` text NOT NULL,
  `Cno` text NOT NULL,
  `Address` text NOT NULL,
  `RoutId` int(11) NOT NULL,
  `Password` text NOT NULL,
  `Status` text NOT NULL,
  `CustType` text NOT NULL,
  `Deposit` int(11) NOT NULL,
  PRIMARY KEY (`CustId`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustId`, `FullName`, `Cno`, `Address`, `RoutId`, `Password`, `Status`, `CustType`, `Deposit`) VALUES
(17, 'Honest Computer Service', '9658747856', '207, Ganesh Arcade, Dahej By Pass Road, Bharuch City, Bharuch - 392001, Above MRF Tyre', 8, '123456', 'Continue', 'Cash', 500),
(18, 'Raj Computer & CCTV', '9532547854', 'FF-108 Rang Pravesh Complex, Behind Rungta School, Bharuch City, Bharuch - 392001, Opp : Care & Cure Hospital', 9, '123456', 'Continue', 'Daily', 500),
(19, 'N G Computer', '9632547854', 'Shop No 112 First Floor Samrajya Complex, Dates Bypass, Bharuch HO, Bharuch - 392001, Near Sravan Chowkdi', 7, '123456', 'Continue', 'Daily', 500),
(20, 'Infinity Computer Centre', '9874521452', '204-205, Harihar Complex, Near Inox Cinema, Zadeshwar Road, Bharuch - 392011, Near Tulsidham', 8, '123456', 'Continue', 'Daily', 500),
(21, 'Prayosha Electronics', '9635878965', 'Shop No-12, Nagar Palica Shopping Center, Tankari Bhagol, Jambusar, Bharuch - 392150, Nr DJ Shah High School', 10, '123456', 'Continue', 'Daily', 500),
(22, 'Sumit Computer', '8547854123', 'F 11 Zazpmzam Residency, N H 8, Bharuch Railway Station, Bharuch - 392001', 7, '123456', 'Continue', 'Daily', 500),
(23, 'Media Infocom', '8632145878', '7 Jay Commercial Complex, Main Station Road, Panch Batti, Bharuch - 392001, Opposite Indianoil Petrol Pump Near Big Bazar', 10, '123456', 'Continue', 'Daily', 500),
(24, 'Sony Exclusive Store', '9635874785', 'Mirambica Complex, Dahej By Pass Road, Shravan Cross Roads, Bharuch - 392001', 8, '123456', 'Continue', 'Daily', 500),
(25, 'Hotel Kohinoor', '9854752123', 'Hotel Kohinoor Hilton Plaza, Railway Station Road, Bholav, Bharuch - 392001, Opposite Railway Station West', 8, '123456', 'Continue', 'Daily', 500),
(26, 'Hotel Virgoseasens', '9632541478', 'Plot No 81, Ipcl Road, Dahej Bharuch, Bharuch - 392130', 8, '123456', 'Continue', 'Daily', 500),
(27, 'Patel Ni Motel', '7854123698', 'Hotel Patel Ni Motel, Narmada Chokdi, N.H. No8, Jadeswar, Bharuch - 392015, Opposite Gnfc Golf Club', 8, '123456', 'Continue', 'Daily', 500);

-- --------------------------------------------------------

--
-- Table structure for table `customerseq`
--

DROP TABLE IF EXISTS `customerseq`;
CREATE TABLE IF NOT EXISTS `customerseq` (
  `CSId` int(11) NOT NULL AUTO_INCREMENT,
  `CustId` int(11) NOT NULL,
  `SeqNo` int(11) NOT NULL,
  `RoutId` int(11) NOT NULL,
  PRIMARY KEY (`CSId`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customerseq`
--

INSERT INTO `customerseq` (`CSId`, `CustId`, `SeqNo`, `RoutId`) VALUES
(13, 17, 1, 8),
(14, 20, 2, 8),
(15, 24, 3, 8),
(16, 18, 1, 9),
(17, 19, 1, 7),
(18, 22, 2, 7);

-- --------------------------------------------------------

--
-- Table structure for table `dailytask`
--

DROP TABLE IF EXISTS `dailytask`;
CREATE TABLE IF NOT EXISTS `dailytask` (
  `DTId` int(11) NOT NULL AUTO_INCREMENT,
  `TaskId` int(11) NOT NULL,
  `TransecTime` datetime NOT NULL,
  `Status` text NOT NULL,
  PRIMARY KEY (`DTId`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dailytask`
--

INSERT INTO `dailytask` (`DTId`, `TaskId`, `TransecTime`, `Status`) VALUES
(2, 2, '2019-07-30 11:29:26', 'Finish'),
(3, 2, '2019-08-04 11:32:43', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `damagestock`
--

DROP TABLE IF EXISTS `damagestock`;
CREATE TABLE IF NOT EXISTS `damagestock` (
  `DId` int(11) NOT NULL AUTO_INCREMENT,
  `StockId` int(11) NOT NULL,
  `TransecId` datetime NOT NULL,
  `UserId` int(11) NOT NULL,
  `UserType` text NOT NULL,
  `DTId` int(11) DEFAULT NULL,
  PRIMARY KEY (`DId`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `damagestock`
--

INSERT INTO `damagestock` (`DId`, `StockId`, `TransecId`, `UserId`, `UserType`, `DTId`) VALUES
(3, 52, '2019-07-31 18:03:12', 2, 'Employee', 2),
(4, 156, '2019-08-01 10:33:12', 3, 'Admin', NULL),
(6, 155, '2019-08-01 10:36:49', 3, 'Admin', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employeedetail`
--

DROP TABLE IF EXISTS `employeedetail`;
CREATE TABLE IF NOT EXISTS `employeedetail` (
  `EmpId` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` text NOT NULL,
  `Cno` text NOT NULL,
  `Address` text NOT NULL,
  `AdharNo` text NOT NULL,
  `Photo` text NOT NULL,
  `Status` text NOT NULL,
  `Password` text NOT NULL,
  PRIMARY KEY (`EmpId`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeedetail`
--

INSERT INTO `employeedetail` (`EmpId`, `FullName`, `Cno`, `Address`, `AdharNo`, `Photo`, `Status`, `Password`) VALUES
(2, 'Minhaz Lariya', '9409205913', 'Bharuch', '1222356985', '2.jpg', 'True', '123456'),
(3, 'Lariya Fahim', '9632541525', 'Bharuch', '1235214585', 'maxwiseltier_1394675058_41.jpg', 'True', '123456'),
(4, 'Roshni Patel', '9854785878', 'Bharuch', '1236985478', 'avatar1.jpg', 'True', '123456'),
(5, 'Rishab Panth', '9658745214', 'Bharuch', '1236985478', '9675student.jpg', 'True', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
CREATE TABLE IF NOT EXISTS `expense` (
  `ExpId` int(11) NOT NULL AUTO_INCREMENT,
  `ExpTypeId` int(11) NOT NULL,
  `ExpFor` text NOT NULL,
  `BillNo` text NOT NULL,
  `Amount` float NOT NULL,
  `Description` text NOT NULL,
  `ExpDate` date NOT NULL,
  `EntryDate` datetime NOT NULL,
  PRIMARY KEY (`ExpId`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`ExpId`, `ExpTypeId`, `ExpFor`, `BillNo`, `Amount`, `Description`, `ExpDate`, `EntryDate`) VALUES
(1, 1, 'Eletricity Bill', 'E1250', 12550, 'This Bill For The Best ', '2019-08-07', '2019-08-07 14:35:00'),
(2, 1, 'Sul Bhai', '1', 500, 'This is for Salary', '2019-08-07', '2019-08-07 11:50:36');

-- --------------------------------------------------------

--
-- Table structure for table `expensetype`
--

DROP TABLE IF EXISTS `expensetype`;
CREATE TABLE IF NOT EXISTS `expensetype` (
  `ExpTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `ExpTypeName` text NOT NULL,
  PRIMARY KEY (`ExpTypeId`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expensetype`
--

INSERT INTO `expensetype` (`ExpTypeId`, `ExpTypeName`) VALUES
(1, 'Salary'),
(3, 'Electricity');

-- --------------------------------------------------------

--
-- Table structure for table `issuestock`
--

DROP TABLE IF EXISTS `issuestock`;
CREATE TABLE IF NOT EXISTS `issuestock` (
  `ISId` int(11) NOT NULL AUTO_INCREMENT,
  `StockId` int(11) NOT NULL,
  `CustId` int(11) NOT NULL,
  `Status` text NOT NULL,
  `IssueEmpId` int(11) DEFAULT NULL,
  `ReturnEmpId` int(11) DEFAULT NULL,
  `AdminIssueId` int(11) DEFAULT NULL,
  `AdminReturnId` int(11) DEFAULT NULL,
  `IssueTime` datetime NOT NULL,
  `ReturnTime` datetime DEFAULT NULL,
  `Price` float NOT NULL,
  `RecNo` int(11) DEFAULT NULL,
  PRIMARY KEY (`ISId`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issuestock`
--

INSERT INTO `issuestock` (`ISId`, `StockId`, `CustId`, `Status`, `IssueEmpId`, `ReturnEmpId`, `AdminIssueId`, `AdminReturnId`, `IssueTime`, `ReturnTime`, `Price`, `RecNo`) VALUES
(84, 2, 24, 'Credit', NULL, NULL, 3, 3, '2019-07-19 11:02:00', '2019-07-19 15:00:00', 25, NULL),
(85, 3, 24, 'Credit', NULL, NULL, 3, NULL, '2019-07-19 11:02:00', NULL, 25, NULL),
(86, 4, 24, 'Credit', NULL, NULL, 3, NULL, '2019-07-19 11:02:00', NULL, 25, NULL),
(87, 5, 24, 'Credit', NULL, NULL, 3, NULL, '2019-07-19 11:02:00', NULL, 25, NULL),
(88, 52, 23, 'Credit', NULL, NULL, 3, NULL, '2019-07-19 11:02:00', NULL, 15, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `issue_stock`
--

DROP TABLE IF EXISTS `issue_stock`;
CREATE TABLE IF NOT EXISTS `issue_stock` (
  `IssueId` int(11) NOT NULL AUTO_INCREMENT,
  `StockId` int(11) NOT NULL,
  `CustId` int(11) NOT NULL,
  `UserType` text NOT NULL,
  `UserId` int(11) NOT NULL,
  `IssueTime` datetime NOT NULL,
  `Price` float NOT NULL,
  `PaymentType` text NOT NULL,
  `RecNo` int(11) DEFAULT NULL,
  `DTId` int(11) DEFAULT NULL,
  PRIMARY KEY (`IssueId`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue_stock`
--

INSERT INTO `issue_stock` (`IssueId`, `StockId`, `CustId`, `UserType`, `UserId`, `IssueTime`, `Price`, `PaymentType`, `RecNo`, `DTId`) VALUES
(7, 2, 23, 'Admin', 3, '2019-07-29 11:25:00', 25, 'Credit', 8, NULL),
(2, 2, 24, 'Admin', 3, '2019-07-10 10:44:00', 25, 'Credit', 10, NULL),
(3, 6, 24, 'Admin', 3, '2019-07-10 10:44:00', 25, 'Credit', 10, NULL),
(4, 7, 24, 'Admin', 3, '2019-07-10 10:44:00', 25, 'Credit', 10, NULL),
(5, 8, 24, 'Admin', 3, '2019-07-10 10:44:00', 25, 'Credit', 10, NULL),
(6, 9, 24, 'Admin', 3, '2019-07-10 10:44:00', 25, 'Credit', 10, NULL),
(8, 3, 23, 'Admin', 3, '2019-07-29 11:25:00', 25, 'Credit', 8, NULL),
(9, 4, 23, 'Admin', 3, '2019-07-29 11:25:00', 25, 'Credit', 8, NULL),
(10, 49, 19, 'Admin', 3, '2019-07-29 11:26:00', 25, 'Credit', 9, NULL),
(11, 50, 19, 'Admin', 3, '2019-07-29 11:26:00', 25, 'Credit', 9, NULL),
(12, 51, 19, 'Admin', 3, '2019-07-29 11:26:00', 25, 'Credit', 9, NULL),
(17, 3, 17, 'Employee', 2, '2019-07-30 13:36:53', 25, 'Credit', NULL, 2),
(16, 2, 17, 'Employee', 2, '2019-07-30 13:36:53', 25, 'Credit', NULL, 2),
(18, 4, 17, 'Employee', 2, '2019-07-30 13:36:53', 25, 'Credit', NULL, 2),
(19, 5, 17, 'Employee', 2, '2019-07-31 10:43:45', 25, 'Credit', NULL, 2),
(20, 7, 17, 'Employee', 2, '2019-07-31 10:43:45', 25, 'Credit', NULL, 2),
(21, 6, 17, 'Employee', 2, '2019-07-31 10:43:45', 25, 'Credit', NULL, 2),
(22, 8, 17, 'Employee', 2, '2019-07-31 10:43:45', 25, 'Credit', NULL, 2),
(23, 9, 17, 'Employee', 2, '2019-07-31 10:43:45', 25, 'Credit', NULL, 2),
(24, 10, 19, 'Employee', 2, '2019-07-31 17:23:47', 25, 'Credit', NULL, 2),
(25, 11, 19, 'Employee', 2, '2019-07-31 17:23:47', 25, 'Credit', NULL, 2),
(26, 12, 19, 'Employee', 2, '2019-07-31 17:23:47', 25, 'Credit', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `loadstock`
--

DROP TABLE IF EXISTS `loadstock`;
CREATE TABLE IF NOT EXISTS `loadstock` (
  `LSId` int(11) NOT NULL AUTO_INCREMENT,
  `DTId` int(11) NOT NULL,
  `ProId` int(11) NOT NULL,
  `StockId` int(11) NOT NULL,
  PRIMARY KEY (`LSId`)
) ENGINE=MyISAM AUTO_INCREMENT=369 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loadstock`
--

INSERT INTO `loadstock` (`LSId`, `DTId`, `ProId`, `StockId`) VALUES
(363, 3, 5, 2),
(362, 2, 5, 17),
(361, 2, 5, 16),
(360, 2, 5, 15),
(359, 2, 5, 14),
(358, 2, 5, 13),
(364, 3, 5, 3),
(365, 3, 5, 4),
(366, 3, 5, 5),
(367, 3, 5, 6),
(368, 3, 5, 7);

-- --------------------------------------------------------

--
-- Table structure for table `pricesetting`
--

DROP TABLE IF EXISTS `pricesetting`;
CREATE TABLE IF NOT EXISTS `pricesetting` (
  `PSId` int(11) NOT NULL AUTO_INCREMENT,
  `ProId` int(11) NOT NULL,
  `CustId` int(11) NOT NULL,
  `Price` float NOT NULL,
  PRIMARY KEY (`PSId`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pricesetting`
--

INSERT INTO `pricesetting` (`PSId`, `ProId`, `CustId`, `Price`) VALUES
(11, 1, 13, 15),
(10, 10, 12, 20),
(9, 6, 12, 15),
(8, 5, 12, 25),
(7, 1, 12, 15),
(12, 5, 13, 25),
(13, 6, 13, 15),
(14, 10, 13, 20),
(15, 1, 14, 15),
(16, 5, 14, 25),
(17, 6, 14, 15),
(18, 10, 14, 20),
(19, 1, 15, 15),
(20, 5, 15, 25),
(21, 6, 15, 15),
(22, 10, 15, 20),
(23, 1, 16, 15),
(24, 5, 16, 25),
(25, 6, 16, 15),
(26, 10, 16, 20),
(27, 1, 17, 15),
(28, 5, 17, 25),
(29, 6, 17, 15),
(30, 10, 17, 20),
(31, 1, 18, 15),
(32, 5, 18, 25),
(33, 6, 18, 15),
(34, 10, 18, 20),
(35, 1, 19, 15),
(36, 5, 19, 25),
(37, 6, 19, 15),
(38, 10, 19, 20),
(39, 1, 20, 15),
(40, 5, 20, 25),
(41, 6, 20, 15),
(42, 10, 20, 20),
(43, 1, 21, 15),
(44, 5, 21, 25),
(45, 6, 21, 15),
(46, 10, 21, 20),
(47, 1, 22, 15),
(48, 5, 22, 25),
(49, 6, 22, 15),
(50, 10, 22, 20),
(51, 1, 23, 15),
(52, 5, 23, 25),
(53, 6, 23, 15),
(54, 10, 23, 20),
(55, 1, 24, 15),
(56, 5, 24, 25),
(57, 6, 24, 15),
(58, 10, 24, 20),
(59, 1, 25, 15),
(60, 5, 25, 25),
(61, 6, 25, 15),
(62, 10, 25, 20),
(63, 1, 26, 15),
(64, 5, 26, 25),
(65, 6, 26, 15),
(66, 10, 26, 20),
(67, 1, 27, 15),
(68, 5, 27, 25),
(69, 6, 27, 15),
(70, 10, 27, 20);

-- --------------------------------------------------------

--
-- Table structure for table `productmaster`
--

DROP TABLE IF EXISTS `productmaster`;
CREATE TABLE IF NOT EXISTS `productmaster` (
  `ProId` int(11) NOT NULL AUTO_INCREMENT,
  `ProName` text NOT NULL,
  `Price` float NOT NULL,
  `Code` text NOT NULL,
  PRIMARY KEY (`ProId`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productmaster`
--

INSERT INTO `productmaster` (`ProId`, `ProName`, `Price`, `Code`) VALUES
(1, '20 ltr Bottle', 15, 'BTL20'),
(5, '20 ltr Cooler', 25, 'CL20'),
(6, '10 ltr Bottle', 15, 'Btl10'),
(10, '15 ltr Bottle', 20, 'BTL15');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

DROP TABLE IF EXISTS `receipt`;
CREATE TABLE IF NOT EXISTS `receipt` (
  `RecId` int(11) NOT NULL AUTO_INCREMENT,
  `CustId` int(11) NOT NULL,
  `Amount` int(11) NOT NULL,
  `RecDate` date NOT NULL,
  PRIMARY KEY (`RecId`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receipt`
--

INSERT INTO `receipt` (`RecId`, `CustId`, `Amount`, `RecDate`) VALUES
(8, 23, 75, '2019-07-29'),
(9, 19, 75, '2019-07-29'),
(10, 24, 125, '2019-07-29');

-- --------------------------------------------------------

--
-- Table structure for table `returnstock`
--

DROP TABLE IF EXISTS `returnstock`;
CREATE TABLE IF NOT EXISTS `returnstock` (
  `RSId` int(11) NOT NULL AUTO_INCREMENT,
  `IssueId` int(11) NOT NULL,
  `UserType` text NOT NULL,
  `UserId` int(11) NOT NULL,
  `ReturnTime` datetime NOT NULL,
  `DTId` int(11) DEFAULT NULL,
  PRIMARY KEY (`RSId`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `returnstock`
--

INSERT INTO `returnstock` (`RSId`, `IssueId`, `UserType`, `UserId`, `ReturnTime`, `DTId`) VALUES
(2, 2, 'Admin', 3, '2019-07-29 12:00:00', NULL),
(3, 3, 'Admin', 3, '2019-07-29 12:00:00', NULL),
(4, 4, 'Admin', 3, '2019-07-29 12:00:00', NULL),
(5, 10, 'Admin', 3, '2019-07-29 12:00:00', NULL),
(6, 11, 'Admin', 3, '2019-07-29 12:00:00', NULL),
(7, 12, 'Admin', 3, '2019-07-29 12:00:00', NULL),
(8, 5, 'Admin', 3, '2019-07-29 12:00:00', NULL),
(9, 17, 'Employee', 2, '2019-07-30 14:08:03', 2),
(10, 16, 'Employee', 2, '2019-07-30 14:08:12', 2);

-- --------------------------------------------------------

--
-- Table structure for table `rout`
--

DROP TABLE IF EXISTS `rout`;
CREATE TABLE IF NOT EXISTS `rout` (
  `RoutId` int(11) NOT NULL AUTO_INCREMENT,
  `RoutName` text NOT NULL,
  PRIMARY KEY (`RoutId`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rout`
--

INSERT INTO `rout` (`RoutId`, `RoutName`) VALUES
(9, 'Super Market'),
(8, 'Zadeshwar'),
(4, 'GIDC-2'),
(6, 'Depot'),
(7, 'Railway Yard');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `StockId` int(11) NOT NULL AUTO_INCREMENT,
  `ProId` int(11) NOT NULL,
  `Code` text NOT NULL,
  `InwardDate` date NOT NULL,
  PRIMARY KEY (`StockId`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`StockId`, `ProId`, `Code`, `InwardDate`) VALUES
(52, 1, 'BTL201', '2019-06-21'),
(2, 5, 'CL201', '2019-06-20'),
(3, 5, 'CL202', '2019-06-20'),
(4, 5, 'CL203', '2019-06-20'),
(5, 5, 'CL204', '2019-06-20'),
(6, 5, 'CL205', '2019-06-20'),
(7, 5, 'CL206', '2019-06-20'),
(8, 5, 'CL207', '2019-06-20'),
(9, 5, 'CL208', '2019-06-20'),
(10, 5, 'CL209', '2019-06-20'),
(11, 5, 'CL2010', '2019-06-20'),
(12, 5, 'CL2011', '2019-06-20'),
(13, 5, 'CL2012', '2019-06-20'),
(14, 5, 'CL2013', '2019-06-20'),
(15, 5, 'CL2014', '2019-06-20'),
(16, 5, 'CL2015', '2019-06-20'),
(17, 5, 'CL2016', '2019-06-20'),
(18, 5, 'CL2017', '2019-06-20'),
(19, 5, 'CL2018', '2019-06-20'),
(20, 5, 'CL2019', '2019-06-20'),
(21, 5, 'CL2020', '2019-06-20'),
(22, 5, 'CL2021', '2019-06-20'),
(23, 5, 'CL2022', '2019-06-20'),
(24, 5, 'CL2023', '2019-06-20'),
(25, 5, 'CL2024', '2019-06-20'),
(26, 5, 'CL2025', '2019-06-20'),
(27, 5, 'CL2026', '2019-06-20'),
(28, 5, 'CL2027', '2019-06-20'),
(29, 5, 'CL2028', '2019-06-20'),
(30, 5, 'CL2029', '2019-06-20'),
(31, 5, 'CL2030', '2019-06-20'),
(32, 5, 'CL2031', '2019-06-20'),
(33, 5, 'CL2032', '2019-06-20'),
(34, 5, 'CL2033', '2019-06-20'),
(35, 5, 'CL2034', '2019-06-20'),
(36, 5, 'CL2035', '2019-06-20'),
(37, 5, 'CL2036', '2019-06-20'),
(38, 5, 'CL2037', '2019-06-20'),
(39, 5, 'CL2038', '2019-06-20'),
(40, 5, 'CL2039', '2019-06-20'),
(41, 5, 'CL2040', '2019-06-20'),
(42, 5, 'CL2041', '2019-06-20'),
(43, 5, 'CL2042', '2019-06-20'),
(44, 5, 'CL2043', '2019-06-20'),
(45, 5, 'CL2044', '2019-06-20'),
(46, 5, 'CL2045', '2019-06-20'),
(47, 5, 'CL2046', '2019-06-20'),
(48, 5, 'CL2047', '2019-06-20'),
(49, 5, 'CL2048', '2019-06-20'),
(50, 5, 'CL2049', '2019-06-20'),
(51, 5, 'CL2050', '2019-06-20'),
(53, 1, 'BTL202', '2019-06-21'),
(54, 1, 'BTL203', '2019-06-21'),
(55, 1, 'BTL204', '2019-06-21'),
(56, 1, 'BTL205', '2019-06-21'),
(57, 1, 'BTL206', '2019-06-21'),
(58, 1, 'BTL207', '2019-06-21'),
(59, 1, 'BTL208', '2019-06-21'),
(60, 1, 'BTL209', '2019-06-21'),
(61, 1, 'BTL2010', '2019-06-21'),
(62, 1, 'BTL2011', '2019-06-21'),
(63, 1, 'BTL2012', '2019-06-21'),
(64, 1, 'BTL2013', '2019-06-21'),
(65, 1, 'BTL2014', '2019-06-21'),
(66, 1, 'BTL2015', '2019-06-21'),
(67, 1, 'BTL2016', '2019-06-21'),
(68, 1, 'BTL2017', '2019-06-21'),
(69, 1, 'BTL2018', '2019-06-21'),
(70, 1, 'BTL2019', '2019-06-21'),
(71, 1, 'BTL2020', '2019-06-21'),
(72, 1, 'BTL2021', '2019-06-21'),
(73, 1, 'BTL2022', '2019-06-21'),
(74, 1, 'BTL2023', '2019-06-21'),
(75, 1, 'BTL2024', '2019-06-21'),
(76, 1, 'BTL2025', '2019-06-21'),
(77, 1, 'BTL2026', '2019-06-21'),
(78, 1, 'BTL2027', '2019-06-21'),
(79, 1, 'BTL2028', '2019-06-21'),
(80, 1, 'BTL2029', '2019-06-21'),
(81, 1, 'BTL2030', '2019-06-21'),
(82, 1, 'BTL2031', '2019-06-21'),
(83, 1, 'BTL2032', '2019-06-21'),
(84, 1, 'BTL2033', '2019-06-21'),
(85, 1, 'BTL2034', '2019-06-21'),
(86, 1, 'BTL2035', '2019-06-21'),
(87, 1, 'BTL2036', '2019-06-21'),
(88, 1, 'BTL2037', '2019-06-21'),
(89, 1, 'BTL2038', '2019-06-21'),
(90, 1, 'BTL2039', '2019-06-21'),
(91, 1, 'BTL2040', '2019-06-21'),
(92, 1, 'BTL2041', '2019-06-21'),
(93, 1, 'BTL2042', '2019-06-21'),
(94, 1, 'BTL2043', '2019-06-21'),
(95, 1, 'BTL2044', '2019-06-21'),
(96, 1, 'BTL2045', '2019-06-21'),
(97, 1, 'BTL2046', '2019-06-21'),
(98, 1, 'BTL2047', '2019-06-21'),
(99, 1, 'BTL2048', '2019-06-21'),
(100, 1, 'BTL2049', '2019-06-21'),
(101, 1, 'BTL2050', '2019-06-21'),
(102, 1, 'BTL2051', '2019-06-21'),
(103, 1, 'BTL2052', '2019-06-21'),
(104, 1, 'BTL2053', '2019-06-21'),
(105, 1, 'BTL2054', '2019-06-21'),
(106, 1, 'BTL2055', '2019-06-21'),
(107, 6, 'Btl101', '2019-06-21'),
(108, 6, 'Btl102', '2019-06-21'),
(109, 6, 'Btl103', '2019-06-21'),
(110, 6, 'Btl104', '2019-06-21'),
(111, 6, 'Btl105', '2019-06-21'),
(112, 6, 'Btl106', '2019-06-21'),
(113, 6, 'Btl107', '2019-06-21'),
(114, 6, 'Btl108', '2019-06-21'),
(115, 6, 'Btl109', '2019-06-21'),
(116, 6, 'Btl1010', '2019-06-21'),
(117, 6, 'Btl1011', '2019-06-21'),
(118, 6, 'Btl1012', '2019-06-21'),
(119, 6, 'Btl1013', '2019-06-21'),
(120, 6, 'Btl1014', '2019-06-21'),
(121, 6, 'Btl1015', '2019-06-21'),
(122, 6, 'Btl1016', '2019-06-21'),
(123, 6, 'Btl1017', '2019-06-21'),
(124, 6, 'Btl1018', '2019-06-21'),
(125, 6, 'Btl1019', '2019-06-21'),
(126, 6, 'Btl1020', '2019-06-21'),
(127, 6, 'Btl1021', '2019-06-21'),
(128, 6, 'Btl1022', '2019-06-21'),
(129, 6, 'Btl1023', '2019-06-21'),
(130, 6, 'Btl1024', '2019-06-21'),
(131, 6, 'Btl1025', '2019-06-21'),
(132, 6, 'Btl1026', '2019-06-21'),
(133, 6, 'Btl1027', '2019-06-21'),
(134, 6, 'Btl1028', '2019-06-21'),
(135, 6, 'Btl1029', '2019-06-21'),
(136, 6, 'Btl1030', '2019-06-21'),
(137, 6, 'Btl1031', '2019-06-21'),
(138, 6, 'Btl1032', '2019-06-21'),
(139, 6, 'Btl1033', '2019-06-21'),
(140, 6, 'Btl1034', '2019-06-21'),
(141, 6, 'Btl1035', '2019-06-21'),
(142, 6, 'Btl1036', '2019-06-21'),
(143, 6, 'Btl1037', '2019-06-21'),
(144, 6, 'Btl1038', '2019-06-21'),
(145, 6, 'Btl1039', '2019-06-21'),
(146, 6, 'Btl1040', '2019-06-21'),
(147, 6, 'Btl1041', '2019-06-21'),
(148, 6, 'Btl1042', '2019-06-21'),
(149, 6, 'Btl1043', '2019-06-21'),
(150, 6, 'Btl1044', '2019-06-21'),
(151, 6, 'Btl1045', '2019-06-21'),
(152, 6, 'Btl1046', '2019-06-21'),
(153, 6, 'Btl1047', '2019-06-21'),
(154, 6, 'Btl1048', '2019-06-21'),
(155, 6, 'Btl1049', '2019-06-21'),
(156, 6, 'Btl1050', '2019-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `taskmaster`
--

DROP TABLE IF EXISTS `taskmaster`;
CREATE TABLE IF NOT EXISTS `taskmaster` (
  `TaskId` int(11) NOT NULL AUTO_INCREMENT,
  `TaskName` text NOT NULL,
  PRIMARY KEY (`TaskId`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taskmaster`
--

INSERT INTO `taskmaster` (`TaskId`, `TaskName`) VALUES
(2, '1st - Round'),
(3, '2nd - Round');

-- --------------------------------------------------------

--
-- Table structure for table `vehicledetail`
--

DROP TABLE IF EXISTS `vehicledetail`;
CREATE TABLE IF NOT EXISTS `vehicledetail` (
  `VehId` int(11) NOT NULL AUTO_INCREMENT,
  `VehNo` text NOT NULL,
  `VehName` text NOT NULL,
  `Status` text NOT NULL,
  PRIMARY KEY (`VehId`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicledetail`
--

INSERT INTO `vehicledetail` (`VehId`, `VehNo`, `VehName`, `Status`) VALUES
(3, 'GJ16AS5913', 'TATA ACE', 'Continue'),
(4, 'GJ22AB1944', 'Chota Hathi', 'Continue');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
